from core.base import ProgramSpec, ToolSpec, PlaceholderTool
from programs.rcc.mwc49.program import MWC49_PROGRAM
from programs.rcc.coe.program import COE_PROGRAM
from programs.rcc.dcd.program import DCD_PROGRAM

RCC_PROGRAM = ProgramSpec(
    id="rcc",
    name="RCC",
    children=[
        MWC49_PROGRAM,
        COE_PROGRAM,
        DCD_PROGRAM
    ]
)

PROGRAMS = {
    RCC_PROGRAM.id: RCC_PROGRAM,
}
