from services.emailingServices.mwc49.risk_tracker_construction import mwc49_risk_tracker_emailer_construction

def mwc49_risk_tracker_email_router(path:str, options: list[str]):
    for option in options:
        if option == "Construction":
            mwc49_risk_tracker_emailer_construction(path)
        else:
            print(f"No emailer defined for option: {option}")