from services.emailingServices.poles.jointPole.releasedVerifyPC20 import releasedVerifyPC20_poles
from services.emailingServices.poles.jointPole.intentCancelledDeletedDraft import intentCancelledDeleteDraft_poles
from services.emailingServices.poles.jointPole.intentReady import intentReady_poles
from services.emailingServices.poles.jointPole.ouDaysExceeded import ouDaysExceeded_poles
from services.emailingServices.poles.permit.confirmPermitIsApproved import confirmPermitIsApproved_poles
from services.emailingServices.poles.permit.permitNeedClickDateForExtension import needClickDateForExtension_poles
from services.emailingServices.poles.permit.permitNotNeeded import notNeeded_poles
from services.emailingServices.poles.permit.permitRequestForExtension import requestForExtension_poles
from services.emailingServices.poles.permit.permitSubmittedOverThirtyDays import submittedOverThirtyDays_poles
from services.emailingServices.poles.land.combinedLandEmailer import combinedLandEmailer
from services.emailingServices.poles.permit.combinedConfirmPermitAndPermitNotNeeded import combinedConfirmPermitAndPermitNotNeeded
from services.emailingServices.poles.permit.combinedRequestForExtensionAndSubmittedOver import combinedRequestForExtensionAndSubmittedOver

from services.emailingServices.maintenance.jointPole.releasedVerifyPC20 import releasedVerifyPC20_maintenance
from services.emailingServices.maintenance.jointPole.intentCancelledDeletedDraft import intentCancelledDeleteDraft_maintenance
from services.emailingServices.maintenance.jointPole.intentReady import intentReady_maintenance
from services.emailingServices.maintenance.jointPole.ouDaysExceeded import ouDaysExceeded_maintenance
from services.emailingServices.maintenance.permit.confirmPermitIsApproved import confirmPermitIsApproved_maintenance
from services.emailingServices.maintenance.permit.permitNeedClickDateForExtension import needClickDateForExtension_maintenance
from services.emailingServices.maintenance.permit.permitNotNeeded import notNeeded_maintenance
from services.emailingServices.maintenance.permit.permitRequestForExtension import requestForExtension_maintenance
from services.emailingServices.maintenance.permit.permitSubmittedOverThirtyDays import submittedOverThirtyDays_maintenance

from services.emailingServices.wmp.permit.combinedConfirmPermitAndPermitNotNeeded import wmp_permit_combinedConfirmPermitAndPermitNotNeeded
from services.emailingServices.wmp.permit.combinedRequestForExtensionAndSubmittedOver import wmp_permit_combinedRequestForExtensionAndSubmittedOver
from services.emailingServices.wmp.miscTSK.ds73 import wmp_miscTSK_ds73


def router(program: str, category: str, path, land_categories = []):
    if program == "poles":
        if category == "Joint Pole | Released. Verify PC20":
            releasedVerifyPC20_poles(path)
        elif category == "Joint Pole | OU Days Exceeded. Complete PC20 and DS48":
            ouDaysExceeded_poles(path)
        elif category == "Joint Pole | Intent Ready to Send Status. Please Send to OU":
            intentReady_poles(path)
        elif category == "Joint Pole | Intent Cancelled/Delete/Draft":
            intentCancelledDeleteDraft_poles(path)
        elif category == "Permit | Confirm Permit is Approved":
            confirmPermitIsApproved_poles(path)
        elif category == "Permit | Need Click Date for Extension":
            needClickDateForExtension_poles(path)
        elif category == "Permit | Request for Extension":
            requestForExtension_poles(path)
        elif category == "Permit | Permit Not Needed":
            notNeeded_poles(path)
        elif category == "Permit | Submitted Over 30 Days":
            submittedOverThirtyDays_poles(path)
        elif category == "Land":
            combinedLandEmailer(path, land_categories)
        elif category == "Permit | Confirm Permit is Approved/Permit Not Needed (Combined email to Brett)":
            combinedConfirmPermitAndPermitNotNeeded(path)
        elif category == "Permit | Request for Extension/Submitted Over 30 Days (Combined email to Brett)":
            combinedRequestForExtensionAndSubmittedOver(path)
        else:
            print("we do not have the code for this right now")
    elif program == "maintenance":
        if category == "Joint Pole | Released. Verify PC20":
            releasedVerifyPC20_maintenance(path)
        elif category == "Joint Pole | OU Days Exceeded. Complete PC20 and DS48":
            ouDaysExceeded_maintenance(path)
        elif category == "Joint Pole | Intent Ready to Send Status. Please Send to OU":
            intentReady_maintenance(path)
        elif category == "Joint Pole | Intent Cancelled/Delete/Draft":
            intentCancelledDeleteDraft_maintenance(path)
        elif category == "Permit | Confirm Permit is Approved":
            confirmPermitIsApproved_maintenance(path)
        elif category == "Permit | Need Click Date for Extension":
            needClickDateForExtension_maintenance(path)
        elif category == "Permit | Request for Extension":
            requestForExtension_maintenance(path)
        elif category == "Permit | Permit Not Needed":
            notNeeded_maintenance(path)
        elif category == "Permit | Submitted Over 30 Days":
            submittedOverThirtyDays_maintenance(path)
        else:
            print("we do not have the code for this right now")
    elif program == "wmp":
        if category == "Permit | Need Click Date for Extension":
            print("Permit | Need Click Date for Extension")
        elif category == "Permit | Confirm Permit is Approved/Permit Not Needed (Combined email to Brett)":
            wmp_permit_combinedConfirmPermitAndPermitNotNeeded(path)
        elif category == "Permit | Request for Extension/Submitted Over 45 Days (Combined email to Brett)":
            wmp_permit_combinedRequestForExtensionAndSubmittedOver(path)
        elif category == "DS73 | Task Closure Request":
            wmp_miscTSK_ds73()
    
    else:
        print("we do not have code for this program right now")
