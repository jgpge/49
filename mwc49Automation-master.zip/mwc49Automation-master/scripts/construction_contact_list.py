# scripts/construction_contact_list.py
from __future__ import annotations

import os
import sqlite3
from typing import List, Tuple


DB_PATH = os.path.join("data", "static_lists.db")
TABLE_NAME = "construction_contact_list"

# Authoritative source of truth: the table will be replaced with exactly these rows each run
ROWS: List[Tuple[str, str]] = [
    ("Nick Fisher (SF)", "naf9@pge.com"),
    ("Casey Northey (CC)", "c3n1@pge.com"),
    ("Eleanor Co Reid (MI)", "epc6@pge.com"),
    ("Ghazi Elayyan (SF)", "gxeu@pge.com"),
    ("Ryan Yamasaki (ST)", "rcy1@pge.com"),
    ("Nicole Dube (SO)", "nld4@pge.com"),
    ("Jenna McPhaul (HB)", "j72c@pge.com"),
    ("Michael Kollman (SA)", "m2k9@pge.com"),
    ("Mary Corrente, Travis Williams (FR)", "m2rk@pge.com; tjwp@pge.com"),
    ("Andy Race (KE)", "axry@pge.com"),
    ("Salvador Rodriguez (SA)", "s9rk@pge.com"),
    ("Rebecca Robles (SI)", "r1r6@pge.com"),
    ("Sara Singh (YO)", "s910@pge.com"),
    ("Jessica Orman-Haney (PN)", "j3oi@pge.com"),
    ("Jay West (LP)", "j0wq@pge.com"),
    ("Mark Wiebe (CC)", "m8wc@pge.com"),
    ("Brandt Laemmlen (KE)", "b1lf@pge.com"),
    ("Robert Stannard (SJ)", "rts9@pge.com"),
    ("Whitney Cinquini (NV)", "w2c6@pge.com"),
    ("Casey Northey (LP)", "c3n1@pge.com"),
    ("Jordan Penninger (DA)", "j7ps@pge.com"),
    ("Steven Beeny (NV)", "s4bz@pge.com"),
    ("Chris Blomseth (DI)", "c9bw@pge.com"),
    ("Jordan Penninger (SJ)", "j7ps@pge.com")
]


def ensure_db_and_table(conn: sqlite3.Connection) -> None:
    conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
            "Construction Contact" TEXT NOT NULL,
            "Email ID" TEXT NOT NULL
        )
    """)
    conn.commit()


def replace_table_contents(conn: sqlite3.Connection, rows: List[Tuple[str, str]]) -> None:
    # Delete all existing rows, then insert exactly the provided list
    conn.execute(f'DELETE FROM {TABLE_NAME}')
    conn.executemany(
        f'INSERT INTO {TABLE_NAME} ("Construction Contact", "Email ID") VALUES (?, ?)',
        rows,
    )
    conn.commit()


def main() -> None:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    try:
        ensure_db_and_table(conn)
        replace_table_contents(conn, ROWS)

        total = conn.execute(f"SELECT COUNT(*) FROM {TABLE_NAME}").fetchone()[0]
        print(f"[OK] DB: {DB_PATH}")
        print(f"[OK] Table: {TABLE_NAME}")
        print(f"[OK] Rows written: {total}")

    finally:
        conn.close()


if __name__ == "__main__":
    main()
