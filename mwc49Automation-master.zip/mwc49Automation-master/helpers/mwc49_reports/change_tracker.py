# helpers/mwc49_reports/change_tracker.py
from __future__ import annotations
from typing import List, Tuple, Optional, Callable
from datetime import date
import pandas as pd

IGNORE_VALS = {
    "job cancelled",
    "job canceled",
    "job deferred",
    "job hold",
}

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    gg = g.copy()
    if "timestamp_dt" not in gg.columns:
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
    gg = gg.dropna(subset=["timestamp_dt"])
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _clean_val_str(v: object) -> str:
    s = str(v).strip()
    if s == "":
        return ""
    lo = s.lower()
    if lo in {"nan", "none", "null"}:
        return ""
    return s

def _detect_change_for_group(
    gg: pd.DataFrame,
    colname: str,
    is_date: bool,
) -> Optional[Tuple[str, str, str]]:
    """
    Given a single (PM#, NOM) group, sorted ascending by timestamp_dt, detect
    the *latest* change into the CURRENT value of `colname`.

    Returns:
        (current_value_str, last_changed_on_str, previous_value_str)
    or None if no change detected.
    """
    if colname not in gg.columns:
        return None
    if gg.empty:
        return None

    vals_raw = gg[colname].tolist()
    ts_series = gg["timestamp_dt"]

    # Normalized comparison values
    norm_vals = [_clean_val_str(v) for v in vals_raw]
    if len(set(norm_vals)) <= 1:
        # No change at all (all same, or all blank)
        return None

    n = len(norm_vals)
    v_latest = norm_vals[-1]

    # Find the row where the last contiguous block of `v_latest` starts
    latest_start_idx = n - 1
    while latest_start_idx > 0 and norm_vals[latest_start_idx - 1] == v_latest:
        latest_start_idx -= 1

    # Now find the last row BEFORE that block where the value was different
    prev_idx = None
    for i in range(latest_start_idx - 1, -1, -1):
        if norm_vals[i] != v_latest:
            prev_idx = i
            break

    if prev_idx is None:
        # Everything before was blank or equal; treat as no meaningful change
        return None

    # Compute dates
    ts_dates = [ts.to_pydatetime().date() if pd.notna(ts) else None for ts in ts_series]
    last_changed_on_date = ts_dates[latest_start_idx] or ts_dates[-1]

    current_raw = vals_raw[-1]
    previous_raw = vals_raw[prev_idx]

    if is_date:
        current_d = _parse_date_cell(current_raw)
        prev_d = _parse_date_cell(previous_raw)
        current_str = _fmt_mdy(current_d) if current_d else ""
        prev_str = _fmt_mdy(prev_d) if prev_d else ""
    else:
        current_str = _clean_val_str(current_raw)
        prev_str = _clean_val_str(previous_raw)

    last_changed_on_str = _fmt_mdy(last_changed_on_date) if last_changed_on_date else ""

    # If both sides are blank, don't bother
    if current_str == "" and prev_str == "":
        return None

    return current_str, last_changed_on_str, prev_str


def make_change_tracker_table(
    df_window: pd.DataFrame,
    field_mode: str,   # "mat" | "wpd" | "pry"
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> Tuple[List[str], List[List[str]], int]:
    """
    Build the Change Report table for the selected field.

    field_mode:
      - "mat" -> Current Mat
      - "wpd" -> Work Plan Date
      - "pry" -> Project Reporting Year

    Returns: (columns, rows, total_raw_rows)
    """
    total_raw_rows = len(df_window)

    if df_window.empty:
        # choose columns based on field_mode
        if field_mode == "wpd":
            columns = [
                "PM #",
                "New Operating Number",
                "Program Name",                 # <--- added
                "Current Work Plan Date",
                "Last Changed On",
                "Previous Work Plan Date",
            ]
        elif field_mode == "pry":
            columns = [
                "PM #",
                "New Operating Number",
                "Program Name",                 # <--- added
                "Current Project Reporting Year",
                "Last Changed On",
                "Previous Project Reporting Year",
            ]
        else:  # default to mat
            columns = [
                "PM #",
                "New Operating Number",
                "Program Name",                 # <--- added
                "Current Mat",
                "Last Changed On",
                "Previous Mat",
            ]
        return columns, [], total_raw_rows

    df = df_window.copy()
    if "timestamp_dt" not in df.columns:
        df["timestamp_dt"] = pd.to_datetime(df.get("timestamp"), errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])

    # Ensure Program Name column exists
    if "Program Name" not in df.columns:
        df["Program Name"] = ""


    if df.empty:
        return [], [], total_raw_rows

    # DB-wide latest DATE (not time)
    db_max_date: Optional[date] = df["timestamp_dt"].dt.date.max()

    # Field configuration
    if field_mode == "wpd":
        colname = "Work Plan Date"
        is_date = True
        columns = [
            "PM #",
            "New Operating Number",
            "Program Name",                 # <--- added
            "Current Work Plan Date",
            "Last Changed On",
            "Previous Work Plan Date",
        ]
    elif field_mode == "pry":
        colname = "Project Reporting Year"
        is_date = False
        columns = [
            "PM #",
            "New Operating Number",
            "Program Name",                 # <--- added
            "Current Project Reporting Year",
            "Last Changed On",
            "Previous Project Reporting Year",
        ]
    else:  # "mat" (default)
        colname = "Current Mat"
        is_date = False
        columns = [
            "PM #",
            "New Operating Number",
            "Program Name",                 # <--- added
            "Current Mat",
            "Last Changed On",
            "Previous Mat",
        ]

    if colname not in df.columns:
        # Schema doesn't support this field
        return columns, [], total_raw_rows

    # Group by case (PM # + NOM)
    grouped = list(df.groupby(["PM #", "New Operating Number"], sort=False, dropna=False))
    total_groups = len(grouped)
    rows: List[List[str]] = []

    if progress_cb:
        progress_cb(0, total_groups or 1)
    done = 0

    for (pm, nom), g in grouped:
        g = g.reset_index(drop=True)
        gg = _ensure_sorted_with_ts(g)
        if gg.empty:
            done += 1
            if progress_cb:
                progress_cb(done, total_groups or 1)
            continue

        # Freshness guard: latest snapshot date must equal db_max_date
        latest = gg.iloc[-1]
        latest_ts = latest.get("timestamp_dt")
        if pd.isna(latest_ts):
            done += 1
            if progress_cb:
                progress_cb(done, total_groups or 1)
            continue
        latest_date = latest_ts.to_pydatetime().date()
        if db_max_date is not None and latest_date != db_max_date:
            done += 1
            if progress_cb:
                progress_cb(done, total_groups or 1)
            continue

        # Ignore terminal / cancelled / deferred / hold
        ph = _norm(latest.get("Primary Hold-Up"))
        if ph in IGNORE_VALS:
            done += 1
            if progress_cb:
                progress_cb(done, total_groups or 1)
            continue

        # Detect change for this field
        # Detect change for this field
        res = _detect_change_for_group(gg, colname, is_date=is_date)
        if res:
            current_str, last_changed_on_str, prev_str = res
            pm_s = str(pm).strip()
            nom_s = str(nom).strip()

            # Program Name from the latest row for this case
            latest_prog = _clean_val_str(latest.get("Program Name", ""))
            prog_s = str(latest_prog).strip()

            if field_mode == "wpd":
                row = [pm_s, nom_s, prog_s, current_str, last_changed_on_str, prev_str]
            elif field_mode == "pry":
                row = [pm_s, nom_s, prog_s, current_str, last_changed_on_str, prev_str]
            else:  # mat
                row = [pm_s, nom_s, prog_s, current_str, last_changed_on_str, prev_str]

            rows.append(row)

        done += 1
        if progress_cb:
            progress_cb(done, total_groups or 1)

    return columns, rows, total_raw_rows
