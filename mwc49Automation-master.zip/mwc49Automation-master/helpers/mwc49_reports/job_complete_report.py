# helpers/mwc49_reports/job_complete_report.py
from __future__ import annotations
from typing import List, Tuple
import pandas as pd

from .common_helpers import fmt_mdy
from .stakeholder_holdup_logic.common import latest_of  # reuse helper

# Columns we’ll output (in this order)
COLUMNS = [
    "PM #",
    "New Operating Number",
    "Project Reporting Year",   # NEW (right after NOM)
    "Current Mat",
    "Program Name",
    "Division",
    "Construction Resource",
    "Completion Criteria",
    "Date of Completion",
]

# Values that mark a job as complete (case-insensitive compare)
_COMPLETE_VALUES = {
    "commissioned": "Commissioned",
    "installed, commissioning not required": "Installed, Commissioning Not Required",
}

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _ensure_ts_sorted(df: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in df.columns:
        gg = df.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = df.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def make_job_complete_table(df: pd.DataFrame) -> Tuple[List[str], List[List[str]], int]:
    """
    For each PM #:
      - Find the FIRST timestamp where 'Stage of Job' is either:
          * 'Commissioned', or
          * 'Installed, Commissioning Not Required'
        (case-insensitive match on value)
      - Completion Criteria = the matched text as above
      - Date of Completion = that timestamp's calendar date (MM/DD/YYYY via fmt_mdy)
      - Project Reporting Year = pulled from the SAME row as Date of Completion (the row that met completion)
      - Program Name, Division & Construction Resource = latest non-empty strings within the group (if present)
      - If not found, set Completion Criteria = 'Not Enough Data' and Date of Completion = 'Not Enough Data'
        and Project Reporting Year = 'Not Enough Data'
    Returns: (columns, rows, total_raw_input_rows)
    """
    total_raw = len(df)
    if df.empty:
        return COLUMNS, [], total_raw

    # normalize basics
    work = df.copy()
    work["PM #"] = work["PM #"].astype(str).str.strip()

    if "New Operating Number" not in work.columns:
        work["New Operating Number"] = ""
    if "Project Reporting Year" not in work.columns:
        work["Project Reporting Year"] = ""
    if "Current Mat" not in work.columns:
        work["Current Mat"] = ""
    if "Program Name" not in work.columns:
        work["Program Name"] = ""
    # optional columns — may be absent in some snapshots
    if "Division" not in work.columns:
        work["Division"] = ""
    if "Construction Resource" not in work.columns:
        work["Construction Resource"] = ""

    work = _ensure_ts_sorted(work)

    rows: List[List[str]] = []

    for pm, g in work.groupby("PM #", sort=False):
        g = g.reset_index(drop=True)

        # Latest string values for descriptive columns
        nom  = latest_of(g, "New Operating Number")
        cmat = latest_of(g, "Current Mat")
        prog = latest_of(g, "Program Name") if "Program Name" in g.columns else ""
        div  = latest_of(g, "Division") if "Division" in g.columns else ""
        cres = latest_of(g, "Construction Resource") if "Construction Resource" in g.columns else ""

        # Scan chronologically for first completion state
        comp_criteria_display = "Not Enough Data"
        comp_date_display     = "Not Enough Data"
        pry_display           = "Not Enough Data"  # NEW

        if "Stage of Job" in g.columns and not g.empty:
            for _, row in g.iterrows():
                stg = _norm(row.get("Stage of Job"))
                if stg in _COMPLETE_VALUES:
                    crit = _COMPLETE_VALUES[stg]
                    ts = row.get("timestamp_dt")
                    if pd.notna(ts):
                        comp_criteria_display = crit
                        comp_date_display = fmt_mdy(ts.to_pydatetime())

                        # Pull PRY from the SAME row that triggered completion
                        pry_val = row.get("Project Reporting Year", "")
                        pry_val = "" if pry_val is None else str(pry_val).strip()
                        pry_display = pry_val or "-"

                        break  # first hit only

        rows.append([
            pm,
            nom,
            pry_display,  # NEW
            cmat,
            prog,
            div or "-",
            cres or "-",
            comp_criteria_display,
            comp_date_display,
        ])

    return COLUMNS, rows, total_raw
