# helpers/mwc49_reports/stakeholder_holdup_lifecycle.py
from __future__ import annotations
from datetime import datetime
from typing import List, Dict, Optional
import pandas as pd

from .common_helpers import STAKEHOLDER_ORDER, PRIMARY_TO_STAKEHOLDER, stakeholder_from_phu

# ---------------- Device Type → Category mapping (case-insensitive) ----------------
_DEVICE_TYPE_PAIRS = [
    ("Add SCADA to LR", "Add SCADA"),
    ("Add SCADA to LR-NOVA", "Add SCADA"),
    ("FS", "FS"),
    ("SCADAMATE", "SCADAMATE"),
    ("LR-GW", "LR"),
    ("MANUAL OH SW", "Switch"),
    ("INT", "INT"),
    ("SW (OH)", "Switch"),
    ("3-WAY SCADA SWITCH", "Switch"),
    ("CO", "Switch"),
    ("3W SW w/ SCADA Control", "Switch"),
    ("Fuse", "Fuse"),
    ("Controller Only - LR Beckwith - 19PIN", "Controller Only"),
    ("FUSE & FI", "Fuse"),
    ("UG Mainline", "Misc."),
    ("LR Relocate", "LR"),
    ("S/S SCADA Switch", "Switch"),
    ("Controller Only LR 4C 19 PIN", "Controller Only"),
    ("Pole reframe", "Misc."),
    ("OH removal", "Misc."),
    ("SW-INT-SW", "Switch"),
    ("SWITCH", "Switch"),
    ("FS - Open Policy", "FS"),
    ("LR-ABB/SEL", "LR"),
    ("PMI Non Scada", "Misc."),
    ("LR", "LR"),
    ("LR-GW & Switch", "LR"),
    ("SCADA Switch", "Switch"),
    ("FS -  Zero Policy", "FS"),
    ("Remove", "Misc."),
    ("Viper ST", "Misc."),
    ("LR - Viper SEL", "LR"),
    ("LR single phase", "LR"),
    ("SW", "Switch"),
    ("3 Way 600A Switch", "Switch"),
    ("Upgrade Firmware", "Misc."),
    ("LR Transfer", "LR"),
    ("USB Switch", "Switch"),
]

# Build a case-insensitive lookup
DEVICE_TYPE_TO_CATEGORY: Dict[str, str] = {k.strip().upper(): v for k, v in _DEVICE_TYPE_PAIRS}

def device_category_from_type(dt: str | None) -> str:
    if not dt:
        return "Unknown"
    key = str(dt).strip().upper()
    return DEVICE_TYPE_TO_CATEGORY.get(key, "Unknown")

# ------------------------------------------------------------------------------

def make_stakeholder_holdup_lifecycle_table(
    df: pd.DataFrame,
    window_start: datetime,
    window_end: datetime,
):
    total_raw = len(df)

    # Empty guard
    if df.empty:
        columns = ["PM #", "New Operating Number", "Current Mat", "Device Category"] + STAKEHOLDER_ORDER
        return (
            columns,
            [],
            total_raw,
            {s: 0 for s in STAKEHOLDER_ORDER},
            {s: 0 for s in STAKEHOLDER_ORDER},
        )

    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])

    # Normalize columns used
    df["Primary Hold-Up"] = df["Primary Hold-Up"].astype(str).str.strip()
    df["PM #"] = df["PM #"].astype(str).str.strip()
    df["New Operating Number"] = df["New Operating Number"].astype(str).str.strip()
    if "Current Mat" not in df.columns:
        df["Current Mat"] = ""   # safety
    if "Device Type" not in df.columns:
        df["Device Type"] = ""   # safety

    # Keep only PHUs we can map to a stakeholder
    df = df[df["Primary Hold-Up"].isin(PRIMARY_TO_STAKEHOLDER.keys())]
    if df.empty:
        columns = ["PM #", "New Operating Number", "Current Mat", "Device Category"] + STAKEHOLDER_ORDER
        return (
            columns,
            [],
            total_raw,
            {s: 0 for s in STAKEHOLDER_ORDER},
            {s: 0 for s in STAKEHOLDER_ORDER},
        )

    # Sort so the "latest" values per PM are easy to take
    df = df.sort_values(["PM #", "timestamp_dt"], ascending=[True, True])

    per_stk_nonzero_counts: Dict[str, int] = {s: 0 for s in STAKEHOLDER_ORDER}
    per_stk_nonzero_sums: Dict[str, int] = {s: 0 for s in STAKEHOLDER_ORDER}

    out_rows: List[List[str]] = []

    for pm, g in df.groupby("PM #", sort=False):
        g = g.reset_index(drop=True)

        # Latest values (from the last row within the window slice)
        last_nom = str(g["New Operating Number"].iloc[-1]).strip() if "New Operating Number" in g.columns else ""
        last_mat = str(g["Current Mat"].iloc[-1]).strip() if "Current Mat" in g.columns else ""

        # Latest non-blank Device Type in the group, else blank/Unknown
        # (You can change to strictly "last row" by removing dropna/replace)
        device_type_series = g["Device Type"].astype(str).str.strip().replace({"": pd.NA}).dropna()
        last_device_type: Optional[str] = device_type_series.iloc[-1] if not device_type_series.empty else ""
        device_category = device_category_from_type(last_device_type)

        pm_stk_days: Dict[str, int] = {s: 0 for s in STAKEHOLDER_ORDER}

        # Walk the lifecycle within the window
        for i in range(len(g)):
            row = g.loc[i]
            phu = row["Primary Hold-Up"]
            resolve_val = str(row.get("Resolve Date", "") or "")
            stk = stakeholder_from_phu(phu, resolve_val)
            if not stk:
                continue

            start_ts = row["timestamp_dt"].to_pydatetime()
            if i < len(g) - 1:
                end_ts = g.loc[i + 1, "timestamp_dt"].to_pydatetime()
            else:
                end_ts = window_end

            interval_start = max(start_ts, window_start)
            interval_end = min(end_ts, window_end)
            if interval_end <= interval_start:
                continue

            days = (interval_end.date() - interval_start.date()).days
            if days < 0:
                days = 0

            pm_stk_days[stk] = pm_stk_days.get(stk, 0) + days

        # update global stats
        for s in STAKEHOLDER_ORDER:
            d = pm_stk_days.get(s, 0)
            if d > 0:
                per_stk_nonzero_counts[s] += 1
                per_stk_nonzero_sums[s] += d

        # row: PM, NOM, Current Mat, Device Category, stakeholders...
        row_vals: List[str] = [pm, last_nom, last_mat, device_category]
        for s in STAKEHOLDER_ORDER:
            row_vals.append(f"{pm_stk_days.get(s, 0)} days")
        out_rows.append(row_vals)

    columns = ["PM #", "New Operating Number", "Current Mat", "Device Category"] + STAKEHOLDER_ORDER
    return (
        columns,
        out_rows,
        total_raw,
        per_stk_nonzero_counts,
        per_stk_nonzero_sums,
    )