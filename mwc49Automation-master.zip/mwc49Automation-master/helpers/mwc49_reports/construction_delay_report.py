from __future__ import annotations
from typing import List, Tuple, Dict
import pandas as pd

from .common_helpers import build_click_delay_rows_normalized

RFC_ONLY = "Ready for Construction"

def make_construction_delay_table(df_window: pd.DataFrame) -> Tuple[List[str], List[List[str]], List[int], int]:
    """
    Returns (columns, rows, totals, total_raw_rows).

    - CLICK End Date change detection is computed ONLY while Stage of Job = 'Ready for Construction'.
    - Adds 'Current Mat', 'Program Name', 'Division', and 'Construction Resource' after NOM for each PM.
    """
    total_raw_rows = len(df_window)

    # 1) Only RFC rows for change detection
    df_rfc = df_window.copy()
    if "Stage of Job" in df_rfc.columns:
        stage_series = df_rfc["Stage of Job"].astype(str).str.strip()
        df_rfc = df_rfc[stage_series.eq(RFC_ONLY)].copy()

    rows, max_changes, totals = build_click_delay_rows_normalized(df_rfc)

    # 2) Latest descriptors (per full window)
    pm_to_mat: Dict[str, str] = {}
    pm_to_prog: Dict[str, str] = {}
    pm_to_div: Dict[str, str] = {}
    pm_to_cr:  Dict[str, str] = {}

    df_latest = df_window.copy()
    for col in ("PM #", "Current Mat", "Program Name", "Division", "Construction Resource", "timestamp"):
        if col not in df_latest.columns:
            df_latest[col] = ""

    # sort: PM then timestamp
    try:
        df_latest["timestamp_dt"] = pd.to_datetime(df_latest["timestamp"], errors="coerce")
        df_latest = df_latest.sort_values(["PM #", "timestamp_dt"], na_position="last")
    except Exception:
        df_latest = df_latest.sort_values(["PM #"])

    for _, r in df_latest.iterrows():
        pm = str(r.get("PM #", "")).strip()
        if not pm:
            continue
        pm_to_mat[pm]  = str(r.get("Current Mat", "")).strip()
        pm_to_prog[pm] = str(r.get("Program Name", "")).strip()
        pm_to_div[pm]  = str(r.get("Division", "")).strip()
        pm_to_cr[pm]   = str(r.get("Construction Resource", "")).strip()

    # 3) Insert descriptors into rows
    new_rows: List[List[str]] = []
    for row in rows:
        pm = row[0] if len(row) > 0 else ""
        mat  = pm_to_mat.get(pm, "")
        prog = pm_to_prog.get(pm, "")
        div  = pm_to_div.get(pm, "")
        cr   = pm_to_cr.get(pm, "")
        # [PM #, NOM, Current Mat, Program Name, Division, Construction Resource, ...rest...]
        new_rows.append([row[0], row[1], mat, prog, div, cr] + row[2:])

    # 4) Columns
    columns = [
        "PM #",
        "New Operating Number",
        "Current Mat",
        "Program Name",
        "Division",
        "Construction Resource",
        "Initial CLICK End Date",
        "Timestamp",
    ]
    for i in range(1, max_changes + 1):
        columns += [f"Change {i}", f"Timestamp {i}", f"Delay {i}"]
    columns += ["Total Delay"]

    return columns, new_rows, totals, total_raw_rows
