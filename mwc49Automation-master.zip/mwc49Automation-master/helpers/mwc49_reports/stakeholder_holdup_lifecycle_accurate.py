# helpers/mwc49_reports/stakeholder_holdup_lifecycle_accurate.py
from __future__ import annotations
from datetime import datetime
from typing import List, Tuple, Callable, Optional
import pandas as pd

from .stakeholder_holdup_logic import REGISTRY  # modules register themselves here
from .stakeholder_holdup_logic.common import latest_of, latest_device_category

# Progress callback type: (done, total)
ProgressCb = Callable[[int, int], None]

# UI label for “all”
ACCURATE_ALL_LABEL = "-----ALL-----"

# Expose choices: ALL + whatever is in the registry (order preserved by dict)
ACCURATE_STAKEHOLDER_CHOICES = [ACCURATE_ALL_LABEL] + list(REGISTRY.keys())


def make_stakeholder_holdup_lifecycle_accurate(
    df: pd.DataFrame,
    window_start: datetime,   # kept for symmetry; not used by current logic
    window_end: datetime,     # kept for symmetry; not used by current logic
    selected_stakeholder: str,
    progress_cb: Optional[ProgressCb] = None,   # optional progress callback
) -> Tuple[List[str], List[List[str]], int]:
    """
    UPDATED GROUPING:
      - Groups are now per (PM #, New Operating Number) pair.

    - If selected_stakeholder == ACCURATE_ALL_LABEL:
        Columns: PM # | NOM | Current Mat | Program Name | Device Category | Stakeholder | Stakeholder Holdup
        One row per (PM, NOM, stakeholder) using each module in REGISTRY.
    - Else (single stakeholder):
        Columns: PM # | NOM | Current Mat | Program Name | Device Category | *module.EXTRA_COLS | <Stakeholder> Holdup
        EXACTLY preserves each module’s start/end columns (or other extras).

    If provided, progress_cb(done, total) is called once per (PM, NOM) group processed.
    """
    total_raw = len(df)

    # Build columns for empty case
    if df.empty:
        if selected_stakeholder == ACCURATE_ALL_LABEL:
            cols = [
                "PM #",
                "New Operating Number",
                "Current Mat",
                "Program Name",
                "Device Category",
                "Stakeholder",
                "Stakeholder Holdup",
            ]
        else:
            mod = REGISTRY[selected_stakeholder]
            cols = [
                "PM #",
                "New Operating Number",
                "Current Mat",
                "Program Name",
                "Device Category",
                *mod.EXTRA_COLS,
                f"{selected_stakeholder} Holdup",
            ]
        return cols, [], total_raw

    # Normalize frame
    df = df.copy()
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])

    df["PM #"] = df["PM #"].astype(str).str.strip()
    df["New Operating Number"] = df["New Operating Number"].astype(str).str.strip()
    if "Current Mat" not in df.columns:
        df["Current Mat"] = ""
    if "Program Name" not in df.columns:
        df["Program Name"] = ""
    if "Device Type" not in df.columns:
        df["Device Type"] = ""

    # Sort so each group is time-ordered (and grouping order is stable)
    df = df.sort_values(["PM #", "New Operating Number", "timestamp_dt"], ascending=[True, True, True])

    # ✅ UPDATED: group by (PM #, NOM)
    grouped = list(df.groupby(["PM #", "New Operating Number"], sort=False))
    total_groups = len(grouped)
    done = 0
    if progress_cb:
        try:
            progress_cb(done, total_groups)
        except Exception:
            pass

    # ---------------- ALL (compact) ----------------
    if selected_stakeholder == ACCURATE_ALL_LABEL:
        columns = [
            "PM #",
            "New Operating Number",
            "Current Mat",
            "Program Name",
            "Device Category",
            "Stakeholder",
            "Stakeholder Holdup",
        ]
        rows: List[List[str]] = []

        for (pm, nom), g in grouped:
            g = g.reset_index(drop=True)

            # NOM is now fixed for the group; no need to compute last_nom
            last_mat = latest_of(g, "Current Mat")
            last_prog = latest_of(g, "Program Name")
            device_category = latest_device_category(g)

            for name, mod in REGISTRY.items():
                res = mod.compute_for_group(g)
                rows.append([
                    pm,
                    nom,
                    last_mat,
                    last_prog,
                    device_category,
                    name,
                    res.holdup_value,
                ])

            done += 1
            if progress_cb:
                try:
                    progress_cb(done, total_groups)
                except Exception:
                    pass

        return columns, rows, total_raw

    # --------------- Single stakeholder (keep module columns) ---------------
    mod = REGISTRY[selected_stakeholder]
    columns = [
        "PM #",
        "New Operating Number",
        "Current Mat",
        "Program Name",
        "Device Category",
        *mod.EXTRA_COLS,
        f"{selected_stakeholder} Holdup",
    ]

    rows: List[List[str]] = []
    for (pm, nom), g in grouped:
        g = g.reset_index(drop=True)

        last_mat = latest_of(g, "Current Mat")
        last_prog = latest_of(g, "Program Name")
        device_category = latest_device_category(g)

        res = mod.compute_for_group(g)
        rows.append([
            pm,
            nom,
            last_mat,
            last_prog,
            device_category,
            *res.extra_values,
            res.holdup_value,
        ])

        done += 1
        if progress_cb:
            try:
                progress_cb(done, total_groups)
            except Exception:
                pass

    return columns, rows, total_raw
