# helpers/mwc49_reports/risk_tracker_logic/dlt_adms.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

ACTION_ADMS_PENDING = "ADMS test date pending."

class RiskEval(NamedTuple):
    action: str
    hold_up: str
    resolve_date_str: str

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def evaluate_group_for_dlt_adms_detail(g: pd.DataFrame, db_max_date: Optional[date] = None) -> Optional[RiskEval]:
    """
    Show when:
      - Latest (most recent timestamp) row has Primary Hold-Up == "ADMS test pending"
      - AND Resolve Date is in the past (relative to today).
    Sanity:
      - Ignore if the latest snapshot is > 1 day older than today.
      - Ignore if Primary/Secondary Hold-Up is any of: Job cancelled / Job deferred / Job hold.
    Output columns (consumed by risk_tracker):
      PM # | New Operating Number | Stakeholder | Primary Hold-Up | Resolve Date | Action
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    latest = gg.iloc[-1]
    last_ts = latest["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    # Sanity 1: must be within 1 day of TODAY
    last_date = last_ts.to_pydatetime().date()
    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None

    # Sanity 2: blocked terminal statuses
    if _blocked_by_holdups(latest):
        return None

    # Core condition
    ph_raw = latest.get("Primary Hold-Up")
    ph = _norm(ph_raw)
    if ph != "adms test pending":
        return None

    rd = _parse_date_cell(latest.get("Resolve Date"))
    if rd is None:
        return None
    if rd >= date.today():
        return None

    return RiskEval(
        action=ACTION_ADMS_PENDING,
        hold_up=str(ph_raw).strip() if ph_raw is not None else "",
        resolve_date_str=_fmt_mdy(rd),
    )
