# helpers/mwc49_reports/risk_tracker_logic/adms.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

# Action text constants
ACTION_SCADA_LETTER = "SCADA letter pending."
ACTION_SCADA_WO_PAST_DUE = "SCADA WO past due."

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure we have a timestamp_dt column and that rows are sorted
    oldest -> newest by that column.
    """
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    """
    Same terminal / hold status guard as Construction:
      Primary/Secondary Hold-Up ∈ {Job cancelled, Job deferred, Job hold, Project managed}
    """
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold", "project managed"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def _inpr_stint_start_index(gg: pd.DataFrame, status_col: str = "SCADA WO Status") -> Optional[int]:
    """
    Starting from the latest row, walk backwards while SCADA WO Status == INPR.
    Return the earliest index in this contiguous INPR stint (oldest INPR in that run).
    """
    if status_col not in gg.columns:
        return None

    statuses = gg[status_col].apply(_norm).to_list()
    first_idx = None
    in_stint = False

    # Walk backwards from the newest row
    for i in range(len(statuses) - 1, -1, -1):
        if statuses[i] == "inpr":
            first_idx = i
            in_stint = True
        else:
            if in_stint:
                # We just stepped out of the INPR block
                break

    return first_idx

class ADMSEval(NamedTuple):
    action: str
    primary_hold_up: str
    resolve_date_str: str

def evaluate_group_for_adms_detail(
    g: pd.DataFrame,
    db_max_date: Optional[date] = None,   # same “freshness” semantics as Construction
) -> Optional[ADMSEval]:
    """
    ADMS stakeholder logic.

    Sanity / guardrails:
      - Require timestamp_dt and at least Primary / Secondary Hold-Up.
      - Freshness rule:
          * If db_max_date is provided, latest snapshot DATE must equal db_max_date; else ignore.
          * If db_max_date is None, latest snapshot DATE must be today; else ignore.
      - Ignore the group if latest Primary/Secondary Hold-Up is in terminal/hold statuses.

    Case 1:
      - In the LATEST snapshot row:
          Primary Hold-Up == "SCADA letter pending" (case-insensitive), AND
          Resolve Date is in the past (Resolve Date < today).
        => Action: "SCADA letter pending."

    Case 2:
      - In the LATEST snapshot row:
          SCADA WO Status == "INPR" (case-insensitive).
      - Walk backwards in time (by timestamp_dt) while SCADA WO Status == "INPR"
        to find when this INPR stint started.
      - If it has been in INPR for 2+ weeks (>= 14 days),
        => Action: "SCADA WO past due."
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    need = {"Primary Hold-Up", "Secondary Hold-Up"}
    if not need.issubset(set(gg.columns)):
        return None

    latest = gg.iloc[-1]
    last_ts = latest.get("timestamp_dt")
    if pd.isna(last_ts):
        return None

    last_date = last_ts.to_pydatetime().date()

    # ---- Freshness guard (NO subtraction with None)
    today = date.today()
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        if last_date != today:
            return None

    # ---- Terminal / hold statuses
    if _blocked_by_holdups(latest):
        return None

    pri_raw = latest.get("Primary Hold-Up")
    pri = _norm(pri_raw)

    # ------------------- Case 1: SCADA letter pending -------------------
    # Primary Hold-Up == "SCADA letter pending" AND Resolve Date < today
    if pri == "scada letter pending":
        resolve_date: Optional[date] = None
        if "Resolve Date" in gg.columns:
            resolve_date = _parse_date_cell(latest.get("Resolve Date"))

        if resolve_date and resolve_date < today:
            return ADMSEval(
                action=ACTION_SCADA_LETTER,
                primary_hold_up=str(pri_raw).strip() if pri_raw is not None else "",
                resolve_date_str=_fmt_mdy(resolve_date),
            )

    # ------------------- Case 2: SCADA WO Status INPR too long -------------------
    status_col = "SCADA WO Status"
    if status_col not in gg.columns:
        return None

    latest_status = _norm(latest.get(status_col))
    if latest_status != "inpr":
        # ADMS logic only triggers when latest SCADA WO Status is INPR
        return None

    start_idx = _inpr_stint_start_index(gg, status_col=status_col)
    if start_idx is None:
        return None

    stint_start_ts = gg.loc[start_idx, "timestamp_dt"]
    if pd.isna(stint_start_ts):
        return None

    stint_start_date = stint_start_ts.to_pydatetime().date()
    days_in_inpr = (last_date - stint_start_date).days

    # "More than 2 weeks" -> 2+ weeks / 14+ days, following the pattern used elsewhere
    if days_in_inpr >= 14:
        # We can keep Primary Hold-Up from latest row; Resolve Date may or may not exist.
        resolve_date_str = ""
        if "Resolve Date" in gg.columns:
            rd = _parse_date_cell(latest.get("Resolve Date"))
            if rd:
                resolve_date_str = _fmt_mdy(rd)

        return ADMSEval(
            action=ACTION_SCADA_WO_PAST_DUE,
            primary_hold_up=str(pri_raw).strip() if pri_raw is not None else "",
            resolve_date_str=resolve_date_str,
        )

    return None

def evaluate_group_for_adms(g: pd.DataFrame) -> Optional[str]:
    """Convenience wrapper if you ever need just the action string."""
    res = evaluate_group_for_adms_detail(g)
    return res.action if res else None
