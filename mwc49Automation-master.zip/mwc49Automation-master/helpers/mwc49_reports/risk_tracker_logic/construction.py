# helpers/mwc49_reports/risk_tracker_logic/construction.py
from __future__ import annotations
from typing import NamedTuple, Optional, Tuple
from datetime import date, timedelta
import pandas as pd

READY_VAL = "ready for construction"

ACTION_NO_CLICK = (
    "Please schedule job for construction. "
    "It has been 2+ weeks since job was ready for construction."
)
ACTION_PULL_IN = (
    "Please pull in job. Scheduled for 9+ weeks since ready for construction."
)
ACTION_CLICK_OLD = (
    "Need new CLICK Date. Latest CLICK Date older than 1 week."
)
ACTION_CN24 = (
    "Please complete CN24."
)
ACTION_CONSTR_REVISIT = (
    "Construction revisit pending. Job not complete."
)
ACTION_CLICK_REMOVED = (
    "Need new CLICK Date. CLICK Date removed."
)

# UPDATED: outside-PRY logic is now specifically "outside of 2026"
ACTION_OUTSIDE_2026 = (
    "Job scheduled outside of 2026"
)

ACTION_MATERIAL_PAST_DUE = (
    "Material past due."
)

class RiskEval(NamedTuple):
    action: str
    rfc_date_str: str
    click_end_date_str: str  # holds the CURRENT CE value (or "")

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _first_nonempty_after_idx(
    g: pd.DataFrame, col: str, start_idx: int
) -> Tuple[int | None, date | None, date | None]:
    if col not in g.columns:
        return None, None, None
    for i in range(max(0, start_idx), len(g)):
        raw = g.iloc[i][col]
        if pd.isna(raw) or str(raw).strip() == "":
            continue
        ts = g.iloc[i]["timestamp_dt"]
        ts_d = ts.to_pydatetime().date() if pd.notna(ts) else None
        val_d = _parse_date_cell(raw)
        return i, ts_d, val_d
    return None, None, None

def _last_rfc_stint_start_index(g: pd.DataFrame) -> int | None:
    if "Stage of Job" not in g.columns:
        return None
    is_rfc = g["Stage of Job"].apply(_norm).eq(READY_VAL).to_list()

    last_start_idx = None
    prev = False
    for i, cur in enumerate(is_rfc):
        if cur and not prev:
            last_start_idx = i  # entering an RFC stint
        prev = cur

    return last_start_idx

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold", "project managed"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def _had_nonempty_ce_before_latest(gg: pd.DataFrame) -> bool:
    """
    Returns True if any row *before the latest* has a non-empty CLICK End Date.
    Used to detect cases where CE existed previously but is now blank.
    """
    if "CLICK End Date" not in gg.columns or len(gg) <= 1:
        return False

    prev = gg["CLICK End Date"].iloc[:-1]
    for raw in prev:
        if pd.isna(raw):
            continue
        if str(raw).strip() != "":
            return True
    return False

def _parse_year(val) -> Optional[int]:
    """
    Try to interpret Project Reporting Year as an integer year.
    Handles numeric, '2025.0', '2025', and date-like strings.
    """
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    s = str(val).strip()
    if not s:
        return None
    # Try simple numeric year first
    try:
        return int(float(s))
    except Exception:
        pass
    # Fallback: parse as date and take year
    try:
        dt = pd.to_datetime(s, errors="coerce")
        if pd.notna(dt):
            return dt.year
    except Exception:
        pass
    return None

def evaluate_group_for_construction_detail(
    g: pd.DataFrame,
    db_max_date: Optional[date] = None,   # safely optional
) -> Optional[RiskEval]:
    """
    CURRENT-snapshot logic with guards.

    Freshness rule:
      - If db_max_date is provided, the group's latest snapshot DATE must equal db_max_date; else ignore.
      - If db_max_date is None, fallback to: latest snapshot DATE must be today (0-day tolerance); else ignore.

    Also ignore if latest Primary/Secondary Hold-Up ∈ {Job cancelled, Job deferred, Job hold, Project managed}.

    Additional cases handled:
      - Construction revisit pending.
      - CE removed while RFC (only when Primary Hold-Up == 'Construction pending').
      - Job scheduled outside of 2026 (ONLY when PRY == 2026 and CE year != 2026),
        except when Stage of Job is 'Commissioned' or 'Installed, Commissioning Not Required'.
      - Material past due (Primary Hold-Up == 'Device ETA' and Resolve Date in the past).
      - CN24 overdue (with guard against CN24 clerical pending).
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    if "CLICK End Date" not in gg.columns:
        return None

    latest_row = gg.iloc[-1]
    last_ts = latest_row["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    last_date = last_ts.to_pydatetime().date()

    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if last_date != date.today():
            return None

    # ---- Terminal/hold statuses
    if _blocked_by_holdups(latest_row):
        return None

    latest_stage = _norm(latest_row.get("Stage of Job")) if "Stage of Job" in gg.columns else ""
    latest_ce_raw = latest_row.get("CLICK End Date")
    latest_ce_val_date = _parse_date_cell(latest_ce_raw)

    # Compute start of the LAST RFC stint (may be None)
    start_idx = _last_rfc_stint_start_index(gg) if "Stage of Job" in gg.columns else None
    rfc_date: Optional[date] = None
    if start_idx is not None:
        rfc_ts = gg.loc[start_idx, "timestamp_dt"]
        if pd.notna(rfc_ts):
            rfc_date = rfc_ts.to_pydatetime().date()

    # Latest Primary Hold-Up (normalized)
    pri_norm = _norm(latest_row.get("Primary Hold-Up"))

    # ------------------- Case: Construction revisit pending -------------------
    if pri_norm == "construction revisit pending":
        return RiskEval(
            ACTION_CONSTR_REVISIT,
            _fmt_mdy(rfc_date) if rfc_date else "",
            _fmt_mdy(latest_ce_val_date) if latest_ce_val_date else "",
        )

    # ----------------------- Cases that REQUIRE latest RFC -----------------------
    if latest_stage == READY_VAL and rfc_date is not None:
        days_since_rfc = (last_date - rfc_date).days if (last_date and rfc_date) else 0

        # Case: CE removed while RFC *and* Primary Hold-Up == "Construction pending"
        if (
            latest_ce_val_date is None
            and pri_norm == "construction pending"
            and _had_nonempty_ce_before_latest(gg)
        ):
            return RiskEval(
                ACTION_CLICK_REMOVED,
                _fmt_mdy(rfc_date),
                "",   # current CE is blank
            )

        # Original "no CLICK for 2+ weeks since RFC" rule
        if latest_ce_val_date is None and days_since_rfc >= 14:
            return RiskEval(ACTION_NO_CLICK, _fmt_mdy(rfc_date), "")

        # Original "pull in job" rule
        if latest_ce_val_date is not None and start_idx is not None:
            _idx, first_ce_row_ts_date, _first_ce_val_date = _first_nonempty_after_idx(
                gg, "CLICK End Date", start_idx
            )
            within_2w = (
                (first_ce_row_ts_date is not None) and (rfc_date is not None) and
                ((first_ce_row_ts_date - rfc_date).days <= 14)
            )
            far_out_now = (
                (latest_ce_val_date is not None) and (rfc_date is not None) and
                ((latest_ce_val_date - rfc_date).days >= 63)
            )
            if within_2w and far_out_now:
                return RiskEval(
                    ACTION_PULL_IN,
                    _fmt_mdy(rfc_date),
                    _fmt_mdy(latest_ce_val_date),
                )

    # ----------------------- Cases that DO NOT require latest RFC ----------------
    fic_col = "Field Install Completed (Yes)"
    latest_fic_yes = _norm(latest_row.get(fic_col)) == "yes" if fic_col in gg.columns else False
    ce_older_than_7 = (
        (latest_ce_val_date is not None) and (last_date is not None) and
        ((last_date - latest_ce_val_date) > timedelta(days=7))
    )
    if ce_older_than_7 and not latest_fic_yes:
        return RiskEval(
            ACTION_CLICK_OLD,
            _fmt_mdy(rfc_date) if rfc_date else "",
            _fmt_mdy(latest_ce_val_date),
        )

    cn24_col = "CN24 Status"
    latest_cn24 = _norm(latest_row.get(cn24_col)) if cn24_col in gg.columns else ""
    ce_older_than_14 = (
        (latest_ce_val_date is not None) and (last_date is not None) and
        ((last_date - latest_ce_val_date) > timedelta(days=14))
    )
    cn24_not_comp = (latest_cn24 != "comp")

    # Guard: if Primary Hold-Up is "CN24 pending clerical support", skip CN24 construction action
    if (
        ce_older_than_14
        and latest_fic_yes
        and cn24_not_comp
        and pri_norm != "cn24 pending clerical support"
    ):
        return RiskEval(
            ACTION_CN24,
            _fmt_mdy(rfc_date) if rfc_date else "",
            _fmt_mdy(latest_ce_val_date),
        )

    # ----------------------- UPDATED case: Job scheduled outside of 2026 -----------------------
    # Only flag when PRY == 2026 AND CE exists AND CE year != 2026,
    # and job is NOT already Commissioned / Installed, Commissioning Not Required.
    if "Project Reporting Year" in gg.columns and latest_ce_val_date is not None:
        completed_stages = {
            "commissioned",
            "installed, commissioning not required",
        }
        if latest_stage not in completed_stages:
            pry_year = _parse_year(latest_row.get("Project Reporting Year"))
            ce_year = latest_ce_val_date.year if latest_ce_val_date else None

            if pry_year == 2026 and ce_year is not None and ce_year != 2026:
                return RiskEval(
                    ACTION_OUTSIDE_2026,
                    _fmt_mdy(rfc_date) if rfc_date else "",
                    _fmt_mdy(latest_ce_val_date),
                )

    # ----------------------- New case 2: Material past due (Device ETA) ------------------
    if pri_norm == "device eta" and "Resolve Date" in gg.columns:
        rd = _parse_date_cell(latest_row.get("Resolve Date"))
        if rd is not None and rd < last_date:
            return RiskEval(
                ACTION_MATERIAL_PAST_DUE,
                _fmt_mdy(rfc_date) if rfc_date else "",
                _fmt_mdy(latest_ce_val_date) if latest_ce_val_date else "",
            )

    return None

def evaluate_group_for_construction(g: pd.DataFrame) -> str | None:
    res = evaluate_group_for_construction_detail(g)
    return res.action if res else None
