# helpers/mwc49_reports/risk_tracker_logic/it_controller.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, datetime, timedelta
import pandas as pd

PENDING_VAL = "it - controller pending"  # casefold compare
ACTION_ITC  = "IT controller past due"

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

class ITCEval(NamedTuple):
    action: str
    hold_up_source: str     # "Primary Hold-Up" or "Secondary Hold-Up"
    resolve_date_str: str   # actual Resolve Date/Resolve Date2 (MDY)

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def evaluate_group_for_it_controller_detail(g: pd.DataFrame, db_max_date: Optional[date] = None,) -> Optional[ITCEval]:
    """
    Shows a row when (based on the LATEST snapshot row):
      Case 1: Primary Hold-Up == 'IT - Controller pending' AND Resolve Date is in the past.
      Case 2: Secondary Hold-Up == 'IT - Controller pending' AND Resolve Date2 is in the past.

    Ignores the (PM#, NOM) combo if:
      - The latest snapshot timestamp is > 20 weeks after 'today' (future data), OR
      - Either Primary/Secondary says 'Job cancelled'/'Job deferred'/'Job hold' (any one).

    Output columns desired:
      - Stakeholder: IT Controller (filled by table builder)
      - Hold-Up: which column triggered (Primary/Secondary)
      - Resolve Date: the actual due date string
      - Action: 'IT - Controller pending'
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    cols_needed = {"Primary Hold-Up", "Secondary Hold-Up", "Resolve Date", "Resolve Date2"}
    if not cols_needed.issubset(set(gg.columns)):
        return None

    latest = gg.iloc[-1]
    latest_ts = latest.get("timestamp_dt")
    last_date = latest_ts.to_pydatetime().date() if pd.notna(latest_ts) else None

    # Guard against obviously future-dated snapshots (> 10 weeks ahead of today)
    today = date.today()
    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None

    # Global ignore flags based on cancellation/deferral/hold
    pri = _norm(latest.get("Primary Hold-Up"))
    sec = _norm(latest.get("Secondary Hold-Up"))
    ignore_tokens = {"job cancelled", "job deferred", "job hold"}
    if any(tok in pri for tok in ignore_tokens) or any(tok in sec for tok in ignore_tokens):
        return None

    # Case 1: Primary pending and Resolve Date in past (to "today")
    if pri == PENDING_VAL:
        due = _parse_date_cell(latest.get("Resolve Date"))
        if due and due < today:
            return ITCEval(
                ACTION_ITC,
                "Primary Hold-Up",
                _fmt_mdy(due),
            )

    # Case 2: Secondary pending and Resolve Date2 in past (to "today")
    if sec == PENDING_VAL:
        due2 = _parse_date_cell(latest.get("Resolve Date2"))
        if due2 and due2 < today:
            return ITCEval(
                ACTION_ITC,
                "Secondary Hold-Up",
                _fmt_mdy(due2),
            )

    return None
