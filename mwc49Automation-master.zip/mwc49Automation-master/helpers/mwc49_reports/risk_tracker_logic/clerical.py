# helpers/mwc49_reports/risk_tracker_logic/clerical.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

PENDING_VAL = "cn24 pending clerical support"    # compare via casefold
ACTION_TXT  = "CN24 pending clerical support"

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

class ClericalEval(NamedTuple):
    action: str  # always ACTION_TXT

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def evaluate_group_for_clerical_detail(g: pd.DataFrame) -> Optional[ClericalEval]:
    """
    Show the (PM#, NOM) combo when, in the LATEST snapshot row:
      - Primary Hold-Up == 'CN24 pending clerical support'  (case-insensitive)

    Ignore the combo when:
      1) The latest snapshot timestamp is >= 20 weeks OLDER than today (i.e., older than 20 weeks),
      2) Either Primary/Secondary contains any of: 'Job cancelled', 'Job deferred', 'Job hold'.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    need = {"Primary Hold-Up", "Secondary Hold-Up"}
    if not need.issubset(set(gg.columns)):
        return None

    latest = gg.iloc[-1]
    latest_ts = latest.get("timestamp_dt")
    latest_date = latest_ts.to_pydatetime().date() if pd.notna(latest_ts) else None

    today = date.today()

    # (1) Ignore if the latest snapshot is 20+ weeks in the past
    if latest_date and (today - latest_date) >= timedelta(weeks=20):
        return None

    # (2) Ignore if cancelled/deferred/hold in either hold-up
    pri = _norm(latest.get("Primary Hold-Up"))
    sec = _norm(latest.get("Secondary Hold-Up"))
    ignore_tokens = ("job cancelled", "job deferred", "job hold")
    if any(tok in pri for tok in ignore_tokens) or any(tok in sec for tok in ignore_tokens):
        return None

    # Trigger if Primary Hold-Up matches target text
    if pri == PENDING_VAL:
        return ClericalEval(ACTION_TXT)

    return None
