# helpers/mwc49_reports/risk_tracker_logic/it.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

ACTION_IT_SURVEY_PAST_DUE = "IT survey past due."
ACTION_IT_COMM_PAST_DUE   = "IT comm support past due."

CASE1_PH = {
    "it - survey wo pending",
    "it - radio type pending",
}
CASE2_PH = {
    "it - field support pending",
    "it - info for scada pending",
}

class RiskEval(NamedTuple):
    action: str
    primary_hold_up: str
    resolve_date_str: str

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def evaluate_group_for_it_detail(g: pd.DataFrame, db_max_date: Optional[date] = None) -> Optional[RiskEval]:
    """
    Most-recent row logic (freshness: same calendar day as today):
      Case 1: Primary Hold-Up ∈ {"IT - Survey WO pending", "IT - Radio type pending"}
              AND Resolve Date is in the past -> ACTION_IT_SURVEY_PAST_DUE
      Case 2: Primary Hold-Up ∈ {"IT - Field support pending", "IT - Info for SCADA pending"}
              AND Resolve Date is in the past -> ACTION_IT_COMM_PAST_DUE

    Sanity:
      • Ignore if latest snapshot is older than 0 days (i.e., date < today).
      • Ignore if Primary/Secondary Hold-Up is Job cancelled / Job deferred / Job hold.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    latest = gg.iloc[-1]
    last_ts = latest["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    # Freshness: must be same calendar day as today
    last_date = last_ts.to_pydatetime().date()
    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None


    if _blocked_by_holdups(latest):
        return None

    ph_raw = latest.get("Primary Hold-Up")
    ph = _norm(ph_raw)
    res_date = _parse_date_cell(latest.get("Resolve Date"))

    # Only consider if Resolve Date exists and is in the past
    if res_date is None or res_date >= date.today():
        return None

    if ph in CASE1_PH:
        return RiskEval(
            action=ACTION_IT_SURVEY_PAST_DUE,
            primary_hold_up=str(ph_raw).strip() if ph_raw is not None else "",
            resolve_date_str=_fmt_mdy(res_date),
        )

    if ph in CASE2_PH:
        return RiskEval(
            action=ACTION_IT_COMM_PAST_DUE,
            primary_hold_up=str(ph_raw).strip() if ph_raw is not None else "",
            resolve_date_str=_fmt_mdy(res_date),
        )

    return None
