# helpers/mwc49_reports/risk_tracker_logic/estimating.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

ACTION_EST_EOD_NEEDED = "Please provide estimating EOD."
ACTION_EST_EOD_PAST_DUE = "Estimating EOD past due."
ACTION_SEND_BACK_TO_EST = "Job needs to go back to estimating."

EST_STAGES = {"estimating", "pre-estimating"}
RD_STAGES = {"NaT",""}

class RiskEval(NamedTuple):
    action: str
    primary_hold_up: str
    stage_of_job: str
    resolve_date_str: str
    ests_planned_out_date_str: str

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def evaluate_group_for_estimating_detail(g: pd.DataFrame, db_max_date: Optional[date] = None) -> Optional[RiskEval]:
    """
    Show when (evaluated on the most-recent row):
      Case 1: Primary Hold-Up == 'Estimating pending' AND Stage ∈ {Estimating, Pre-Estimating}
              AND Resolve Date is blank/null  -> ACTION_EST_EOD_NEEDED.
      Case 2: Stage ∈ {Estimating, Pre-Estimating} AND Primary Hold-Up == 'Estimating pending'
              AND ESTS Planned Out Date is in the past -> ACTION_EST_EOD_PAST_DUE.
      Case 3: Primary Hold-Up == 'Estimating pending' AND Resolve Date blank/null
              AND Stage NOT in {Estimating, Pre-Estimating} -> ACTION_SEND_BACK_TO_EST.

    Sanity:
      - Ignore if latest snapshot is > 1 day older than today.
      - Ignore if Primary/Secondary Hold-Up indicates: Job cancelled / Job deferred / Job hold.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    latest = gg.iloc[-1]
    last_ts = latest["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    # Sanity 1: freshness (≤ 1 day old)
    last_date = last_ts.to_pydatetime().date()
    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None

    # Sanity 2: terminal/cold states
    if _blocked_by_holdups(latest):
        return None

    ph_raw = latest.get("Primary Hold-Up")
    ph = _norm(ph_raw)
    if ph != "estimating pending":
        return None

    stage_raw = latest.get("Stage of Job")
    stage_norm = _norm(stage_raw)

    rd = _parse_date_cell(latest.get("Resolve Date"))
    ests_planned = _parse_date_cell(latest.get("ESTS Planned Out Date"))

    # Case 1
    if stage_norm in EST_STAGES and rd is None:
        return RiskEval(
            action=ACTION_EST_EOD_NEEDED,
            primary_hold_up=str(ph_raw).strip() if ph_raw is not None else "",
            stage_of_job=str(stage_raw).strip() if stage_raw is not None else "",
            resolve_date_str="",  # blank
            ests_planned_out_date_str=_fmt_mdy(ests_planned) if ests_planned else "",
        )

    # Case 2
    if stage_norm in EST_STAGES and ests_planned is not None and ests_planned < date.today():
        return RiskEval(
            action=ACTION_EST_EOD_PAST_DUE,
            primary_hold_up=str(ph_raw).strip() if ph_raw is not None else "",
            stage_of_job=str(stage_raw).strip() if stage_raw is not None else "",
            resolve_date_str=_fmt_mdy(rd) if rd else "",
            ests_planned_out_date_str=_fmt_mdy(ests_planned),
        )

    # Case 3
    if rd in RD_STAGES and stage_norm not in EST_STAGES:
        return RiskEval(
            action=ACTION_SEND_BACK_TO_EST,
            primary_hold_up=str(ph_raw).strip() if ph_raw is not None else "",
            stage_of_job=str(stage_raw).strip() if stage_raw is not None else "",
            resolve_date_str="",  # blank
            ests_planned_out_date_str=_fmt_mdy(ests_planned) if ests_planned else "",
        )

    return None
