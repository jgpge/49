# helpers/mwc49_reports/risk_tracker_logic/dlt.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

ACTION_PRECOMM   = "Pending. DLT to complete pre-comm."
ACTION_SITEVISIT = "Pending load read from DLT."
ACTION_INSTALL   = "Pending installation date from DLT."

class RiskEval(NamedTuple):
    device_type_str: str
    primary_hold_up_str: str
    resolve_date_str: str
    action: str

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def evaluate_group_for_dlt_detail(g: pd.DataFrame, db_max_date: Optional[date] = None) -> Optional[RiskEval]:
    """
    Use ONLY the group's latest row.
    Sanity:
      • Ignore if latest snapshot is > 20 weeks older than TODAY.
      • Ignore if latest Primary/Secondary Hold-Up in {Job cancelled, Job deferred, Job hold}.

    Case 1:
      Primary Hold-Up == "DLT - Pre-comm pending" AND Resolve Date < today -> ACTION_PRECOMM
    Case 2:
      Primary Hold-Up == "DLT - Site visit pending" AND Resolve Date < today -> ACTION_SITEVISIT
    Case 3:
      "Device Type" contains "Controller Only" AND Primary Hold-Up == "Construction pending"
      AND Resolve Date < today -> ACTION_INSTALL
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    latest = gg.iloc[-1]
    last_ts = latest["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    # Sanity 1: latest snapshot must be within 1 day of today
    last_date = last_ts.to_pydatetime().date()
    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None

    # Sanity 2: ignore terminal/blocked statuses
    if _blocked_by_holdups(latest):
        return None

    # Original (display) strings
    dev_disp = str(latest.get("Device Type") or "").strip()
    ph_disp  = str(latest.get("Primary Hold-Up") or "").strip()

    # Normalized for matching
    dev = _norm(dev_disp)
    ph  = _norm(ph_disp)

    res_dt = _parse_date_cell(latest.get("Resolve Date"))
    if res_dt is None or res_dt >= date.today():
        return None  # time-based checks require a past date

    # Case 1: DLT - Pre-comm pending
    if ph == "dlt - pre-comm pending":
        return RiskEval(dev_disp, ph_disp, _fmt_mdy(res_dt), ACTION_PRECOMM)

    # Case 2: DLT - Site visit pending
    if ph == "dlt - site visit pending":
        return RiskEval(dev_disp, ph_disp, _fmt_mdy(res_dt), ACTION_SITEVISIT)

    # Case 3: Controller Only + Construction pending
    if ("controller only" in dev) and (ph == "construction pending"):
        return RiskEval(dev_disp, ph_disp, _fmt_mdy(res_dt), ACTION_INSTALL)

    return None
