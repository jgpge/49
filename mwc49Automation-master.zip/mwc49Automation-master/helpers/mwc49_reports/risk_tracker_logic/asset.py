# helpers/mwc49_reports/risk_tracker_logic/asset.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd

TARGET_VAL = "asset feedback pending"  # case-insensitive target
PH_COL = "Primary Hold-Up"
SH_COL = "Secondary Hold-Up"

# Ignore list (case-insensitive); includes both spellings for cancelled/canceled
IGNORE_VALS = {
    "job cancelled",
    "job canceled",
    "job deferred",
    "job hold",
}

ACTION_ASSET_PENDING = "Asset feedback pending"

class AssetEval(NamedTuple):
    action: str
    days_pending: int  # number of days the asset status has been continuously pending up to the latest snapshot

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _streak_start_date_if_pending(gg: pd.DataFrame, col: str) -> Optional[date]:
    """
    If the LATEST row is pending in `col`, walk backward as long as it's pending,
    and return the calendar date (from timestamp_dt) where the streak started.
    If latest row isn't pending (or col missing), return None.
    """
    if col not in gg.columns or gg.empty:
        return None

    last_idx = len(gg) - 1
    if _norm(gg.iloc[last_idx][col]) != TARGET_VAL:
        return None

    start_idx = last_idx
    for i in range(last_idx, -1, -1):
        if _norm(gg.iloc[i][col]) == TARGET_VAL:
            start_idx = i
        else:
            break

    ts = gg.loc[start_idx, "timestamp_dt"]
    return ts.to_pydatetime().date() if pd.notna(ts) else None

def evaluate_group_for_asset_detail(g: pd.DataFrame, db_max_date: Optional[date] = None) -> Optional[AssetEval]:
    """
    Asset risk rule (latest snapshot only):

    IGNORE if:
      1) The latest snapshot is older than 10 weeks from the reference "today"
         (reference = db_max_date if provided, else real today()).
      2) The latest Primary/Secondary Hold-Up is any of: Job cancelled/canceled, Job deferred, Job hold.

    Otherwise:
      - If (Primary Hold-Up) OR (Secondary Hold-Up) == 'Asset feedback pending' on the latest row,
        include with:
          Action          = 'Asset feedback pending'
          Days in Pending = days since the start of the continuous 'Asset feedback pending' streak
                           (compute for PH and SH separately if both pending; take MAX).
      - Else return None.
    """
    cols_needed = {PH_COL, SH_COL, "timestamp"}
    if not cols_needed.issubset(set(g.columns)):
        return None

    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    # Latest snapshot date (calendar day)
    last_row = gg.iloc[-1]
    last_ts = last_row["timestamp_dt"]
    last_date = last_ts.to_pydatetime().date() if pd.notna(last_ts) else None
    if last_date is None:
        return None

    # ---- Freshness guard (NO subtraction with None)
    if db_max_date is not None:
        if last_date != db_max_date:
            return None
    else:
        # fallback: require "today"
        if (db_max_date - last_date) > timedelta(days=0):
            return None

    # Latest hold-up values
    latest_ph = _norm(last_row.get(PH_COL))
    latest_sh = _norm(last_row.get(SH_COL))

    # --- Ignore rule 2: cancelled/deferred/hold at latest snapshot
    if latest_ph in IGNORE_VALS or latest_sh in IGNORE_VALS:
        return None

    # If neither is currently "asset feedback pending", no row
    if latest_ph != TARGET_VAL and latest_sh != TARGET_VAL:
        return None

    # Compute pending streak(s) and take max
    days_candidates = []

    ph_start = _streak_start_date_if_pending(gg, PH_COL)
    if ph_start is not None:
        days_candidates.append((last_date - ph_start).days)

    sh_start = _streak_start_date_if_pending(gg, SH_COL)
    if sh_start is not None:
        days_candidates.append((last_date - sh_start).days)

    if not days_candidates:
        return None

    return AssetEval(
        action=ACTION_ASSET_PENDING,
        days_pending=max(days_candidates),
    )
