# helpers/mwc49_reports/risk_tracker_logic/dependencies.py
from __future__ import annotations
from typing import NamedTuple, Optional
from datetime import date, timedelta
import pandas as pd
import numpy as np

# ---- Actions (messages) ----
ACTION_EOD_MISSING = "Please provide dependency EOD for open dependencies."
ACTION_EOD_PAST = "EOD in the past. Please provide updated EOD for open dependencies."
ACTION_EOD_90_AFTER_ESTS = "Dependency EOD is 90+ days after ESTS Actual Out Date. Please pull job in."
ACTION_EOD_DECEMBER = "Dependency EOD in December. Please escalate."
ACTION_EOD_2027 = "Dependency EOD is in 2027. Please escalate."

class RiskEval(NamedTuple):
    action: str
    open_dep_str: str   # <-- NEW: the latest 'Open Dependencies' cell as-is (string)
    dep_eod_str: str    # latest "Dependency Estimated Out Date" (MDY) or ""

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _open_deps_is_meaningful(v) -> bool:
    if v is None:
        return False
    s = str(v).strip()
    if s == "":
        return False
    n = s.casefold()
    # treat these as "not open"
    return n not in {"project managed", "in estimating", "none", "null", "nan", np.nan}

def _blocked_by_holdups(latest_row: pd.Series) -> bool:
    ph = _norm(latest_row.get("Primary Hold-Up"))
    sh = _norm(latest_row.get("Secondary Hold-Up"))
    blocked_vals = {"job cancelled", "job deferred", "job hold", "project managed"}
    return (ph in blocked_vals) or (sh in blocked_vals)

def evaluate_group_for_dependencies_detail(
    g: pd.DataFrame,
    db_max_date: Optional[date] = None,  # DB-wide max DATE (not timestamp)
) -> Optional[RiskEval]:
    """
    Dependencies risk uses ONLY the group's MOST RECENT row (on the DB-wide max DATE).

    Sanity (per-group):
      • Latest row's timestamp DATE must equal db_max_date; else ignore.
      • Ignore if latest Primary/Secondary Hold-Up ∈ {Job cancelled, Job deferred, Job hold}.

    Case 1:
      Open Dependencies is meaningful AND Dependency Estimated Out Date is missing -> ACTION_EOD_MISSING.

    Case 2:
      Open Dependencies is meaningful AND EOD exists AND EOD < today -> ACTION_EOD_PAST.

    Case 3:
      Open Dependencies is meaningful AND
      ESTS Actual Out Date exists AND EOD exists AND (ESTS Actual + 90 days) < EOD -> ACTION_EOD_90_AFTER_ESTS.

    Case 4:
      Open Dependencies is meaningful AND
      EOD in Dec 2025 -> ACTION_EOD_DECEMBER.
      EOD in any month of 2027 -> ACTION_EOD_2027.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return None

    # Restrict to rows on the DB-wide max DATE (not time), then take the latest of that day
    if db_max_date is not None:
        gg_same_day = gg[gg["timestamp_dt"].dt.date == db_max_date]
        if gg_same_day.empty:
            return None
        latest = gg_same_day.iloc[-1]
    else:
        latest = gg.iloc[-1]

    last_ts = latest["timestamp_dt"]
    if pd.isna(last_ts):
        return None

    # Skip blocked by terminal/cold hold-ups
    if _blocked_by_holdups(latest):
        return None

    open_deps_val = latest.get("Open Dependencies")
    open_dep_str = "" if (open_deps_val is None or (isinstance(open_deps_val, float) and pd.isna(open_deps_val))) else str(open_deps_val).strip()
    is_meaningful = _open_deps_is_meaningful(open_deps_val)

    dep_eod = _parse_date_cell(latest.get("Dependency Estimated Out Date"))
    ests_actual = _parse_date_cell(latest.get("ESTS Actual Out Date"))

    # Case 1
    if is_meaningful and dep_eod is None:
        return RiskEval(ACTION_EOD_MISSING, open_dep_str, "")

    # Case 2
    today = date.today()
    if is_meaningful and (dep_eod is not None) and (dep_eod < today):
        return RiskEval(ACTION_EOD_PAST, open_dep_str, _fmt_mdy(dep_eod))

    # Case 3
    if is_meaningful and (ests_actual is not None) and (dep_eod is not None):
        if ests_actual + timedelta(days=90) < dep_eod:
            return RiskEval(ACTION_EOD_90_AFTER_ESTS, open_dep_str, _fmt_mdy(dep_eod))

    # Case 4
    if is_meaningful and (dep_eod is not None):
        if dep_eod.year == 2025 and dep_eod.month == 12:
            return RiskEval(ACTION_EOD_DECEMBER, open_dep_str, _fmt_mdy(dep_eod))
        if dep_eod.year == 2027:
            return RiskEval(ACTION_EOD_2027, open_dep_str, _fmt_mdy(dep_eod))

    return None
