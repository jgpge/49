# helpers/mwc49_reports/stakeholder_holdup.py
from __future__ import annotations
from typing import List, Tuple
import pandas as pd

from .common_helpers import (
    STAKEHOLDER_ALL_LABEL,
    stakeholder_from_phu,   # <-- we created this earlier
)

def make_stakeholder_holdup_table(
    df_window: pd.DataFrame,
    selected_stakeholder: str,
    threshold_days: int,
) -> Tuple[List[str], List[List[str]], int]:
    """
    CURRENT Stakeholder Holdup
    - Show ONLY PMs whose *latest* row in the window still has a mappable holdup
      (i.e. the job is STILL in that holdup as of the 'To' date).
    - If the latest row does NOT map to a stakeholder -> skip that PM.
    - Days are still computed by walking backward as before.
    """
    total_raw_rows = len(df_window)

    columns = [
        "PM #",
        "New Operating Number",
        "Device Type",  # NEW
        "Current Mat",
        "Program Name",
        "Current Primary Hold-Up",
        "Days in Current Primary Hold-Up",
        "Stakeholder",
        "Days with Stakeholder",
    ]

    if df_window.empty:
        return columns, [], total_raw_rows

    df = df_window.copy()

    # normalize/core columns
    df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp_dt"])
    df["Primary Hold-Up"] = df["Primary Hold-Up"].astype(str).str.strip()
    df["PM #"] = df["PM #"].astype(str).str.strip()
    df["New Operating Number"] = df["New Operating Number"].astype(str).str.strip()

    if "Device Type" not in df.columns:
        df["Device Type"] = ""  # NEW (robust if column missing)

    if "Current Mat" not in df.columns:
        df["Current Mat"] = ""
    if "Program Name" not in df.columns:
        df["Program Name"] = ""
    if "Resolve Date" not in df.columns:
        df["Resolve Date"] = ""

    # sort so that "latest in window" is the last row per PM
    df = df.sort_values(["PM #", "timestamp_dt"], ascending=[True, True])

    rows: List[List[str]] = []
    sel = (selected_stakeholder or "").strip()

    for pm, g in df.groupby("PM #", sort=False):
        g = g.reset_index(drop=True)

        # latest snapshot in window
        last_row = g.iloc[-1]
        curr_phu = str(last_row["Primary Hold-Up"])
        curr_resolve = str(last_row.get("Resolve Date", "") or "")
        curr_stk = stakeholder_from_phu(curr_phu, curr_resolve)

        # if no stakeholder on the *latest* row -> this PM is currently NOT on hold -> skip
        if not curr_stk:
            continue

        # stakeholder filter (only compare after we know it’s current)
        if sel and sel != STAKEHOLDER_ALL_LABEL and curr_stk != sel:
            continue

        # --- Days in Current Primary Hold-Up (walk backward while PHU stays the same)
        phu_run_start = len(g) - 1
        for i in range(len(g) - 2, -1, -1):
            prev_phu = str(g.loc[i, "Primary Hold-Up"])
            if prev_phu != curr_phu:
                break
            phu_run_start = i
        phu_start_ts = g.loc[phu_run_start, "timestamp_dt"]
        end_ts = g.loc[len(g) - 1, "timestamp_dt"]
        days_in_current_phu = max(0, (end_ts.date() - phu_start_ts.date()).days)

        # --- Days with Stakeholder (walk backward while mapped stakeholder stays the same)
        stk_run_start = len(g) - 1
        for i in range(len(g) - 2, -1, -1):
            phu_i = str(g.loc[i, "Primary Hold-Up"])
            resolve_i = str(g.loc[i].get("Resolve Date", "") or "")
            stk_i = stakeholder_from_phu(phu_i, resolve_i)
            if stk_i != curr_stk:
                break
            stk_run_start = i
        stk_start_ts = g.loc[stk_run_start, "timestamp_dt"]
        days_with_stk = max(0, (end_ts.date() - stk_start_ts.date()).days)

        # threshold on "days with stakeholder"
        if days_with_stk < max(0, int(threshold_days or 0)):
            continue

        nom = last_row.get("New Operating Number", "") or ""
        dev = last_row.get("Device Type", "") or ""  # NEW
        mat = last_row.get("Current Mat", "") or ""
        prog = last_row.get("Program Name", "") or ""

        rows.append([
            pm,
            nom,
            dev if str(dev).strip() else "-",  # NEW
            mat,
            prog,
            curr_phu,
            f"{days_in_current_phu} days",
            curr_stk,
            f"{days_with_stk} days",
        ])

    return columns, rows, total_raw_rows
