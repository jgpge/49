from __future__ import annotations
from typing import List, Optional
import pandas as pd

from .common import (
    Result,
    fmt_date_mdy,  # date -> "MM/DD/YYYY" or "-"
)

NAME = "Asset"

EXTRA_COLS: List[str] = [
    "Asset Start Date",
    "Asset End Date",
]

# Primary Hold-Up values that map to Asset (case-insensitive, trimmed)
_ASSET_PHU_VALUES = {
    "pa pending",
    "asset feedback pending",
    "rescope pending",
}

def _norm(s) -> str:
    return str(s).strip().casefold()

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Sum total days while Primary Hold-Up is one of:
      - "PA pending"
      - "Asset feedback pending"
      - "Rescope pending"

    We only count fully-bounded segments:
      enter = transition from non-asset PHU -> asset PHU
      leave = next transition from asset PHU -> non-asset PHU

    Edge rules -> "Not Enough Data":
      - If the oldest row is already in an asset PHU (segment may have started earlier)
      - If the latest row is still in an asset PHU (segment may be ongoing)
      - If no bounded segments exist
    """

    if g.empty or "Primary Hold-Up" not in g.columns:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Ensure we have and use timestamp_dt sorted ascending
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    # Determine whether first/last rows are inside asset state
    first_is_asset = _norm(gg.loc[0, "Primary Hold-Up"]) in _ASSET_PHU_VALUES
    last_is_asset  = _norm(gg.loc[len(gg) - 1, "Primary Hold-Up"]) in _ASSET_PHU_VALUES

    # Build segments by walking transitions
    in_segment = False
    seg_start_date: Optional[pd.Timestamp.date] = None

    segments: List[tuple[pd.Timestamp.date, pd.Timestamp.date]] = []

    for i in range(len(gg)):
        row = gg.loc[i]
        phu_is_asset = _norm(row.get("Primary Hold-Up")) in _ASSET_PHU_VALUES
        ts = row.get("timestamp_dt")
        if pd.isna(ts):
            continue
        day = ts.to_pydatetime().date()

        if phu_is_asset and not in_segment:
            # entering asset state
            in_segment = True
            seg_start_date = day
        elif (not phu_is_asset) and in_segment:
            # leaving asset state -> close segment
            if seg_start_date is not None:
                segments.append((seg_start_date, day))
            in_segment = False
            seg_start_date = None

    # If we ended still "in_segment", then it's open-ended
    if in_segment:
        last_is_asset = True  # reinforce rule

    # Edge ambiguity -> Not Enough Data
    if first_is_asset or last_is_asset:
        return Result(
            extra_values=[fmt_date_mdy(segments[0][0]) if segments else "-", 
                          fmt_date_mdy(segments[-1][1]) if segments else "-"],
            holdup_value="Not Enough Data",
        )

    if not segments:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Sum bounded segments in whole days (end - start)
    total_days = 0
    for s, e in segments:
        d = (e - s).days
        if d > 0:
            total_days += d

    if total_days <= 0:
        return Result(
            extra_values=[fmt_date_mdy(segments[0][0]), fmt_date_mdy(segments[-1][1])],
            holdup_value="Not Enough Data",
        )

    # First enter date; last leave date
    first_start = segments[0][0]
    last_end    = segments[-1][1]

    return Result(
        extra_values=[fmt_date_mdy(first_start), fmt_date_mdy(last_end)],
        holdup_value=f"{total_days} days",
    )
