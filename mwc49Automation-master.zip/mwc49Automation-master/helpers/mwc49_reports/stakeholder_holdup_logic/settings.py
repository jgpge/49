from __future__ import annotations
from typing import List
import pandas as pd
from datetime import date

from .common import (
    Result,
    first_any_date_in_col,  # parses many formats & Excel serials -> date
    fmt_date_mdy,           # date -> "MM/DD/YYYY" or "-"
)

NAME = "Settings"

_MIN_START_DATE = date(2026, 1, 2)

# These will show as columns before the holdup column
EXTRA_COLS: List[str] = [
    "Settings Requested Date",
    "Settings Received Date",
]

_COL_REQ = "Settings Requested Date"
_COL_REC = "Settings Received Date"

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start  = first actual calendar date value found in 'Settings Requested Date'
             (cell value, not the timestamp)
    End    = first actual calendar date value found in 'Settings Received Date'
             (cell value, not the timestamp)
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start
    """
    if g.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    start_date = first_any_date_in_col(g, _COL_REQ)
    end_date   = first_any_date_in_col(g, _COL_REC)

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
