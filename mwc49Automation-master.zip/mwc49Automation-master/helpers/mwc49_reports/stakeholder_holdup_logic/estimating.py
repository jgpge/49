from __future__ import annotations
from typing import List
import pandas as pd

from .common import (
    Result,
    fmt_date_mdy,  # date -> "MM/DD/YYYY" or "-"
)

NAME = "Estimating"

EXTRA_COLS: List[str] = [
    "Estimating Start Date",
    "Estimating End Date",
]

# Primary Hold-Up values that map to Estimating (case-insensitive, trimmed)
_ESTIMATING_PHU_VALUES = {
    "estimating pending",
    "veg management pending",
    "estimating - scope clarification",
}

def _norm(s) -> str:
    return str(s).strip().casefold()

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Sum total days where Primary Hold-Up ∈ _ESTIMATING_PHU_VALUES.
    Only count fully-bounded segments:
      transition into set  -> transition out of set.

    Return "Not Enough Data" if:
      - the oldest row is already in Estimating PHU (segment may have started earlier), or
      - the latest row is still in Estimating PHU (segment may be ongoing), or
      - no bounded segments are found.
    """
    if g.empty or "Primary Hold-Up" not in g.columns:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # ensure sorted by timestamp_dt ASC
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    first_is_estim = _norm(gg.loc[0, "Primary Hold-Up"]) in _ESTIMATING_PHU_VALUES
    last_is_estim  = _norm(gg.loc[len(gg) - 1, "Primary Hold-Up"]) in _ESTIMATING_PHU_VALUES

    in_segment = False
    seg_start = None
    segments: List[tuple[pd.Timestamp.date, pd.Timestamp.date]] = []

    for i in range(len(gg)):
        row = gg.loc[i]
        is_estim = _norm(row.get("Primary Hold-Up")) in _ESTIMATING_PHU_VALUES
        ts = row.get("timestamp_dt")
        if pd.isna(ts):
            continue
        day = ts.to_pydatetime().date()

        if is_estim and not in_segment:
            in_segment = True
            seg_start = day
        elif (not is_estim) and in_segment:
            if seg_start is not None:
                segments.append((seg_start, day))
            in_segment = False
            seg_start = None

    # open tail → ambiguous
    if in_segment:
        last_is_estim = True

    if first_is_estim or last_is_estim:
        # ambiguous edges -> Not Enough Data
        start_disp = fmt_date_mdy(segments[0][0]) if segments else "-"
        end_disp   = fmt_date_mdy(segments[-1][1]) if segments else "-"
        return Result(extra_values=[start_disp, end_disp], holdup_value="Not Enough Data")

    if not segments:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    total_days = 0
    for s, e in segments:
        d = (e - s).days
        if d > 0:
            total_days += d

    if total_days <= 0:
        return Result(
            extra_values=[fmt_date_mdy(segments[0][0]), fmt_date_mdy(segments[-1][1])],
            holdup_value="Not Enough Data",
        )

    first_start = segments[0][0]
    last_end    = segments[-1][1]

    return Result(
        extra_values=[fmt_date_mdy(first_start), fmt_date_mdy(last_end)],
        holdup_value=f"{total_days} days",
    )
