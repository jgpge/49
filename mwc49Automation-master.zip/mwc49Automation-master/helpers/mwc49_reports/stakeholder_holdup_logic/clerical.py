# helpers/mwc49_reports/stakeholder_holdup_logic/clerical.py
from __future__ import annotations
import pandas as pd

from .common import (
    Result,
    fmt_date_mdy,
)

NAME = "Clerical"

# Show these two columns before the holdup column
EXTRA_COLS = [
    "Clerical Start Date",
    "Clerical End Date",
]

_COL_PHU = "Primary Hold-Up"
_COL_RESOLVE = "Resolve Date"


def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""


def _is_clerical_row(row) -> bool:
    """
    A PM# is with Clerical if either:
      1) Primary Hold-Up == "CN24 pending" AND Resolve Date == "Clerical Support"
      2) Primary Hold-Up == "CN24 pending clerical support"
    (case-insensitive, trimmed)
    """
    phu = _norm(row.get(_COL_PHU))
    res = _norm(row.get(_COL_RESOLVE))
    return (
        (phu == "cn24 pending" and res == "clerical support")
        or (phu == "cn24 pending clerical support")
    )


def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)


def _first_ts_date_where(g: pd.DataFrame) -> pd.Timestamp.date | None:
    if g.empty:
        return None
    for _, row in g.iterrows():
        if _is_clerical_row(row):
            ts = row.get("timestamp_dt")
            if pd.notna(ts):
                return ts.to_pydatetime().date()
    return None


def _last_ts_date_where(g: pd.DataFrame) -> pd.Timestamp.date | None:
    if g.empty:
        return None
    # Fast path: boolean mask, then take last True index
    mask = g.apply(_is_clerical_row, axis=1)
    if not mask.any():
        return None
    idx = mask[mask].index[-1]
    ts = g.loc[idx, "timestamp_dt"]
    if pd.isna(ts):
        return None
    return ts.to_pydatetime().date()


def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start = timestamp date of the FIRST row where the 'Clerical' condition is true.
    End   = timestamp date of the LAST row where the 'Clerical' condition is true.
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty or (_COL_PHU not in gg.columns) or (_COL_RESOLVE not in gg.columns):
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    start_date = _first_ts_date_where(gg)
    end_date   = _last_ts_date_where(gg)

    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
