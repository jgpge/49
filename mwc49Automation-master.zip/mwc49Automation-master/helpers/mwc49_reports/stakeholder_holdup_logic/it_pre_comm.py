from __future__ import annotations
from typing import List
import pandas as pd
from datetime import date

from .common import (
    Result,
    first_any_date_in_col,  # robust: parses many formats & Excel serials -> date
    fmt_date_mdy,           # date -> "MM/DD/YYYY" or "-"
)

NAME = "IT Pre-comm"

EXTRA_COLS: List[str] = [
    "Comm WO Request Date",
    "Controller Delivered to DLT Date",
]

_COL_REQ = "Comm WO Request Date"
_COL_DEL = "Controller Delivered to DLT Date"
_MIN_START_DATE = date(2026, 1, 2)

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start  = first actual calendar date value in 'Comm WO Request Date'
    End    = first actual calendar date value in 'Controller Delivered to DLT Date'
    (Use the cell values themselves, not the timestamps; ignore non-date text.)
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start
    """
    if g.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    start_date = first_any_date_in_col(g, _COL_REQ)
    end_date   = first_any_date_in_col(g, _COL_DEL)

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
