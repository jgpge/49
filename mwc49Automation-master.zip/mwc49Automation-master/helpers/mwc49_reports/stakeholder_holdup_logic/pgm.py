from __future__ import annotations
from typing import List, Tuple
import pandas as pd

from .common import Result, fmt_date_mdy

NAME = "PGM"

EXTRA_COLS: List[str] = [
    "PGM Start Date",
    "PGM End Date",
]

_PHU_VALUES = {
    "wpd update for permit",
    "resource assignment pending",
}

def _norm(s) -> str:
    return str(s).strip().casefold()

def compute_for_group(g: pd.DataFrame) -> Result:
    if g.empty or "Primary Hold-Up" not in g.columns:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    first_in = _norm(gg.loc[0, "Primary Hold-Up"]) in _PHU_VALUES
    last_in  = _norm(gg.loc[len(gg) - 1, "Primary Hold-Up"]) in _PHU_VALUES

    in_segment = False
    seg_start = None
    segments: List[Tuple[pd.Timestamp.date, pd.Timestamp.date]] = []

    for _, row in gg.iterrows():
        is_in = _norm(row.get("Primary Hold-Up")) in _PHU_VALUES
        ts = row.get("timestamp_dt")
        if pd.isna(ts):
            continue
        d = ts.to_pydatetime().date()

        if is_in and not in_segment:
            in_segment = True
            seg_start = d
        elif (not is_in) and in_segment:
            if seg_start is not None:
                segments.append((seg_start, d))
            in_segment = False
            seg_start = None

    if in_segment:
        last_in = True

    if first_in or last_in or not segments:
        start_disp = fmt_date_mdy(segments[0][0]) if segments else "-"
        end_disp   = fmt_date_mdy(segments[-1][1]) if segments else "-"
        return Result(extra_values=[start_disp, end_disp], holdup_value="Not Enough Data")

    total_days = sum(max(0, (e - s).days) for s, e in segments)
    first_start = segments[0][0]
    last_end    = segments[-1][1]

    return Result(
        extra_values=[fmt_date_mdy(first_start), fmt_date_mdy(last_end)],
        holdup_value=(f"{total_days} days" if total_days > 0 else "Not Enough Data"),
    )
