# helpers/mwc49_reports/stakeholder_holdup_logic/construction_pre_comm.py
from __future__ import annotations
from typing import List, Optional
import pandas as pd
from datetime import date

from .common import (
    Result,
    first_any_date_in_col,
    fmt_date_mdy,
)

_MIN_START_DATE = date(2026, 1, 2)

NAME = "Construction Pre-comm"

# Shown before the holdup column (unchanged)
EXTRA_COLS: List[str] = [
    "Material Requested Date",
    "Material Delivered Date",
]

_COL_REQ = "Material Requested Date"
_COL_DEL = "Material Delivered Date"
_COL_CTRL_DLT = "Controller Delivered to DLT Date"  # used for end-date candidate (not displayed)

def _max_date(d1, d2):
    """Return the later of two optional dates, or the one that exists, or None if both missing."""
    if d1 is None and d2 is None:
        return None
    if d1 is None:
        return d2
    if d2 is None:
        return d1
    return max(d1, d2)

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start  = first actual calendar date in 'Material Requested Date' (cell value)
    End    = MAX( first date in 'Material Delivered Date' (cell value),
                  first date in 'Controller Delivered to DLT Date' (cell value) )
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start
    """
    if g.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Start (cell value, robust)
    start_date = first_any_date_in_col(g, _COL_REQ)

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    # End candidates (cell values, robust)
    end_delivered = first_any_date_in_col(g, _COL_DEL)
    end_controller = first_any_date_in_col(g, _COL_CTRL_DLT)

    end_date = _max_date(end_delivered, end_controller)

    # Displayed extra columns remain the same (requested originally)
    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_delivered if end_date == end_delivered else end_controller if end_date is not None else None)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
