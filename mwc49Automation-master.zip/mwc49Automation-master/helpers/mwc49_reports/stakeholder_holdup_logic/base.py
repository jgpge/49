from __future__ import annotations
from dataclasses import dataclass
from typing import List, Protocol
import pandas as pd

@dataclass
class StakeholderAccResult:
    """
    Return value for a single PM group:
    - extra_values: strings to print in the stakeholder-specific extra columns (same order as EXTRA_COLS)
    - holdup_value: the final holdup cell text (e.g., '23 days' or 'Not Enough Data')
    """
    extra_values: List[str]
    holdup_value: str

class StakeholderAccLogic(Protocol):
    """
    Stakeholder logic must provide:
    - STAKEHOLDER_NAME: str (display in UI/dispatcher key)
    - EXTRA_COLS: List[str] (column headers inserted before the holdup cell)
    - compute_for_group(g: pd.DataFrame) -> StakeholderAccResult
    """
    STAKEHOLDER_NAME: str
    EXTRA_COLS: List[str]

    def compute_for_group(self, g: pd.DataFrame) -> StakeholderAccResult: ...
