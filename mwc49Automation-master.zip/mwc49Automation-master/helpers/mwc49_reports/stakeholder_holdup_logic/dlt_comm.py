# helpers/mwc49_reports/stakeholder_holdup_logic/dlt_comm.py
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Optional, List

import pandas as pd
from datetime import date

from .common import (
    Result,
    parse_any_to_date,
    first_ts_date_where,
    fmt_date_mdy,
)

NAME = "DLT Comm"

# columns to show before the holdup column
EXTRA_COLS: List[str] = [
    "Field Install Complete Date",
    "SCADA ADMS Test Date",
]

_FIELD_INSTALL_COL = "Field Install Completed (Yes)"
_ADMS_TEST_COL = "SCADA ADMS Test Date"

# RCC DB + table/column settings
_RCC_DB_FILENAME = "RCC.db"
_RCC_DB_DIRNAME = "data"
_MWC49_TABLE = "mwc49"
_TS_COL = "timestamp"

# Module-level cache so we only hit SQLite once per process
_LATEST_DB_DATE: Optional[date] = None
_LATEST_DB_DATE_LOADED: bool = False

_MIN_START_DATE = date(2026, 1, 2)

def _is_yes(val) -> bool:
    return str(val).strip().lower() == "yes"


def _find_rcc_db_path() -> Optional[str]:
    """
    Try to locate data/RCC.db by walking upward from this file's directory.
    Returns absolute path if found, else None.
    """
    here = Path(__file__).resolve()
    for parent in [here.parent, *here.parents]:
        candidate = parent / _RCC_DB_DIRNAME / _RCC_DB_FILENAME
        if candidate.is_file():
            return str(candidate)
    return None


def _load_latest_database_date() -> Optional[date]:
    """
    Reads MAX(timestamp) from mwc49 table in data/RCC.db and returns it as a date (YYYY-MM-DD).
    Returns None if DB/table/column missing or no valid timestamps.
    """
    db_path = _find_rcc_db_path()
    if not db_path:
        return None

    try:
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            cur.execute(f'SELECT MAX("{_TS_COL}") FROM "{_MWC49_TABLE}"')
            row = cur.fetchone()
    except Exception:
        return None

    if not row:
        return None

    max_ts = row[0]
    if max_ts is None:
        return None

    try:
        dt = pd.to_datetime(max_ts, errors="coerce")
        if pd.isna(dt):
            return None
        return dt.to_pydatetime().date()
    except Exception:
        return None


def latest_database_date() -> Optional[date]:
    """
    Public accessor (cached) for latest timestamp date in RCC.db::mwc49.timestamp.
    """
    global _LATEST_DB_DATE, _LATEST_DB_DATE_LOADED
    if not _LATEST_DB_DATE_LOADED:
        _LATEST_DB_DATE = _load_latest_database_date()
        _LATEST_DB_DATE_LOADED = True
    return _LATEST_DB_DATE


def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start  = timestamp date when Field Install Completed (Yes) first becomes 'Yes' (case-insensitive)
    End    = first non-empty *value* in 'SCADA ADMS Test Date' (format-agnostic)
    Holdup = (End - Start).days, else 'Not Enough Data'

    NEW GUARD:
      - Compute latest_database_date = MAX(date(timestamp)) from RCC.db::mwc49.timestamp
      - Compute group_latest_date    = MAX(date(timestamp_dt)) within this group
      - If group_latest_date != latest_database_date -> return Not Enough Data
    """
    # Build/sort timestamp_dt
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
        gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)
    else:
        gg = g.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # ---- NEW: stale-group guard vs latest DB date ----
    db_latest = latest_database_date()
    try:
        grp_latest_ts = gg["timestamp_dt"].max()
        grp_latest = grp_latest_ts.to_pydatetime().date() if pd.notna(grp_latest_ts) else None
    except Exception:
        grp_latest = None

    # If we can't determine either date, or they don't match -> Not Enough Data
    if db_latest is None or grp_latest is None or grp_latest != db_latest:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Start: first timestamp where Field Install Completed == 'Yes'
    start_d: Optional[date] = first_ts_date_where(gg, _FIELD_INSTALL_COL, _is_yes)

    if start_d is not None:
        start_d = max(start_d, _MIN_START_DATE)

    # End: first actual date value present in SCADA ADMS Test Date
    end_d: Optional[date] = None
    if _ADMS_TEST_COL in gg.columns:
        for v in gg[_ADMS_TEST_COL].tolist():
            d = parse_any_to_date(v)
            if d is not None:
                end_d = d
                break

    start_str = fmt_date_mdy(start_d)
    end_str = fmt_date_mdy(end_d)

    if start_d is None or end_d is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_d - start_d).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
