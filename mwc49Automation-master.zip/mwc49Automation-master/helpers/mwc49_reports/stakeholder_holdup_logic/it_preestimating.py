# helpers/mwc49_reports/stakeholder_holdup_logic/it_preestimating.py
from __future__ import annotations
from typing import List, Optional
import pandas as pd

from .base import StakeholderAccResult
from .common import (
    first_any_date_in_col,
    first_ts_date_where,
    fmt_date_mdy,
)

STAKEHOLDER_NAME = "IT Pre-estimating"
EXTRA_COLS: List[str] = [
    "IT Survey Request Date",
    "IT Survey Site Status Pass Date",
]

_COL_REQ = "IT Survey Request Date"
_COL_STATUS = "IT Survey Site Status (Pass/Fail)"
_COL_WO = "IT Survey WO"  # fallback source for START (timestamp where first value starts with 'WO')

def _is_pass(val) -> bool:
    return str(val).strip().lower() == "pass"

def _starts_with_wo(val) -> bool:
    s = str(val).strip().upper()
    return s.startswith("WO")

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def compute_for_group(g: pd.DataFrame) -> StakeholderAccResult:
    """
    Start  (primary)  = earliest actual date found in 'IT Survey Request Date' (cell value; format-agnostic)
    Start  (fallback) = calendar date of the FIRST timestamp where 'IT Survey WO' starts with 'WO'
    End               = calendar date of the FIRST timestamp where 'IT Survey Site Status (Pass/Fail)' == 'Pass'
    Holdup            = (End - Start).days
    Special rule      = if the first 'Pass' occurs on the oldest timestamp date we have for this PM → "Not Enough Data"
    Fallback usage    = If Start is missing OR Start > End, try the WO-based start. If still invalid → "Not Enough Data".
    """
    if g is None or g.empty:
        return StakeholderAccResult(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Oldest available data date (string-sliced, per your working fix)
    try:
        oldest_ts = g["timestamp"].min()
        oldest_date = str(oldest_ts)[:10]
    except Exception:
        oldest_date = ""

    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return StakeholderAccResult(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # End date: first time Site Status says "Pass" (from timestamp's calendar date)
    end_date = first_ts_date_where(gg, _COL_STATUS, _is_pass)

    # Start date (primary): earliest actual value in IT Survey Request Date (cell value)
    start_date: Optional[pd.Timestamp.date] = first_any_date_in_col(gg, _COL_REQ)

    # If primary start missing OR invalid (after End), try fallback: first timestamp where IT Survey WO starts with 'WO'
    def _maybe_use_fallback(current_start):
        if _COL_WO not in gg.columns:
            return current_start
        wo_start = first_ts_date_where(gg, _COL_WO, _starts_with_wo)
        # only use if it exists
        return wo_start if wo_start is not None else current_start

    # Attempt fallback when:
    #  - Start is None, or
    #  - End exists and Start > End (negative delta)
    if start_date is None:
        start_date = _maybe_use_fallback(start_date)
    elif end_date is not None and (end_date - start_date).days < 0:
        start_date = _maybe_use_fallback(start_date)

    # Format columns for display
    req_str = fmt_date_mdy(start_date)
    pass_str = fmt_date_mdy(end_date)

    # Final validity checks
    if start_date is None or end_date is None:
        return StakeholderAccResult([req_str, pass_str], "Not Enough Data")

    # If the found Pass date equals the oldest data date, we lack pre-Pass history
    if str(end_date) == str(oldest_date):
        return StakeholderAccResult([req_str, pass_str], "Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return StakeholderAccResult([req_str, pass_str], "Not Enough Data")

    return StakeholderAccResult([req_str, pass_str], f"{delta} days")


# Expose a module-like object with required attributes for the registry
class MODULE:
    STAKEHOLDER_NAME = STAKEHOLDER_NAME
    EXTRA_COLS = EXTRA_COLS
    compute_for_group = staticmethod(compute_for_group)
