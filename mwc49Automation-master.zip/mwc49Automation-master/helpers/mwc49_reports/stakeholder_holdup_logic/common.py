from __future__ import annotations
from datetime import datetime, date
from typing import Optional, List
import math
import pandas as pd

from ..common_helpers import fmt_mdy
from ..stakeholder_holdup_lifecycle import device_category_from_type

from dataclasses import dataclass  # <-- ADD THIS

# === NEW: result container each stakeholder returns ===
@dataclass(frozen=True)
class Result:
    extra_values: List[str]   # columns specific to that stakeholder (e.g., start/end display strings)
    holdup_value: str         # e.g., "12 days" or "Not Enough Data"

# -------- robust date parsing ----------
def parse_any_to_date(val) -> Optional[date]:
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    if isinstance(val, pd.Timestamp):
        if pd.isna(val):
            return None
        return date(val.year, val.month, val.day)
    from datetime import datetime as _dt
    if isinstance(val, _dt):
        return date(val.year, val.month, val.day)
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        try:
            dt = pd.to_datetime(val, unit="d", origin="1899-12-30", errors="coerce")
            if pd.isna(dt):
                dt = pd.to_datetime(val, unit="s", errors="coerce")
            if pd.isna(dt):
                return None
            return date(dt.year, dt.month, dt.day)
        except Exception:
            pass
    s = str(val).strip()
    if s == "" or s.lower() in ("nan", "none", "nat"):
        return None
    try:
        dt = pd.to_datetime(s, errors="coerce", infer_datetime_format=True)
        if pd.isna(dt):
            return None
        return date(dt.year, dt.month, dt.day)
    except Exception:
        return None

def first_any_date_in_col(g: pd.DataFrame, colname: str) -> Optional[date]:
    if colname not in g.columns:
        return None
    vals = []
    for v in g[colname].tolist():
        d = parse_any_to_date(v)
        if d is not None:
            vals.append(d)
    return min(vals) if vals else None

# -------- small utilities ----------
def first_ts_date_where(g: pd.DataFrame, colname: str, predicate) -> Optional[date]:
    if colname not in g.columns or "timestamp_dt" not in g.columns:
        return None
    for _, row in g.iterrows():
        if predicate(row.get(colname)):
            ts = row.get("timestamp_dt")
            if pd.isna(ts):
                continue
            return ts.to_pydatetime().date()
    return None

def latest_of(g: pd.DataFrame, col: str) -> str:
    if col not in g.columns or g.empty:
        return ""
    v = str(g[col].iloc[-1] if pd.notna(g[col].iloc[-1]) else "").strip()
    return v

def latest_device_category(g: pd.DataFrame) -> str:
    if "Device Type" not in g.columns or g.empty:
        return "Unknown"
    ser = g["Device Type"].astype(str).str.strip().replace({"": pd.NA}).dropna()
    last_device_type = ser.iloc[-1] if not ser.empty else ""
    return device_category_from_type(last_device_type)

def fmt_date_mdy(d: Optional[date]) -> str:
    if d is None:
        return "-"
    return fmt_mdy(datetime(d.year, d.month, d.day))
