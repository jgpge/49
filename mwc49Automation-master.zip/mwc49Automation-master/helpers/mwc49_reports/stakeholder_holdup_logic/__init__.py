from .it_preestimating import MODULE as it_preestimating_module
from .construction import MODULE as construction_module 
from . import adms as mod_adms
from . import dlt_comm as mod_dlt_comm
from . import dependency as mod_dependency
from . import dlt_pre_comm as mod_dlt_pre_comm   # <-- ADD
from . import construction_pre_comm as mod_constr_pre_comm   # <-- ADD
from . import settings              as mod_settings            # <-- ADD
from . import it_pre_comm           as mod_it_pre_comm      # <-- ADD
from . import asset                 as mod_asset            # <-- ADD
from . import it_comm               as mod_it_comm      # <-- ADD
from . import estimating as mod_estimating  # <-- ADD
from . import other_mat as mod_other_mat         # <-- ADD
from . import pgm as mod_pgm                     # <-- ADD
from . import exponent_support as mod_exp_sup    # <-- ADD
from . import dlt_pre_estimating as mod_dlt_pre_estimating  # <-- ADD
from . import clerical as mod_clerical  # <-- ADD

REGISTRY = {
    it_preestimating_module.STAKEHOLDER_NAME: it_preestimating_module,
    construction_module.STAKEHOLDER_NAME: construction_module, 
    mod_adms.NAME: mod_adms,
    mod_dlt_comm.NAME: mod_dlt_comm,
    mod_dependency.NAME: mod_dependency, 
    mod_dlt_pre_comm.NAME: mod_dlt_pre_comm,         # <-- ADD   
    mod_constr_pre_comm.NAME: mod_constr_pre_comm,          # <-- ADD   
    mod_settings.NAME: mod_settings,                           # <-- ADD
    mod_it_pre_comm.NAME: mod_it_pre_comm,                  # <-- ADD
    mod_asset.NAME: mod_asset,                              # <-- ADD
    mod_it_comm.NAME: mod_it_comm,                      # <-- ADD
    mod_estimating.NAME: mod_estimating,     # <-- ADD
    mod_other_mat.NAME: mod_other_mat,
    mod_pgm.NAME: mod_pgm,
    mod_exp_sup.NAME: mod_exp_sup,
    mod_dlt_pre_estimating.NAME: mod_dlt_pre_estimating,   # <-- ADD
    mod_clerical.NAME: mod_clerical,  # <-- ADD
}

ACCURATE_STAKEHOLDER_CHOICES = list(REGISTRY.keys())
