from __future__ import annotations
from typing import List, Optional
import pandas as pd
from datetime import date

from .base import StakeholderAccResult
from .common import (
    fmt_date_mdy,
)

STAKEHOLDER_NAME = "Construction"
EXTRA_COLS: List[str] = [
    "Ready for Construction Date",
    "Field Install Complete Date",
]

_RFC_VALUE = "ready for construction"

_MIN_START_DATE = date(2026, 1, 2)

def _normalize_str(x) -> str:
    s = str(x).strip().lower()
    return s

def _last_ready_for_construction_start_date(g: pd.DataFrame) -> Optional[pd.Timestamp.date]:
    """
    Walk the group's history (sorted by timestamp_dt ASC) and find the
    **last transition into** 'Ready for Construction' in 'Stage of Job'.
    Return that transition's calendar date (from the timestamp).
    If never entered, return None.
    """
    
    print(g.columns)
    if "Stage of Job" not in g.columns or "timestamp_dt" not in g.columns or g.empty:
        return None

    # ensure sorted
    g_sorted = g.sort_values("timestamp_dt", ascending=True)
    prev_is_rfc = False
    last_start_date: Optional[pd.Timestamp.date] = None

    for _, row in g_sorted.iterrows():
        stage = _normalize_str(row.get("Stage of Job"))
        is_rfc = (stage == _RFC_VALUE)

        # transition: previously not RFC, now RFC -> segment start
        if is_rfc and not prev_is_rfc:
            ts = row.get("timestamp_dt")
            if pd.notna(ts):
                last_start_date = ts.to_pydatetime().date()

        prev_is_rfc = is_rfc

    return last_start_date

def _first_field_install_complete_date(g: pd.DataFrame) -> Optional[pd.Timestamp.date]:
    """
    Find the **first timestamp** where 'Field Install Completed (Yes)' is 'yes' (any case).
    Return that timestamp's calendar date.
    """
    col = "Field Install Completed (Yes)"
    if col not in g.columns or "timestamp_dt" not in g.columns or g.empty:
        return None

    g_sorted = g.sort_values("timestamp_dt", ascending=True)
    for _, row in g_sorted.iterrows():
        val = _normalize_str(row.get(col))
        if val in ("yes", "y", "true", "1"):  # lenient yes
            ts = row.get("timestamp_dt")
            if pd.notna(ts):
                return ts.to_pydatetime().date()
    return None

def compute_for_group(g: pd.DataFrame) -> StakeholderAccResult:
    """
    Start = start of the **last** 'Ready for Construction' run (from timestamp)
    End   = first timestamp date where 'Field Install Completed (Yes)' == yes
    If either is missing or End < Start → 'Not Enough Data'
    """
    # Ensure timestamp_dt is present & sorted
    if "timestamp_dt" not in g.columns:
        g = g.copy()
        g["timestamp_dt"] = pd.to_datetime(g["timestamp"], errors="coerce")
        g = g.dropna(subset=["timestamp_dt"])
    g = g.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)
    if g.empty:
        return StakeholderAccResult(["-", "-"], "Not Enough Data")

    start_date = _last_ready_for_construction_start_date(g)
    end_date   = _first_field_install_complete_date(g)

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return StakeholderAccResult([start_str, end_str], "Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return StakeholderAccResult([start_str, end_str], "Not Enough Data")

    return StakeholderAccResult([start_str, end_str], f"{delta} days")

# Expose module in the expected shape
class MODULE:
    STAKEHOLDER_NAME = STAKEHOLDER_NAME
    EXTRA_COLS = EXTRA_COLS
    compute_for_group = staticmethod(compute_for_group)
