from __future__ import annotations
from typing import Optional, List
import pandas as pd
from datetime import date

from .common import (
    Result,
    latest_of,
    latest_device_category,
)

NAME = "Dependency"

# No extra display columns before the holdup column for this stakeholder
EXTRA_COLS: List[str] = []

_COL = "Open Dependencies"

_MIN_START_DATE = date(2026, 1, 2)

# values that mean "not with Dependency"
_EXEMPT = {"", "none", "#n/a", "project managed", "na", "n/a", "in estimating", "nan"}

def _norm(s) -> str:
    return str(s).strip().lower()

def _is_dependency_open(val) -> bool:
    return _norm(val) not in _EXEMPT

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Holdup = count of rows where 'Open Dependencies' is anything OTHER than
             (None/blank, '#N/A', 'Project Managed', "In Estimating"), case-insensitive.

    Edge cases (Not Enough Data):
      - Oldest row already shows an "open" dependency (we don't know when it began).
      - Latest row still shows an "open" dependency (it may still be ongoing).
    """
    if _COL not in g.columns:
        return Result(extra_values=[], holdup_value="Not Enough Data")

    # Ensure time-order
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
        gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)
    else:
        gg = g.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    if gg.empty:
        return Result(extra_values=[], holdup_value="Not Enough Data")

    # Oldest & latest values for edge checks
    oldest_val = gg[_COL].iloc[0]
    latest_val = gg[_COL].iloc[-1]

    oldest_open = _is_dependency_open(oldest_val)
    latest_open = _is_dependency_open(latest_val)

    # If either boundary is open, we don't have a bounded interval
    if oldest_open or latest_open:
        return Result(extra_values=[], holdup_value="Not Enough Data")

    # Otherwise, simply count rows that were "open"
    open_count = int(sum(_is_dependency_open(v) for v in gg[_COL].tolist()))

    return Result(extra_values=[], holdup_value=f"{open_count} days")
