# helpers/mwc49_reports/stakeholder_holdup_logic/dlt_pre_estimating.py
from __future__ import annotations
import pandas as pd

from .common import (
    Result,
    first_ts_date_where,
    fmt_date_mdy,
)

NAME = "DLT Pre-estimating"

# Shown before the holdup column
EXTRA_COLS = [
    "DLT Pre-estimating Start Date",
    "DLT Pre-estimating End Date",
]

_COL_STATUS = "DLT Site Visit Status (NOTN/INPR/COMP)"
_COL_PHU    = "Primary Hold-Up"
_PHU_TARGET = "DLT - Site visit pending"


def _norm(v) -> str:
    return str(v).strip().upper() if v is not None else ""


def _is_inpr(v) -> bool:
    return _norm(v) == "INPR"


def _is_comp(v) -> bool:
    return _norm(v) == "COMP"


def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)


def _first_ts_date_equals(g: pd.DataFrame, col: str, target: str) -> pd.Timestamp.date | None:
    """Calendar date of FIRST timestamp where g[col] == target (case-insensitive, trimmed)."""
    if col not in g.columns:
        return None
    tgt = target.strip().casefold()
    for _, row in g.iterrows():
        v = str(row.get(col, "")).strip().casefold()
        if v == tgt:
            ts = row.get("timestamp_dt")
            if pd.notna(ts):
                return ts.to_pydatetime().date()
    return None


def _last_ts_date_equals(g: pd.DataFrame, col: str, target: str) -> pd.Timestamp.date | None:
    """Calendar date of LAST timestamp where g[col] == target (case-insensitive, trimmed)."""
    if col not in g.columns:
        return None
    tgt = target.strip().casefold()
    # fast path: filter then take last
    mask = g[col].astype(str).str.strip().str.casefold() == tgt
    if not mask.any():
        return None
    last_idx = mask[mask].index[-1]
    ts = g.loc[last_idx, "timestamp_dt"]
    if pd.isna(ts):
        return None
    return ts.to_pydatetime().date()


def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Primary logic:
      Start = FIRST timestamp where DLT Site Visit Status == INPR
      End   = FIRST timestamp where DLT Site Visit Status == COMP
    Fallback when the above yields "Not Enough Data":
      Use Primary Hold-Up:
        Start = FIRST timestamp where Primary Hold-Up == "DLT - Site visit pending"
        End   = LAST  timestamp where Primary Hold-Up == "DLT - Site visit pending"
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start.
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # keep oldest snapshot date just for the status-based guard
    oldest_ts = gg["timestamp_dt"].iloc[0]
    oldest_date = oldest_ts.to_pydatetime().date() if pd.notna(oldest_ts) else None

    # ---------- Primary method: INPR -> COMP in DLT Site Visit Status ----------
    start_date = first_ts_date_where(gg, _COL_STATUS, _is_inpr)
    end_date   = first_ts_date_where(gg, _COL_STATUS, _is_comp)

    start_str = fmt_date_mdy(start_date)
    end_str   = fmt_date_mdy(end_date)

    valid_primary = True
    if start_date is None or end_date is None:
        valid_primary = False
    elif oldest_date is not None and end_date == oldest_date:
        valid_primary = False
    elif (end_date - start_date).days < 0:
        valid_primary = False

    if valid_primary:
        return Result(extra_values=[start_str, end_str], holdup_value=f"{(end_date - start_date).days} days")

    # ---------- Fallback method: Primary Hold-Up window ----------
    gg_phu = gg  # already sorted
    phu_start = _first_ts_date_equals(gg_phu, _COL_PHU, _PHU_TARGET)
    phu_end   = _last_ts_date_equals(gg_phu, _COL_PHU, _PHU_TARGET)

    phu_start_str = fmt_date_mdy(phu_start)
    phu_end_str   = fmt_date_mdy(phu_end)

    if phu_start is None or phu_end is None:
        return Result(extra_values=[start_str if start_date else phu_start_str,
                                    end_str if end_date else phu_end_str],
                      holdup_value="Not Enough Data")

    delta = (phu_end - phu_start).days
    if delta < 0:
        return Result(extra_values=[phu_start_str, phu_end_str], holdup_value="Not Enough Data")

    # Display the fallback dates in the same two columns
    return Result(extra_values=[phu_start_str, phu_end_str], holdup_value=f"{delta} days")
