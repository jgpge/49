# helpers/mwc49_reports/stakeholder_holdup_logic/adms.py
from __future__ import annotations
from datetime import date, datetime
from typing import Optional, List
import pandas as pd

from ..common_helpers import fmt_mdy
from .common import Result, parse_any_to_date, first_ts_date_where

NAME = "ADMS"
EXTRA_COLS = ["SCADA Build Request Date", "SCADA WO COMP Date"]  # display labels unchanged
_MIN_START_DATE = date(2026, 1, 2)

# ---- helpers that are robust to duplicated column names ----------------------

def _collapse_dup_column(g: pd.DataFrame, colname: str) -> Optional[pd.Series]:
    """
    Return a single Series representing `colname` even if the DataFrame has
    duplicated columns with that same name. We take the first non-empty cell
    across the duplicates for each row.
    """
    if colname not in g.columns:
        return None

    # All physical columns that match this logical name (handles duplicates)
    mask = g.columns == colname
    sub = g.loc[:, mask]

    if isinstance(sub, pd.Series):
        # Unique column name → already a Series
        return sub

    if sub.empty:
        return None

    # Collapse duplicates: prefer the first non-empty/non-NaN per row
    # Normalize blanks to NaN so bfill works nicely
    sub_norm = sub.apply(lambda s: s.where(s.astype(str).str.strip() != "", other=pd.NA))
    # Take the first non-null across columns
    collapsed = sub_norm.bfill(axis=1).iloc[:, 0]
    return collapsed

def _first_any_date_in_col(g: pd.DataFrame, colname: str) -> Optional[date]:
    """
    Earliest valid date parsed from logical column `colname` (format-agnostic),
    robust to duplicated column names.
    """
    s = _collapse_dup_column(g, colname)
    if s is None:
        return None

    dates: List[date] = []
    for v in s.tolist():
        d = parse_any_to_date(v)
        if d is not None:
            dates.append(d)
    return min(dates) if dates else None

def _fmt_date_mdy(d: Optional[date]) -> str:
    if d is None:
        return "-"
    return fmt_mdy(datetime(d.year, d.month, d.day))

# ---- main -------------------------------------------------------------------

def compute_for_group(g: pd.DataFrame) -> Result:
    """
    ADMS logic:
      Start = earliest actual value in 'SCADA Build Request Date' (calendar date)
      End   = MIN(
                 calendar date of FIRST timestamp where 'SCADA WO Status' == 'COMP',
                 earliest actual date in 'SCADA Build Ready Date'
               )
      Holdup = (End - Start).days
      Guards: if either missing, or End < Start, or End equals the oldest data day -> "Not Enough Data"
    """
    if g.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Oldest available data (string slice guard)
    oldest_ts = g["timestamp"].min()
    oldest_date = str(oldest_ts)[:10] if pd.notna(oldest_ts) else None

    # Ensure timestamp_dt exists and is sorted
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg["timestamp"], errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
        gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)
    else:
        gg = g.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Start: earliest actual value in SCADA Build Request Date
    start_date = _first_any_date_in_col(gg, "SCADA Build Request Date")

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    # End candidates:
    #  1) First timestamp where SCADA WO Status == COMP  -> use timestamp's calendar date
    end_comp = first_ts_date_where(gg, "SCADA WO Status", lambda v: str(v).strip().upper() == "COMP")
    #  2) Earliest actual date found in SCADA Build Ready Date (cell value)
    end_ready = _first_any_date_in_col(gg, "SCADA Build Ready Date")

    # Effective end = min of whichever exist
    if end_comp and end_ready:
        end_date = min(end_comp, end_ready)
    else:
        end_date = end_comp or end_ready  # one of them, or None

    start_str = _fmt_date_mdy(start_date)
    end_str   = _fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    # Guard: if chosen end equals the oldest data day (no pre-history), say NED
    if oldest_date is not None and str(end_date) == str(oldest_date):
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
