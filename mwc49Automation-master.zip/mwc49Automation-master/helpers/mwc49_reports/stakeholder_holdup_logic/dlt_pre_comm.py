# helpers/mwc49_reports/stakeholder_holdup_logic/dlt_pre_comm.py
from __future__ import annotations

from typing import Optional, List
from pathlib import Path
import sqlite3

import pandas as pd
from datetime import date

from .common import (
    Result,
    parse_any_to_date,
    first_ts_date_where,
    fmt_date_mdy,
    first_any_date_in_col,
)

NAME = "DLT Pre-comm"

# Show these two columns before the holdup column
EXTRA_COLS: List[str] = [
    "Material Delivered Date",
    "DS83 Completed Date",
]

_COL_MATERIAL_DELIVERED = "Material Delivered Date"
_COL_DS83_YES = "DS83 Completed (Yes)"  # we display date under "DS83 Completed Date"

# New guard column
_STAGE_COL = "Stage of Job"

# RCC DB + table/column settings
_RCC_DB_FILENAME = "RCC.db"
_RCC_DB_DIRNAME = "data"
_MWC49_TABLE = "mwc49"
_TS_COL = "timestamp"
_MIN_START_DATE = date(2026, 1, 2)

# Module-level cache so we only hit SQLite once per process
_LATEST_DB_DATE: Optional[date] = None
_LATEST_DB_DATE_LOADED: bool = False


def _is_yes(val) -> bool:
    return str(val).strip().lower() == "yes"


def _find_rcc_db_path() -> Optional[str]:
    """
    Try to locate data/RCC.db by walking upward from this file's directory.
    Returns absolute path if found, else None.
    """
    here = Path(__file__).resolve()
    for parent in [here.parent, *here.parents]:
        candidate = parent / _RCC_DB_DIRNAME / _RCC_DB_FILENAME
        if candidate.is_file():
            return str(candidate)
    return None


def _load_latest_database_date() -> Optional[date]:
    """
    Reads MAX(timestamp) from mwc49 table in data/RCC.db and returns it as a date (YYYY-MM-DD).
    Returns None if DB/table/column missing or no valid timestamps.
    """
    db_path = _find_rcc_db_path()
    if not db_path:
        return None

    try:
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            cur.execute(f'SELECT MAX("{_TS_COL}") FROM "{_MWC49_TABLE}"')
            row = cur.fetchone()
    except Exception:
        return None

    if not row:
        return None

    max_ts = row[0]
    if max_ts is None:
        return None

    try:
        dt = pd.to_datetime(max_ts, errors="coerce")
        if pd.isna(dt):
            return None
        return dt.to_pydatetime().date()
    except Exception:
        return None


def latest_database_date() -> Optional[date]:
    """
    Cached accessor for latest timestamp date in RCC.db::mwc49.timestamp.
    """
    global _LATEST_DB_DATE, _LATEST_DB_DATE_LOADED
    if not _LATEST_DB_DATE_LOADED:
        _LATEST_DB_DATE = _load_latest_database_date()
        _LATEST_DB_DATE_LOADED = True
    return _LATEST_DB_DATE


def compute_for_group(g: pd.DataFrame) -> Result:
    """
    Start  = first actual calendar date found in 'Material Delivered Date' (cell value, not timestamp)
    End    = calendar date of the FIRST timestamp where 'DS83 Completed (Yes)' == 'Yes'
    Holdup = (End - Start).days, or "Not Enough Data" if either missing or End < Start

    NEW GUARDS:
      1) latest DB date guard:
         - latest_database_date = MAX(date(timestamp)) from RCC.db::mwc49.timestamp
         - group_latest_date    = MAX(date(timestamp_dt)) within this group
         - If group_latest_date != latest_database_date -> Not Enough Data

      2) Stage-of-job guard:
         - If Stage of Job at the group's latest timestamp row is "Project Managed" -> Not Enough Data
    """
    if g is None or g.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Oldest available data date (string slice)
    oldest_ts = g.get("timestamp", pd.Series(dtype=object)).min()
    oldest_date = str(oldest_ts)[:10] if pd.notna(oldest_ts) else None

    # Ensure we have a time axis
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
        gg = gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)
    else:
        gg = g.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

    if gg.empty:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # Robust oldest date in this group (true chronological oldest)
    grp_oldest_ts = gg["timestamp_dt"].min()
    grp_oldest_date = grp_oldest_ts.to_pydatetime().date() if pd.notna(grp_oldest_ts) else None

    # ---- NEW GUARD #1: group latest date must match latest DB date ----
    db_latest = latest_database_date()
    grp_latest_ts = gg["timestamp_dt"].max()
    grp_latest = grp_latest_ts.to_pydatetime().date() if pd.notna(grp_latest_ts) else None

    if db_latest is None or grp_latest is None or grp_latest != db_latest:
        return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")

    # ---- NEW GUARD #2: Stage of Job at latest timestamp row cannot be Project Managed ----
    if _STAGE_COL in gg.columns:
        last_stage = str(gg.loc[len(gg) - 1, _STAGE_COL]).strip().casefold()
        if last_stage == "project managed":
            return Result(extra_values=["-", "-"], holdup_value="Not Enough Data")
    # If the column is missing, we do NOT block (only block when present and matches)

    # Start: first actual date value in Material Delivered Date
    start_date = first_any_date_in_col(gg, _COL_MATERIAL_DELIVERED)

    if start_date is not None:
        start_date = max(start_date, _MIN_START_DATE)

    # End: first timestamp where DS83 Completed (Yes) == "Yes"
    end_date = first_ts_date_where(gg, _COL_DS83_YES, _is_yes)

    start_str = fmt_date_mdy(start_date)
    end_str = fmt_date_mdy(end_date)

    if start_date is None or end_date is None:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    # Scenario 4 guard: if DS83 first-Yes occurs on the oldest timestamp day in the group
    if grp_oldest_date is not None and end_date == grp_oldest_date:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    delta = (end_date - start_date).days
    if delta < 0:
        return Result(extra_values=[start_str, end_str], holdup_value="Not Enough Data")

    return Result(extra_values=[start_str, end_str], holdup_value=f"{delta} days")
