# helpers/mwc49_reports/common_helpers.py
from __future__ import annotations
from datetime import datetime, timedelta
from typing import Optional, Tuple, List
import pandas as pd

# ===== Primary Hold-Up → Stakeholder map (single source of truth) =====
PRIMARY_TO_STAKEHOLDER = {
    "PA pending": "Asset",
    "DLT - Site visit pending": "DLT Pre-estimating",
    "Asset feedback pending": "Asset",
    "Rescope pending": "Asset",
    "Estimating pending": "Estimating",
    "Other MAT work pending": "Other MAT",
    "Settings pending": "Settings",
    "IT - Survey WO pending": "IT Pre-estimating",
    "IT - Surveyed wrong site": "IT Pre-estimating",
    "IT - Radio type pending": "IT Pre-estimating",
    "IT - Survey failed, feedback pending": "IT Pre-estimating",
    "IT - Comm WO pending": "IT Pre-comm",
    "IT - Controller pending": "IT Pre-comm",
    "IT - Repeater pending": "IT Pre-comm",
    "IT - Info for SCADA pending": "IT Comm",
    "IT - Comm issue pending": "IT Comm",
    "IT - Antenna missing": "IT Comm",
    "IT - Field support pending": "IT Comm",
    "Device delivery pending": "Construction Pre-comm",
    "Device ETA": "Construction Pre-comm",
    "DLT - Pre-comm pending": "DLT Pre-comm",
    "DLT - Pre-comm verification needed": "DLT Pre-comm",
    "Permit pending": "Dependency",
    "Permit application pending": "Dependency",
    "Permit Extension Needed": "Dependency",
    "Info needed for PC25": "Exponent Support",
    "PC25 request pending": "Exponent Support",
    "UNSC pending MPP update": "Exponent Support",
    "LR firmware pending": "Settings",
    "SCADA build pending": "ADMS",
    "WPD update for Permit": "PGM",
    "Construction pending": "Construction",
    "Construction scheduled": "Construction",
    "ADMS test pending": "DLT Comm",
    "ADMS test scheduled": "DLT Comm",
    "DLT - Commissioning pending": "DLT Comm",
    "Construction revisit pending": "Construction",
    "Device replacement pending": "Construction",
    "Veg management pending": "Estimating",
    "Site access delays": "Construction",
    "SCADA letter pending": "ADMS",
    "Actual Unit pending": "Clerical",
    "CN83 completed pending MPP update": "Exponent Support",
    "Estimating - Scope Clarification": "Estimating",
    "Resource assignment pending": "PGM",
    "CN24 pending": "Construction",
    "CN24 pending clerical support": "Clerical"
}

# this is the order you said you want to be able to edit later
STAKEHOLDER_ORDER = [
    "Asset",
    "IT Pre-estimating",
    "DLT Pre-estimating",
    "Estimating",
    "IT Pre-comm",
    "Settings",
    "Construction Pre-comm",
    "DLT Pre-comm",
    "Dependency",
    "Construction",
    "ADMS",
    "DLT Comm",
    "IT Comm",
    "Clerical",
    "Other MAT",
    "PGM",
    "Exponent Support",
]

STAKEHOLDERS = sorted(set(PRIMARY_TO_STAKEHOLDER.values()))
STAKEHOLDER_ALL_LABEL = "----ALL----"
STAKEHOLDER_CHOICES = [STAKEHOLDER_ALL_LABEL] + STAKEHOLDERS

# ===== Shared date helpers =====
def parse_mmddyyyy(s: str) -> datetime.date:
    return datetime.strptime((s or "").strip(), "%m/%d/%Y").date()

def fmt_mdy(dt: Optional[datetime]) -> str:
    if not dt:
        return "-"
    return dt.strftime("%m/%d/%Y")

def parse_date_cell(val) -> Optional[datetime]:
    """
    Best-effort coercion to a date-only datetime.
    Handles:
      - pandas.Timestamp / numpy.datetime64 / python datetime/date
      - Strings (any pandas-parsable format, incl. 'YYYY/MM/DD HH:MM:SS')
      - Excel serial numbers (e.g., 45678 or 45678.0 -> days since 1899-12-30)
    Returns None if unparsable.
    """
    if val is None:
        return None

    # pandas / numpy / python datetime-like
    try:
        import numpy as _np
    except Exception:
        _np = None

    if isinstance(val, pd.Timestamp):
        if pd.isna(val):
            return None
        return datetime(val.year, val.month, val.day)

    if isinstance(val, datetime):
        return datetime(val.year, val.month, val.day)

    if _np is not None and isinstance(val, _np.datetime64):
        ts = pd.to_datetime(val, errors="coerce")
        if pd.isna(ts):
            return None
        return datetime(ts.year, ts.month, ts.day)

    # Excel serial numbers (float/int but not bool)
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        if pd.isna(val):
            return None
        try:
            base = datetime(1899, 12, 30)
            d = base + timedelta(days=float(val))
            return datetime(d.year, d.month, d.day)
        except Exception:
            pass  # fall through

    # Strings
    s = str(val).strip()
    if s == "" or s.lower() in ("nan", "none", "nat", "null"):
        return None

    # pandas fast-path (covers 'YYYY/MM/DD HH:MM:SS', etc.)
    ts = pd.to_datetime(s, errors="coerce")  # no infer_datetime_format
    if not pd.isna(ts):
        return datetime(ts.year, ts.month, ts.day)

    # explicit fallbacks (date-only)
    for f in ("%m/%d/%Y", "%Y-%m-%d", "%Y/%m/%d", "%m-%d-%Y", "%d-%b-%Y"):
        try:
            d = datetime.strptime(s, f)
            return datetime(d.year, d.month, d.day)
        except Exception:
            continue

    return None

def date_changed(a: Optional[datetime], b: Optional[datetime]) -> bool:
    if (a is None) != (b is None):
        return True
    if a is None and b is None:
        return False
    return (a.year, a.month, a.day) != (b.year, b.month, b.day)

# ===== Construction delay table builder =====
def build_click_delay_rows_normalized(df: pd.DataFrame) -> Tuple[List[List[str]], int, List[int]]:
    """
    Given df with: timestamp, PM #, New Operating Number, CLICK End Date
    Returns:
      rows: table rows
      max_changes: max # of changes across PM
      totals: numeric total delay per PM
    """
    if df.empty:
        return [], 0, []

    df = df.copy()
    # Robust timestamp parse; no deprecated args
    df["timestamp_dt"] = pd.to_datetime(df.get("timestamp"), errors="coerce")
    # If CLICK End Date is already string/serial/etc., parse row-by-row later
    df = df.sort_values(["PM #", "timestamp_dt"], ascending=[True, True], na_position="last")

    pm_payloads: List[dict] = []
    max_changes = 0

    for pm, g in df.groupby("PM #", sort=False):
        g = g.reset_index(drop=True)

        nom_series = g.get("New Operating Number")
        if nom_series is not None:
            non_null_nom = nom_series.dropna()
            new_op_num = str(non_null_nom.iloc[-1]).strip() if len(non_null_nom) else "-"
        else:
            new_op_num = "-"

        series: List[Tuple[datetime, Optional[datetime]]] = []
        for _, r in g.iterrows():
            ts = r.get("timestamp_dt")
            if pd.isna(ts):
                continue
            ce = parse_date_cell(r.get("CLICK End Date"))
            series.append((ts.to_pydatetime(), ce))

        if not series:
            continue

        initial_ts, initial_date = series[0]

        changes: List[Tuple[datetime, Optional[datetime]]] = []
        prev_date = initial_date
        for (ts, ce_date) in series[1:]:
            # record only when the date actually changes (None vs date or date difference)
            a = prev_date
            b = ce_date
            if (a is None) != (b is None) or (a and b and (a.year, a.month, a.day) != (b.year, b.month, b.day)):
                changes.append((ts, ce_date))
                prev_date = ce_date

        if not changes:
            continue

        pm_payloads.append({
            "pm": str(pm).strip(),
            "nom": new_op_num if new_op_num else "-",
            "initial_ts": initial_ts,
            "initial_date": initial_date,
            "changes": changes,
        })
        max_changes = max(max_changes, len(changes))

    if not pm_payloads:
        return [], 0, []

    rows: List[List[str]] = []
    totals: List[int] = []

    def _fmt_mdy(dt: Optional[datetime]) -> str:
        return "-" if not dt else dt.strftime("%m/%d/%Y")

    for item in pm_payloads:
        pm = item["pm"]
        nom = item["nom"]
        initial_ts = item["initial_ts"]
        initial_date = item["initial_date"]
        changes = item["changes"]

        row: List[str] = [pm, nom, _fmt_mdy(initial_date), _fmt_mdy(initial_ts)]

        total_days = 0
        prev_for_delay = initial_date

        for (chg_ts, chg_date) in changes:
            if prev_for_delay is not None and chg_date is not None:
                days = (chg_date - prev_for_delay).days
                total_days += days
                delay_str = f"{days:+d} days"
            else:
                delay_str = "-"
            row += [_fmt_mdy(chg_date), _fmt_mdy(chg_ts), delay_str]
            prev_for_delay = chg_date

        # pad remaining triplets
        missing = max_changes - len(changes)
        for _ in range(missing):
            row += ["-", "-", "-"]

        row.append(f"{total_days:+d} days")
        rows.append(row)
        totals.append(total_days)

    return rows, max_changes, totals

def stakeholder_from_phu(phu: str, resolve_date: str | None = None) -> str | None:
    """
    Map PHU -> stakeholder, with special-case override for CN24 pending.
    If Resolve Date is something like 'Clerical Support', 'CLERICAL SUPPORT  ',
    'clerical   support - MB', we still treat it as Clerical.
    """
    phu = (phu or "").strip()
    base = PRIMARY_TO_STAKEHOLDER.get(phu)
    if not base:
        return None

    # special case for CN24 pending
    if phu == "CN24 pending" and resolve_date:
        # normalize: lower, strip, collapse spaces
        rd = (resolve_date or "").strip().lower()
        # also allow prefixes like "clerical support - ..."
        if rd == "clerical support" or rd.startswith("clerical support "):
            return "Clerical"

    return base

