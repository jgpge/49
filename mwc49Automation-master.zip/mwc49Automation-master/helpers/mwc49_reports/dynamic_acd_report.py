# helpers/mwc49_reports/dynamic_acd_report.py
from __future__ import annotations

from typing import List, Tuple, Optional
import pandas as pd


# Columns we’ll output (in this order)
COLUMNS = [
    "PM #",
    "New Operating Number",
    "Project Reporting Year",   # NEW (right after NOM)
    "Current Mat",
    "Program Name",
    "Division",
    "Construction Resource",
    "Dynamic ACD",  # date-only string in UI
]


def _ensure_ts_sorted_desc(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure we have a parsed datetime column and sort DESC (latest -> oldest).
    """
    work = df.copy()
    if "timestamp_dt" not in work.columns:
        work["timestamp_dt"] = pd.to_datetime(work.get("timestamp"), errors="coerce")
    work = work.dropna(subset=["timestamp_dt"])
    return work.sort_values("timestamp_dt", ascending=False).reset_index(drop=True)


def _coerce_str_series(s: pd.Series) -> pd.Series:
    return s.astype(str).fillna("").map(lambda x: str(x).strip())


def _norm_colname(s: str) -> str:
    # normalize for matching: remove spaces/underscores/dashes, lowercase
    return "".join(ch for ch in str(s).strip().casefold() if ch.isalnum())


def _find_dynamic_acd_col(df: pd.DataFrame) -> Optional[str]:
    """
    Try to locate the Dynamic ACD column even if naming differs slightly.
    """
    if df is None or df.empty:
        return None

    # direct hit
    if "Dynamic ACD" in df.columns:
        return "Dynamic ACD"

    # normalized matching
    targets = {
        "dynamicacd",
        "dynamicacddate",
        "dynamicacddatetime",
        "acd",
        "acddate",
        "dynamic_acd",  # just in case someone literally has this as a column name
    }

    norm_map = {c: _norm_colname(c) for c in df.columns}
    for c, n in norm_map.items():
        if n in targets:
            return c

    # looser: contains both "dynamic" and "acd"
    for c, n in norm_map.items():
        if "dynamic" in n and "acd" in n:
            return c

    return None


def _fmt_date_only(v) -> str:
    """
    Convert a value like '2026-04-27 00:00:00' into date-only for UI.

    Strategy:
      - Try pandas datetime parse; if succeeds -> YYYY-MM-DD
      - Else, for strings with space or 'T', take the first token before space/'T'
      - Else return '-' for blanks
    """
    if v is None:
        return "-"

    try:
        ts = pd.to_datetime(v, errors="coerce")
        if pd.notna(ts):
            return ts.strftime("%Y-%m-%d")
    except Exception:
        pass

    s = str(v).strip()
    if not s or s.lower() in {"nan", "none", "nat"}:
        return "-"

    if " " in s:
        return s.split(" ", 1)[0].strip() or "-"
    if "T" in s:
        return s.split("T", 1)[0].strip() or "-"

    return s


def make_dynamic_acd_table(
    df: pd.DataFrame,
) -> Tuple[List[str], List[List[str]], int, str, int, int]:
    """
    Dynamic ACD Report logic:

    1) latest_update_date = calendar date of the GLOBAL latest timestamp in df["timestamp"].
    2) For each group = unique (PM #, New Operating Number):
       - Sort group by timestamp DESC
       - If DATE(group latest ts) != latest_update_date => reject group
       - Else include ONLY the latest row from that group

    Output includes Dynamic ACD as DATE-ONLY string (YYYY-MM-DD).
    Adds Project Reporting Year right after New Operating Number.
    """
    total_raw = len(df)
    if df is None or df.empty:
        return COLUMNS, [], total_raw, "", 0, 0

    work = df.copy()

    # Required grouping keys
    if "PM #" not in work.columns:
        work["PM #"] = ""
    if "New Operating Number" not in work.columns:
        work["New Operating Number"] = ""

    # NEW: PRY (fill if missing)
    if "Project Reporting Year" not in work.columns:
        work["Project Reporting Year"] = ""

    # Required display columns (fill if missing)
    for c in ["Current Mat", "Program Name", "Division", "Construction Resource"]:
        if c not in work.columns:
            work[c] = ""

    # Locate Dynamic ACD column (could be named differently)
    dyn_col = _find_dynamic_acd_col(work)
    if dyn_col is None:
        dyn_col = "Dynamic ACD"
        if dyn_col not in work.columns:
            work[dyn_col] = ""

    # normalize keys
    work["PM #"] = _coerce_str_series(work["PM #"])
    work["New Operating Number"] = _coerce_str_series(work["New Operating Number"])

    # parse timestamps + sort overall DESC
    work = _ensure_ts_sorted_desc(work)
    if work.empty:
        return COLUMNS, [], total_raw, "", 0, 0

    # global latest update date
    latest_ts: Optional[pd.Timestamp] = None
    try:
        latest_ts = work["timestamp_dt"].max()
    except Exception:
        latest_ts = None

    if latest_ts is None or pd.isna(latest_ts):
        return COLUMNS, [], total_raw, "", 0, 0

    latest_update_date = latest_ts.date()
    latest_update_date_str = latest_update_date.strftime("%m/%d/%Y")

    rows: List[List[str]] = []
    included = 0
    rejected = 0

    for (pm, nom), g in work.groupby(["PM #", "New Operating Number"], sort=False):
        if g.empty:
            continue

        g = g.sort_values("timestamp_dt", ascending=False).reset_index(drop=True)

        grp_latest_ts = g.loc[0, "timestamp_dt"]
        if pd.isna(grp_latest_ts):
            rejected += 1
            continue

        if grp_latest_ts.date() != latest_update_date:
            rejected += 1
            continue

        r0 = g.iloc[0]

        dyn_val = _fmt_date_only(r0.get(dyn_col, ""))

        pry = r0.get("Project Reporting Year", "")
        pry = "" if pry is None else str(pry).strip()
        pry_display = pry or "-"

        rows.append([
            str(pm).strip(),
            str(nom).strip(),
            pry_display,  # NEW
            str(r0.get("Current Mat", "") or "").strip() or "-",
            str(r0.get("Program Name", "") or "").strip() or "-",
            str(r0.get("Division", "") or "").strip() or "-",
            str(r0.get("Construction Resource", "") or "").strip() or "-",
            dyn_val,
        ])
        included += 1

    rows.sort(key=lambda r: (r[0], r[1]))
    return COLUMNS, rows, total_raw, latest_update_date_str, included, rejected
