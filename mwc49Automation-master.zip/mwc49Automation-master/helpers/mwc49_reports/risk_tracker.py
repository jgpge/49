# helpers/mwc49_reports/risk_tracker.py
from __future__ import annotations
from typing import List, Tuple, Callable, Optional
import pandas as pd
from datetime import datetime, date, timedelta

from .risk_tracker_logic.construction import evaluate_group_for_construction_detail
from .risk_tracker_logic.asset import evaluate_group_for_asset_detail
from .risk_tracker_logic.it_controller import evaluate_group_for_it_controller_detail
from .risk_tracker_logic.clerical import evaluate_group_for_clerical_detail
from .risk_tracker_logic.dlt import evaluate_group_for_dlt_detail
from .risk_tracker_logic.dependencies import evaluate_group_for_dependencies_detail
from .risk_tracker_logic.dlt_adms import evaluate_group_for_dlt_adms_detail
from .risk_tracker_logic.estimating import evaluate_group_for_estimating_detail
from .risk_tracker_logic.it import evaluate_group_for_it_detail  # IT

# ---- Public choices ----
RISK_STAKEHOLDER_CHOICES: List[str] = [
    "-----ALL-----",          # Combined view
    "Construction",
    "Asset",
    "IT Controller",
    "Clerical",
    "DLT",
    "Dependencies",
    "DLT/ADMS",
    "Estimating",
    "IT",
]

# ---- Registry ----
_REGISTRY: dict[str, Callable[..., Optional[object]]] = {
    "Construction":   evaluate_group_for_construction_detail,
    "Asset":          evaluate_group_for_asset_detail,
    "IT Controller":  evaluate_group_for_it_controller_detail,
    "Clerical":       evaluate_group_for_clerical_detail,
    "DLT":            evaluate_group_for_dlt_detail,
    "Dependencies":   evaluate_group_for_dependencies_detail,
    "DLT/ADMS":       evaluate_group_for_dlt_adms_detail,
    "Estimating":     evaluate_group_for_estimating_detail,
    "IT":             evaluate_group_for_it_detail,
}

# Deterministic order for ALL view
_ALL_ORDER: List[str] = [
    "Construction",
    "Asset",
    "IT Controller",
    "Clerical",
    "DLT",
    "Dependencies",
    "DLT/ADMS",
    "Estimating",
    "IT",
]

# ----------------- Small helpers for the ALL view -----------------
_READY_VAL = "ready for construction"

def _norm(s) -> str:
    return str(s).strip().casefold() if s is not None else ""

def _fmt_mdy(d: Optional[date]) -> str:
    return d.strftime("%m/%d/%Y") if d else ""

def _ensure_sorted_with_ts(g: pd.DataFrame) -> pd.DataFrame:
    if "timestamp_dt" not in g.columns:
        gg = g.copy()
        gg["timestamp_dt"] = pd.to_datetime(gg.get("timestamp"), errors="coerce")
        gg = gg.dropna(subset=["timestamp_dt"])
    else:
        gg = g.copy()
    return gg.sort_values("timestamp_dt", ascending=True).reset_index(drop=True)

def _parse_date_cell(v) -> Optional[date]:
    try:
        dt = pd.to_datetime(v, errors="coerce")
        if pd.notna(dt):
            return dt.to_pydatetime().date()
    except Exception:
        pass
    return None

def _ci_get(columns: pd.Index, *candidates: str) -> Optional[str]:
    """
    Return the FIRST matching column name in `columns` that equals (case-insensitive)
    any of the `candidates`. If none found, return None.
    """
    low = {str(c).strip().lower(): c for c in columns}
    for cand in candidates:
        k = cand.strip().lower()
        if k in low:
            return low[k]
    return None

def _get_cell(row: pd.Series, colname: Optional[str]) -> str:
    if not colname:
        return ""
    v = row.get(colname)
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in {"nan", "none", "null"} else s

def _get_date_str(row: pd.Series, colname: Optional[str]) -> str:
    if not colname:
        return ""
    d = _parse_date_cell(row.get(colname))
    return _fmt_mdy(d) if d else ""

def _last_rfc_stint_start_date(g: pd.DataFrame) -> Optional[date]:
    """
    Compute the start DATE (by snapshot timestamp) of the LAST contiguous stint
    where 'Stage of Job' equals 'ready for construction' (case-insensitive).
    """
    gg = _ensure_sorted_with_ts(g)
    if gg.empty or "Stage of Job" not in gg.columns:
        return None

    is_rfc = gg["Stage of Job"].apply(_norm).eq(_READY_VAL).to_list()
    last_start_idx = None
    prev = False
    for i, cur in enumerate(is_rfc):
        if cur and not prev:
            last_start_idx = i
        prev = cur

    if last_start_idx is None:
        return None
    ts = gg.loc[last_start_idx, "timestamp_dt"]
    return ts.to_pydatetime().date() if pd.notna(ts) else None

def _call_evaluator(
    evaluator: Callable[..., Optional[object]],
    g: pd.DataFrame,
    db_max_date: Optional[date],
):
    """
    Try to pass db_max_date if the evaluator supports it; otherwise call without it.
    """
    try:
        return evaluator(g, db_max_date=db_max_date)
    except TypeError:
        return evaluator(g)

def _collapse_ws(s: str) -> str:
    return " ".join((s or "").split())

def _action_eq(a: str, b: str) -> bool:
    # robust exact-match: case-insensitive + collapse whitespace
    return _collapse_ws(_norm(a)) == _collapse_ws(_norm(b))

# ---- Requested PM Escalation rules (ALL view) ----
_ACTION_CONSTR_PULL_IN = "Please pull in job. Scheduled for 9+ weeks since ready for construction."
_ACTION_DEP_PULL_IN = "Dependency EOD is 90+ days after ESTS Actual Out Date. Please pull job in."

# ----------------- Main entry -----------------
def make_risk_tracker_table(
    df: pd.DataFrame,
    window_start: Optional[datetime] = None,
    window_end:   Optional[datetime] = None,
    stakeholder: str = "Construction",
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> Tuple[List[str], List[List[str]], int]:
    total_raw = len(df)

    req = {"PM #", "New Operating Number"}
    if not req.issubset(set(df.columns)):
        # Minimal safe fallback when schema is incomplete
        if stakeholder == "-----ALL-----":
            return [
                "PM #", "New Operating Number", "Program Name", "Current Mat",
                "Dependency Estimated Out Date", "Open Dependencies", "ESTS Actual Out Date",
                "Work Plan Date", "Project Reporting Year", "Anticipated Complete Date (VOID)",
                "Completion Deadline Date", "Notification #", "Notification Status", "Device Type",
                "Region", "Division", "Stakeholder", "Construction Resource",
                "Construction Contact / Div Director", "ESTS Planned Out Date",
                "CLICK End Date", "Action", "Meeting Notes", "Background", "Resolved (Y/N)",
                "PM Escalation", "Requestor", "Requested Date", "MPP Sub-Category",
                "On linda's list?", "Primary Hold-Up", "Resolve Date"
            ], [], total_raw
        return ["PM #", "New Operating Number", "Stakeholder",
                "Ready for Construction Date", "CLICK End Date", "Action"], [], total_raw

    if "timestamp_dt" not in df.columns:
        df = df.copy()
        df["timestamp_dt"] = pd.to_datetime(df.get("timestamp"), errors="coerce")
        df = df.dropna(subset=["timestamp_dt"])

    # Compute DB-wide max DATE (not time)
    db_max_date: Optional[date] = None
    if not df.empty:
        db_max_date = df["timestamp_dt"].dt.date.max()

    df = df.sort_values(["PM #", "New Operating Number", "timestamp_dt"], ascending=[True, True, True])

    # ----------------- Combined (ALL) view -----------------
    if stakeholder == "-----ALL-----":
        columns = [
            "PM #",
            "New Operating Number",
            "Program Name",
            "Current Mat",
            "Main Work Center",
            "Dependency Estimated Out Date",
            "Open Dependencies",
            "ESTS Actual Out Date",
            "Work Plan Date",
            "Project Reporting Year",
            "Anticipated Complete Date (VOID)",
            "Completion Deadline Date",
            "Notification #",
            "Notification Status",
            "SAP Order User Status ",
            "Device Type",
            "Region",
            "Division",
            "Stakeholder",
            "Construction Resource",
            "Construction Contact / Div Director",
            "ESTS Planned Out Date",
            "CLICK End Date",
            "Action",
            "Meeting Notes",
            "Background",
            "Resolved (Y/N)",
            "PM Escalation",
            "Requestor",
            "Requested Date",
            "MPP Sub-Category",
            "On linda's list?",
            "Primary Hold-Up",
            "Resolve Date",
        ]
        rows: List[List[str]] = []

        # Candidate column names (case-insensitive) for display fields (latest snapshot in each group)
        PROGRAM_COLS     = ("Program Name", "Program")
        MAT_COLS         = ("Current Mat", "Current MAT", "MAT", "Mat")
        MWC_COLS         = ("Main Work Center", "Work Plan Center")
        DEP_EOD_COLS     = ("Dependency Estimated Out Date", "Dependency EOD", "Dependency Estimated Out", "Dep EOD")
        OPEN_COLS        = ("Open Dependencies", "Open Dependency")
        ESTS_ACT_COLS    = ("ESTS Actual Out Date", "ESTS Actual Date", "ESTS Actual", "ESTS Out Actual Date")
        WPD_COLS         = ("Work Plan Date",)
        PRY_COLS         = ("Project Reporting Year", "Project Reporting Yr", "Reporting Year")
        AC_VOID_COLS     = ("Anticipated Complete Date (VOID)", "Anticipated Complete Date", "AC VOID")
        CDL_COLS         = ("Completion Deadline Date", "Completion Deadline")
        NOTIF_NUM_COLS   = ("Notification #", "Notification Number", "Notification")
        NOTIF_STAT_COLS  = ("Notification Status",)
        SAP_USER_STATUS_COLS = ("SAP Order User Status", "SAP Order Status", "Order User Status", "SAP Order User Status ")
        DEV_COLS         = ("Device Type",)
        REGION_COLS      = ("Region",)
        DIV_COLS         = ("Division", "Div")
        RESRC_COLS       = ("Construction Resource", "Resource", "Construction Resource Name")
        CONTACT_COLS     = ("Construction Contact / Div Director", "Construction Contact", "Div Director")
        ESTS_PLAN_COLS   = ("ESTS Planned Out Date", "ESTS Planned Date", "ESTS Planned Out")
        CE_COLS          = ("CLICK End Date", "CE", "Click End Date")
        MPP_SUB_COLS     = ("MPP Sub-Category", "MPP Subcategory", "MPP Sub Category")
        ON_LINDA_COLS    = ("On linda's list?", "On linda’s list?", "On lindas list", "On linda list")
        PH_COLS          = ("Primary Hold-Up", "Primary Hold Up", "Primary HoldUp")
        RD1_COLS         = ("Resolve Date", "Resolve date", "Resolve_Date", "ResolveDate")
        # RFC stint start is computed; we do not display it in ALL columns per your spec

        grouped = list(df.groupby(["PM #", "New Operating Number"], sort=False, dropna=False))
        total_groups = len(grouped)
        done = 0
        if progress_cb:
            progress_cb(done, total_groups or 1)

        for (pm, nom), g in grouped:
            g = g.reset_index(drop=True)
            gg = _ensure_sorted_with_ts(g)
            if gg.empty:
                continue

            # latest snapshot for this (PM, NOM)
            latest = gg.iloc[-1]

            # Resolve the actual column names present (case-insensitive)
            c_program   = _ci_get(gg.columns, *PROGRAM_COLS)
            c_mat       = _ci_get(gg.columns, *MAT_COLS)
            c_mwc       = _ci_get(gg.columns, *MWC_COLS)
            c_dep_eod   = _ci_get(gg.columns, *DEP_EOD_COLS)
            c_open      = _ci_get(gg.columns, *OPEN_COLS)
            c_ests_act  = _ci_get(gg.columns, *ESTS_ACT_COLS)
            c_wpd       = _ci_get(gg.columns, *WPD_COLS)
            c_pry       = _ci_get(gg.columns, *PRY_COLS)
            c_ac_void   = _ci_get(gg.columns, *AC_VOID_COLS)
            c_cdl       = _ci_get(gg.columns, *CDL_COLS)
            c_notif_num = _ci_get(gg.columns, *NOTIF_NUM_COLS)
            c_notif_sts = _ci_get(gg.columns, *NOTIF_STAT_COLS)
            c_sap_stat  = _ci_get(gg.columns, *SAP_USER_STATUS_COLS)
            c_dev       = _ci_get(gg.columns, *DEV_COLS)
            c_region    = _ci_get(gg.columns, *REGION_COLS)
            c_div       = _ci_get(gg.columns, *DIV_COLS)
            c_resrc     = _ci_get(gg.columns, *RESRC_COLS)
            c_contact   = _ci_get(gg.columns, *CONTACT_COLS)
            c_ests_plan = _ci_get(gg.columns, *ESTS_PLAN_COLS)
            c_ce        = _ci_get(gg.columns, *CE_COLS)
            c_mpp_sub   = _ci_get(gg.columns, *MPP_SUB_COLS)
            c_on_linda  = _ci_get(gg.columns, *ON_LINDA_COLS)
            c_ph        = _ci_get(gg.columns, *PH_COLS)
            c_rd1       = _ci_get(gg.columns, *RD1_COLS)

            # Pull latest values (strings or date strings), all from the latest row
            pm_s           = str(pm).strip()
            nom_s          = str(nom).strip()
            program_str    = _get_cell(latest, c_program)
            mat_str        = _get_cell(latest, c_mat)
            mwc_str        = _get_cell(latest, c_mwc)
            dep_eod_str    = _get_date_str(latest, c_dep_eod)
            open_dep_str   = _get_cell(latest, c_open)
            ests_act_str   = _get_date_str(latest, c_ests_act)
            wpd_str        = _get_date_str(latest, c_wpd)
            pry_str        = _get_cell(latest, c_pry)  # year stays as text
            ac_void_str    = _get_date_str(latest, c_ac_void)
            cdl_str        = _get_date_str(latest, c_cdl)
            notif_num_str  = _get_cell(latest, c_notif_num)
            notif_sts_str  = _get_cell(latest, c_notif_sts)
            sap_status_str = _get_cell(latest, c_sap_stat)
            dev_type_str   = _get_cell(latest, c_dev)
            region_str     = _get_cell(latest, c_region)
            div_str        = _get_cell(latest, c_div)
            resrc_str      = _get_cell(latest, c_resrc)
            contact_str    = _get_cell(latest, c_contact)
            ests_plan_str  = _get_date_str(latest, c_ests_plan)
            ce_date_str    = _get_date_str(latest, c_ce)
            mpp_sub_str    = _get_cell(latest, c_mpp_sub)
            on_linda_str   = _get_cell(latest, c_on_linda)
            ph_str         = _get_cell(latest, c_ph)
            rd1_str        = _get_date_str(latest, c_rd1)

            # For each stakeholder that "fires", output one row with Stakeholder + Action
            for label in _ALL_ORDER:
                evaluator = _REGISTRY.get(label)
                if evaluator is None:
                    continue
                res = _call_evaluator(evaluator, gg, db_max_date)
                if not res:
                    continue

                action_str = getattr(res, "action", "")

                # Fixed empty/export-only columns
                meeting_notes = ""
                background    = ""
                resolved_yn   = ""

                # ---- Requested behavior: PM Escalation = "No" for specific cases ----
                pm_escalation = ""
                if label == "Construction" and _action_eq(action_str, _ACTION_CONSTR_PULL_IN):
                    pm_escalation = "No"
                elif label == "Dependencies" and _action_eq(action_str, _ACTION_DEP_PULL_IN):
                    pm_escalation = "No"

                requestor     = ""
                requested_dt  = ""

                rows.append([
                    pm_s,
                    nom_s,
                    program_str,
                    mat_str,
                    mwc_str,
                    dep_eod_str,
                    open_dep_str,
                    ests_act_str,
                    wpd_str,
                    pry_str,
                    ac_void_str,
                    cdl_str,
                    notif_num_str,
                    notif_sts_str,
                    sap_status_str,
                    dev_type_str,
                    region_str,
                    div_str,
                    label,           # Stakeholder
                    resrc_str,
                    contact_str,
                    ests_plan_str,
                    ce_date_str,
                    action_str,
                    meeting_notes,
                    background,
                    resolved_yn,
                    pm_escalation,
                    requestor,
                    requested_dt,
                    mpp_sub_str,
                    on_linda_str,
                    ph_str,
                    rd1_str,
                ])

            done += 1
            if progress_cb:
                progress_cb(done, total_groups or 1)

        return columns, rows, total_raw

    # ----------------- Single-stakeholder views (unchanged) -----------------
    if stakeholder == "Construction":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Ready for Construction Date", "CLICK End Date", "Action"]
    elif stakeholder == "Asset":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Days in Pending", "Action"]
    elif stakeholder == "IT Controller":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Hold-Up", "Resolve Date", "Action"]
    elif stakeholder == "Clerical":
        columns = ["PM #", "New Operating Number", "Stakeholder", "Action"]
    elif stakeholder == "DLT":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Device Type", "Primary Hold-Up", "Resolve Date", "Action"]
    elif stakeholder == "Dependencies":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Open Dependency", "Dependency EOD", "Action"]
    elif stakeholder == "DLT/ADMS":
        columns = ["PM #", "New Operating Number", "Stakeholder",
                   "Primary Hold-Up", "Resolve Date", "Action"]
    elif stakeholder == "Estimating":
        columns = ["PM #", "New Operating Number",
                   "Primary Hold-Up", "Stage of Job", "Resolve Date", "ESTS Planned Out Date", "Action"]
    elif stakeholder == "IT":
        columns = ["PM #", "New Operating Number",
                   "Primary Hold-Up", "Resolve Date", "Action"]
    else:
        columns = ["PM #", "New Operating Number", "Stakeholder", "Action"]

    rows: List[List[str]] = []
    evaluator = _REGISTRY.get(stakeholder)
    if evaluator is None:
        return columns, rows, total_raw

    grouped = list(df.groupby(["PM #", "New Operating Number"], sort=False, dropna=False))
    total_groups = len(grouped)
    done = 0
    if progress_cb:
        progress_cb(done, total_groups or 1)

    for (pm, nom), g in grouped:
        g = g.reset_index(drop=True)
        res = _call_evaluator(evaluator, g, db_max_date)

        if res:
            pm_s, nom_s = str(pm).strip(), str(nom).strip()

            if stakeholder == "Construction":
                rows.append([pm_s, nom_s, "Construction", res.rfc_date_str, res.click_end_date_str, res.action])
            elif stakeholder == "Asset":
                rows.append([pm_s, nom_s, "Asset", str(res.days_pending), res.action])
            elif stakeholder == "IT Controller":
                rows.append([pm_s, nom_s, "IT Controller", res.hold_up_source, res.resolve_date_str, res.action])
            elif stakeholder == "Clerical":
                rows.append([pm_s, nom_s, "Clerical", res.action])
            elif stakeholder == "DLT":
                rows.append([
                    pm_s, nom_s, "DLT",
                    res.device_type_str,
                    res.primary_hold_up_str,
                    res.resolve_date_str,
                    res.action
                ])
            elif stakeholder == "Dependencies":
                rows.append([pm_s, nom_s, "Dependencies", res.open_dep_str, res.dep_eod_str, res.action])
            elif stakeholder == "DLT/ADMS":
                rows.append([pm_s, nom_s, "DLT/ADMS", res.hold_up, res.resolve_date_str, res.action])
            elif stakeholder == "Estimating":
                rows.append([
                    pm_s, nom_s,
                    res.primary_hold_up,
                    res.stage_of_job,
                    res.resolve_date_str,
                    res.ests_planned_out_date_str,
                    res.action
                ])
            elif stakeholder == "IT":
                rows.append([pm_s, nom_s, res.primary_hold_up, res.resolve_date_str, res.action])
            else:
                rows.append([pm_s, nom_s, stakeholder, getattr(res, "action", "")])

        done += 1
        if progress_cb:
            progress_cb(done, total_groups or 1)

    return columns, rows, total_raw
