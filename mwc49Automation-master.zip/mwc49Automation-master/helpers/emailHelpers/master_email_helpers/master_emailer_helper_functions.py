# helpers/emailHelpers/master_email_helpers/master_emailer_helper_functions.py
from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from typing import List, Tuple

import pandas as pd


SHEET_NAME_49_2026 = "49 Programs 2026"
HEADER_ROW_1_INDEXED = 11  # row 11 has headers

# -----------------------------
# Existing: Settings email pulls
# -----------------------------
RAW_COLUMNS_SETTINGS: List[str] = [
    "PM-Location",
    "Mat Code",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "IT Survey WO",
    "SCADA Enabled?",
    "SAP Equipment ID",
    "Latitude",
    "Longitude",
    "Settings Mapping Completed (PC26)",
    "Equipment Settings Link",
    "Settings Requested Date",
    "Resolve Date",
    "Primary Hold-Up",
]

TABLE1_COLUMNS: List[str] = [
    "PM-Location",
    "Mat Code",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "IT Survey WO",
    "SCADA Enabled?",
    "SAP Equipment ID",
    "Latitude",
    "Longitude",
    "PC26",
    "Engineer",
    "Request Date",
]

TABLE2_COLUMNS: List[str] = [
    "PM-Location",
    "Mat Code",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "IT Survey WO",
    "SCADA Enabled?",
    "SAP Equipment ID",
    "Latitude",
    "Longitude",
    "PC26",
    "Engineer",
    "Request Date",
    "Forecasted Ready Date",
]

# -----------------------------
# Materials: raw pull columns
# -----------------------------
RAW_COLUMNS_MATERIALS: List[str] = [
    "PM #",
    "Mat Code",
    "EOY Target Type",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "Local DLT LAN ID",
    "DLT Address",
    "Construction Resource",
    "Construction Contact / Div Director",
    "Primary Hold-Up",
    "Resolve Date",
    "Material Requested Date",
]

# -----------------------------
# Materials: UI + Email column schemas (FINAL)
# -----------------------------
MATERIALS_TABLE1_UI_COLUMNS: List[str] = [
    "PM #",
    "Mat Code",
    "EOY Target Type",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "Local DLT LAN ID",
    "DLT Address",
    "Construction Resource",
    "Construction Contact",  # header rename
    "Email ID",
    "Material Requested Date",  # set to today (MM/DD/YYYY)
]

MATERIALS_TABLE1_EMAIL_COLUMNS: List[str] = [
    "PM #",
    "Mat Code",
    "EOY Target Type",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "Local DLT LAN ID",
    "DLT Address",
    "Construction Resource",
    "Construction Contact",  # header rename
    "Material Requested Date",  # set to today (MM/DD/YYYY)
]

MATERIALS_TABLE2_UI_COLUMNS: List[str] = [
    "PM #",
    "Mat Code",
    "EOY Target Type",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "Local DLT LAN ID",
    "DLT Address",
    "Construction Resource",
    "Construction Contact",       # header rename
    "Email ID",
    "Material Requested Date",    # set to today (MM/DD/YYYY)
    "Forecasted Delivery Date",   # header rename from Resolve Date
]

MATERIALS_TABLE2_EMAIL_COLUMNS: List[str] = [
    "PM #",
    "Mat Code",
    "EOY Target Type",
    "New Operating Number",
    "Device Type",
    "Circuit Name",
    "Division",
    "Local DLT LAN ID",
    "DLT Address",
    "Construction Resource",
    "Construction Contact",       # header rename
    "Material Requested Date",    # set to today (MM/DD/YYYY)
    "Forecasted Delivery Date",   # header rename from Resolve Date
]

# For backwards compatibility in code that imported MATERIALS_UI_COLUMNS
# (not used anymore for UI column ordering now that we have 2 tables)
MATERIALS_UI_COLUMNS: List[str] = MATERIALS_TABLE1_UI_COLUMNS.copy()

# Static lists DB/table
STATIC_LISTS_DB_PATH = os.path.join("data", "static_lists.db")
CONSTRUCTION_CONTACT_TABLE = "construction_contact_list"


# -----------------------------
# Helpers
# -----------------------------
def _norm_str(v) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in {"nan", "nat", "none"} else s


def _read_49_programs_df(tracker_path: str) -> pd.DataFrame:
    if not tracker_path:
        return pd.DataFrame()

    header_idx = HEADER_ROW_1_INDEXED - 1  # row 11 => header=10 (0-indexed)
    df = pd.read_excel(
        tracker_path,
        sheet_name=SHEET_NAME_49_2026,
        header=header_idx,
        engine=None,
    )
    df.columns = [str(c).strip() for c in df.columns]
    return df


def _safe_today_mdy() -> str:
    return datetime.now().strftime("%m/%d/%Y")


def _ensure_mdy_column(df: pd.DataFrame, col: str) -> None:
    if df is None or df.empty or col not in df.columns:
        return
    df[col] = df[col].apply(_to_mdy_str)


def _to_mdy_str(v) -> str:
    if pd.isna(v):
        return ""
    s = str(v).strip()
    if not s or s.lower() in {"nat", "nan", "none"}:
        return ""
    dt = pd.to_datetime(v, errors="coerce")
    if pd.isna(dt):
        return s
    return pd.Timestamp(dt).strftime("%m/%d/%Y")


def _load_construction_contact_map() -> dict[str, str]:
    mp: dict[str, str] = {}
    if not os.path.exists(STATIC_LISTS_DB_PATH):
        return mp

    conn = sqlite3.connect(STATIC_LISTS_DB_PATH)
    try:
        q = f'''
            SELECT "Construction Contact", "Email ID"
            FROM {CONSTRUCTION_CONTACT_TABLE}
        '''
        rows = conn.execute(q).fetchall()
        for name, email in rows:
            k = _norm_str(name)
            if k:
                mp[k.casefold()] = _norm_str(email)
    except Exception:
        return mp
    finally:
        conn.close()

    return mp


def _clean_pm_number(v) -> str:
    if pd.isna(v):
        return ""
    if isinstance(v, (int, float)):
        try:
            return str(int(v))
        except Exception:
            return str(v).strip()
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


def _parse_any_date(v) -> pd.Timestamp:
    if pd.isna(v):
        return pd.NaT
    s = str(v).strip()
    if not s or s.lower() in {"nan", "nat", "none"}:
        return pd.NaT
    dt = pd.to_datetime(v, errors="coerce", infer_datetime_format=True)
    if pd.isna(dt):
        dt = pd.to_datetime(s, errors="coerce", dayfirst=False)
    return pd.Timestamp(dt) if not pd.isna(dt) else pd.NaT


def _sort_by_email_id(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty or "Email ID" not in df.columns:
        return df
    email_key = df["Email ID"].apply(
        lambda x: (1, "") if _norm_str(x) == "" else (0, _norm_str(x).casefold())
    )
    return df.assign(_email_sort=email_key).sort_values("_email_sort").drop(columns=["_email_sort"])


# -----------------------------
# Existing: Settings table builder
# -----------------------------
def build_settings_request_tables_from_tracker(
    tracker_path: str,
) -> Tuple[pd.DataFrame, List[str], pd.DataFrame, List[str]]:
    if not tracker_path:
        empty1 = pd.DataFrame(columns=TABLE1_COLUMNS)
        empty2 = pd.DataFrame(columns=TABLE2_COLUMNS)
        return empty1, TABLE1_COLUMNS.copy(), empty2, TABLE2_COLUMNS.copy()

    base = _read_49_programs_df(tracker_path)
    if base is None or base.empty:
        empty1 = pd.DataFrame(columns=TABLE1_COLUMNS)
        empty2 = pd.DataFrame(columns=TABLE2_COLUMNS)
        return empty1, TABLE1_COLUMNS.copy(), empty2, TABLE2_COLUMNS.copy()

    present = [c for c in RAW_COLUMNS_SETTINGS if c in base.columns]
    df = base[present].copy()

    for c in RAW_COLUMNS_SETTINGS:
        if c not in df.columns:
            df[c] = ""

    ph = df["Primary Hold-Up"].apply(_norm_str).str.casefold()
    df = df[ph == "settings pending"].copy()

    if df.empty:
        empty1 = pd.DataFrame(columns=TABLE1_COLUMNS)
        empty2 = pd.DataFrame(columns=TABLE2_COLUMNS)
        return empty1, TABLE1_COLUMNS.copy(), empty2, TABLE2_COLUMNS.copy()

    for c in RAW_COLUMNS_SETTINGS:
        if c in df.columns:
            df[c] = df[c].apply(_norm_str)

    resolve_series = df["Resolve Date"]
    is_blank_resolve = resolve_series.isna() | (
        resolve_series.astype(str).str.strip().isin(["", "NaT", "nan", "None"])
    )
    t1 = df[is_blank_resolve].copy()

    today_mdy = _safe_today_mdy()
    req_norm = t1["Settings Requested Date"].apply(_norm_str)
    t1.loc[req_norm == "", "Settings Requested Date"] = today_mdy

    t1 = t1.rename(
        columns={
            "Settings Mapping Completed (PC26)": "PC26",
            "Equipment Settings Link": "Engineer",
            "Settings Requested Date": "Request Date",
        }
    )

    t1_out = pd.DataFrame(columns=TABLE1_COLUMNS)
    for c in TABLE1_COLUMNS:
        t1_out[c] = t1.get(c, "")
    t1_out = t1_out.fillna("")
    _ensure_mdy_column(t1_out, "Request Date")

    dt_resolve = pd.to_datetime(df["Resolve Date"], errors="coerce")
    today_date = pd.Timestamp(datetime.now().date())
    in_past = dt_resolve.notna() & (dt_resolve < today_date)
    t2 = df[in_past].copy()

    t2 = t2.rename(
        columns={
            "Settings Mapping Completed (PC26)": "PC26",
            "Equipment Settings Link": "Engineer",
            "Settings Requested Date": "Request Date",
            "Resolve Date": "Forecasted Ready Date",
        }
    )

    t2_out = pd.DataFrame(columns=TABLE2_COLUMNS)
    for c in TABLE2_COLUMNS:
        t2_out[c] = t2.get(c, "")
    t2_out = t2_out.fillna("")
    _ensure_mdy_column(t2_out, "Request Date")
    _ensure_mdy_column(t2_out, "Forecasted Ready Date")

    return t1_out, TABLE1_COLUMNS.copy(), t2_out, TABLE2_COLUMNS.copy()


# -----------------------------
# Materials table builders (Table 1 + Table 2)
# -----------------------------
def build_material_release_precommissioning_tables_from_tracker(
    tracker_path: str,
) -> Tuple[pd.DataFrame, List[str], pd.DataFrame, List[str]]:
    """
    Materials logic:
      - Filter Primary Hold-Up == "Device Delivery Pending"
      - Add Email ID from static list lookup using Construction Contact / Div Director
      - Split into:
          Table 1: Resolve Date blank/null/NaT
          Table 2: Resolve Date parseable AND in the past
      - For BOTH tables: set Material Requested Date = today's date (MM/DD/YYYY)
      - Rename headers:
          "Construction Contact / Div Director" -> "Construction Contact"
          Table2: "Resolve Date" -> "Forecasted Delivery Date"
    """
    empty1 = pd.DataFrame(columns=MATERIALS_TABLE1_UI_COLUMNS)
    empty2 = pd.DataFrame(columns=MATERIALS_TABLE2_UI_COLUMNS)
    if not tracker_path:
        return empty1, MATERIALS_TABLE1_UI_COLUMNS.copy(), empty2, MATERIALS_TABLE2_UI_COLUMNS.copy()

    base = _read_49_programs_df(tracker_path)
    if base is None or base.empty:
        return empty1, MATERIALS_TABLE1_UI_COLUMNS.copy(), empty2, MATERIALS_TABLE2_UI_COLUMNS.copy()

    present = [c for c in RAW_COLUMNS_MATERIALS if c in base.columns]
    df = base[present].copy()

    if "PM #" in df.columns:
        df["PM #"] = df["PM #"].apply(_clean_pm_number)

    for c in RAW_COLUMNS_MATERIALS:
        if c not in df.columns:
            df[c] = ""

    for c in RAW_COLUMNS_MATERIALS:
        df[c] = df[c].apply(_norm_str)

    ph = df["Primary Hold-Up"].apply(_norm_str).str.casefold()
    df = df[ph == "device delivery pending"].copy()

    if df.empty:
        return empty1, MATERIALS_TABLE1_UI_COLUMNS.copy(), empty2, MATERIALS_TABLE2_UI_COLUMNS.copy()

    contact_map = _load_construction_contact_map()

    def _lookup_email(contact_val: str) -> str:
        k = _norm_str(contact_val).casefold()
        return contact_map.get(k, "")

    df["Email ID"] = df["Construction Contact / Div Director"].apply(_lookup_email)

    # Split by Resolve Date
    resolve_dt = df["Resolve Date"].apply(_parse_any_date)
    today_date = pd.Timestamp(datetime.now().date())

    is_blank_resolve = resolve_dt.isna() | (df["Resolve Date"].astype(str).str.strip().isin(["", "NaT", "nan", "None"]))
    is_past_resolve = resolve_dt.notna() & (resolve_dt < today_date)

    t1 = df[is_blank_resolve].copy()
    t2 = df[is_past_resolve].copy()

    # Force Material Requested Date to today's date for both tables
    today_mdy = _safe_today_mdy()
    if "Material Requested Date" in t1.columns:
        t1["Material Requested Date"] = today_mdy
    # if "Material Requested Date" in t2.columns:
    #     t2["Material Requested Date"] = today_mdy

    # Header renames
    t1 = t1.rename(columns={"Construction Contact / Div Director": "Construction Contact"})
    t2 = t2.rename(columns={"Construction Contact / Div Director": "Construction Contact",
                            "Resolve Date": "Forecasted Delivery Date"})

    def _to_cols(df_in: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
        out = pd.DataFrame(columns=cols)
        if df_in is None or df_in.empty:
            return out
        for c in cols:
            out[c] = df_in.get(c, "")
        out = out.fillna("")
        out = _sort_by_email_id(out)  # only sorts if Email ID exists in schema
        return out

    t1_out = _to_cols(t1, MATERIALS_TABLE1_UI_COLUMNS)
    t2_out = _to_cols(t2, MATERIALS_TABLE2_UI_COLUMNS)
    _ensure_mdy_column(t2_out, "Forecasted Delivery Date")   # <--- add this
    # Resolve Date renamed to "Forecasted Delivery Date" — format it too
    _ensure_mdy_column(t2_out, "Material Requested Date")

    # Format it (MM/DD/YYYY)
    _ensure_mdy_column(t1_out, "Material Requested Date")

    return t1_out, MATERIALS_TABLE1_UI_COLUMNS.copy(), t2_out, MATERIALS_TABLE2_UI_COLUMNS.copy()
