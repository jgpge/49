# helpers/access_database/extract_data_from_access.py
from pathlib import Path
import pyodbc
import pandas as pd

__all__ = ["access_table_to_df"]

def access_table_to_df(db_path: str, table_name: str, password: str | None = None) -> pd.DataFrame:
    r"""
    Return the specified table from an Access .accdb/.mdb file as a pandas DataFrame.

    Example:
        df = access_table_to_df(
            r"C:\Users\ugupta\Downloads\WRO_EGI_SIP_Dashboard_Data.accdb",
            "tbl_WRODashboardData"
        )
    """
    db_path = str(Path(db_path).resolve())
    driver = "{Microsoft Access Driver (*.mdb, *.accdb)}"  # requires ACE ODBC driver
    pwd = f"PWD={password};" if password else ""
    conn_str = f"Driver={driver};DBQ={db_path};{pwd}"

    with pyodbc.connect(conn_str, autocommit=False) as conn:
        query = f"SELECT * FROM [{table_name}]"
        return pd.read_sql(query, conn)
