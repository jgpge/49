# helpers/coe_reports/current_stakeholder_holdup.py
from __future__ import annotations

import sqlite3
from typing import List, Tuple, Optional

import pandas as pd

from ledgers.rcc.coe_holdup_stakeholder_mapping import (
    COE_HOLDUP_TO_STAKEHOLDER,
    COE_IGNORE_PRIMARY_HOLDUPS,
)

OUTPUT_COLUMNS: List[str] = [
    "PM #",
    "Notification",
    "Mat Code",
    "Primary Hold-Up",
    "Stakeholder",
]

BASE_COLUMNS: List[str] = [
    "PM #",
    "Notification",
    "Mat Code",
    "Primary Hold-Up",
]


def build_current_stakeholder_holdup_df(*, db_path: str, table_name: str) -> tuple[pd.DataFrame, Optional[str]]:
    """
    Steps:
      1) Find latest timestamp in COE table
      2) Filter to only that timestamp
      3) Remove rows where Primary Hold-Up in {Job hold, Job cancelled, Job deferred}
      4) Keep cols: PM#, Notification, Mat Code, Primary Hold-Up
      5) Add Stakeholder column using mapping dict
    Returns: (df, latest_timestamp)
    """
    con = sqlite3.connect(db_path)
    try:
        # Latest timestamp
        latest_ts = None
        try:
            cur = con.cursor()
            cur.execute(f'SELECT MAX("timestamp") FROM "{table_name}" WHERE "timestamp" IS NOT NULL AND TRIM("timestamp") <> \'\'')
            latest_ts = cur.fetchone()[0]
        except Exception:
            latest_ts = None

        if not latest_ts:
            return pd.DataFrame(columns=OUTPUT_COLUMNS), None

        # Pull only the needed columns for latest snapshot
        q = f"""
            SELECT
                "PM #",
                "Notification",
                "Mat Code",
                "Primary Hold-Up"
            FROM "{table_name}"
            WHERE "timestamp" = ?
        """
        df = pd.read_sql_query(q, con, params=(latest_ts,))
    finally:
        con.close()

    if df.empty:
        return pd.DataFrame(columns=OUTPUT_COLUMNS), latest_ts

    # Clean strings
    for c in BASE_COLUMNS:
        if c in df.columns:
            df[c] = df[c].astype("string").str.strip()

    # Filter ignored hold-ups
    if "Primary Hold-Up" in df.columns:
        df = df[~df["Primary Hold-Up"].isin(COE_IGNORE_PRIMARY_HOLDUPS)]

    # Drop rows where all base cols are empty
    df = df.dropna(how="all", subset=BASE_COLUMNS)

    # Add Stakeholder mapping
    df["Stakeholder"] = df["Primary Hold-Up"].map(COE_HOLDUP_TO_STAKEHOLDER)

    # If unmapped, keep blank (so it's obvious, but doesn't break anything)
    df["Stakeholder"] = df["Stakeholder"].fillna("")

    # Enforce final column order
    for col in OUTPUT_COLUMNS:
        if col not in df.columns:
            df[col] = ""
    df = df[OUTPUT_COLUMNS]

    return df, latest_ts


def make_current_stakeholder_holdup_table(*, db_path: str, table_name: str) -> tuple[list[str], list[list[str]], int, Optional[str], int]:
    """
    Returns:
      columns: list[str]
      rows: list[list[str]]
      total_raw: int (rows in latest snapshot before ignore filter)
      latest_ts: str|None
      unmapped_count: int
    """
    df, latest_ts = build_current_stakeholder_holdup_df(db_path=db_path, table_name=table_name)
    if latest_ts is None:
        return OUTPUT_COLUMNS, [], 0, None, 0

    # total_raw: re-query just count of latest snapshot quickly
    total_raw = 0
    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        cur.execute(f'SELECT COUNT(*) FROM "{table_name}" WHERE "timestamp" = ?', (latest_ts,))
        total_raw = int(cur.fetchone()[0] or 0)
    except Exception:
        total_raw = 0
    finally:
        try:
            con.close()
        except Exception:
            pass

    unmapped_count = 0
    try:
        unmapped_count = int((df["Stakeholder"].astype(str).str.strip() == "").sum())
    except Exception:
        unmapped_count = 0

    rows = df.astype("string").fillna("").values.tolist()
    return OUTPUT_COLUMNS, rows, total_raw, latest_ts, unmapped_count
