# helpers/comments_updater/mwc49_tracker.py
from __future__ import annotations

import os
from typing import Dict, Tuple, List

from helpers.comments_updater.text_utils import normalize_pm, normalize_loc

SHEET_NAME = "49 Programs 2026"
HEADER_ROW = 11          # Excel row 11 has headers
DATA_START_ROW = 12      # data begins on row 12

COL_PM = "PM #"
COL_LOC = "PM-Location"
COL_NOTES_UPDATES = "Notes and Updates"


def apply_it_comments_to_mwc49_tracker(
    tracker_path: str,
    mapping: Dict[Tuple[str, str], str],
    *,
    debug_print_keys: bool = True,
    debug_limit: int = 2000,
) -> str:
    """
    Mutates tracker workbook IN-PLACE using Excel COM automation (pywin32),
    so we do NOT break external connections / tables / query ranges.

    Matches on (PM #, PM-Location) and prepends into "Notes and Updates".

    Requirements:
      - Windows + Excel installed
      - pip install pywin32
    """
    tracker_path = os.path.abspath(tracker_path)

    ext = os.path.splitext(tracker_path)[1].lower()
    if ext not in (".xlsx", ".xlsm"):
        raise ValueError("MWC49 Tracker must be .xlsx or .xlsm (in-place editing).")

    if not os.path.exists(tracker_path):
        raise ValueError(f"Tracker path not found: {tracker_path}")

    if not mapping:
        return (
            "MWC49 Tracker updates:\n"
            "- Mapping entries: 0\n"
            "- Rows updated: 0\n"
            "- Duplicate-start skipped: 0\n"
            "- Empty new note skipped: 0\n"
            "- Mapping keys not found in tracker: 0\n"
            "(No mapping entries were provided.)"
        )

    try:
        import win32com.client  # type: ignore
    except Exception:
        raise RuntimeError(
            "pywin32 is required to update the tracker without corrupting it.\n"
            "Install it with:\n\n"
            "  pip install pywin32\n\n"
            "Then restart your app and try again."
        )

    print(f"\n[MWC49 Tracker] Updating via Excel COM (safe save). File: {tracker_path}")
    print(f"[MWC49 Tracker] Incoming mapping keys: {len(mapping)}")

    excel = None
    wb = None

    updated = 0
    duplicates_skipped = 0
    empty_new_note = 0
    no_match = 0
    missing_keys: List[Tuple[str, str]] = []

    # For debug printing control
    printed = 0

    try:
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.AskToUpdateLinks = False

        # Open without updating links/prompts
        # UpdateLinks=0 prevents link updates popup; ReadOnly=False ensures we can write
        wb = excel.Workbooks.Open(
            tracker_path,
            UpdateLinks=0,
            ReadOnly=False,
            IgnoreReadOnlyRecommended=True,
            AddToMru=False,
        )

        # Ensure calculations are up-to-date so formula columns (PM-Location) return real values
        try:
            excel.CalculateFullRebuild()
        except Exception:
            try:
                excel.CalculateFull()
            except Exception:
                pass

        # Get sheet
        try:
            ws = wb.Worksheets(SHEET_NAME)
        except Exception:
            raise ValueError(f'Tracker workbook is missing sheet "{SHEET_NAME}".')

        # Find column indexes from header row
        used_cols = ws.UsedRange.Columns.Count
        header_vals = ws.Range(ws.Cells(HEADER_ROW, 1), ws.Cells(HEADER_ROW, used_cols)).Value

        # header_vals is a tuple-of-tuples like ((h1,h2,...),) or sometimes a single tuple
        if header_vals is None:
            raise ValueError(f'No headers found on row {HEADER_ROW} of "{SHEET_NAME}".')

        # Normalize header row into a flat list
        if isinstance(header_vals, tuple) and len(header_vals) == 1 and isinstance(header_vals[0], tuple):
            headers = list(header_vals[0])
        elif isinstance(header_vals, tuple):
            headers = list(header_vals)
        else:
            headers = [header_vals]

        def _find_col(name: str) -> int:
            for idx, hv in enumerate(headers, start=1):
                if hv is None:
                    continue
                if str(hv).strip() == name:
                    return idx
            raise ValueError(
                f'Tracker sheet "{SHEET_NAME}" is missing required column "{name}". '
                f"Found headers sample: {sorted({str(h).strip() for h in headers if h})[:30]}..."
            )

        pm_col = _find_col(COL_PM)
        loc_col = _find_col(COL_LOC)
        notes_col = _find_col(COL_NOTES_UPDATES)

        # Determine last row based on UsedRange
        last_row = ws.UsedRange.Rows.Count + ws.UsedRange.Row - 1
        if last_row < DATA_START_ROW:
            last_row = DATA_START_ROW

        print(f"[MWC49 Tracker] Sheet={repr(SHEET_NAME)} Used last_row={last_row} used_cols={used_cols}")
        print(f"[MWC49 Tracker] Columns: PM={pm_col}, PM-Location={loc_col}, Notes={notes_col}")

        # Build index of tracker keys -> row number
        tracker_index: Dict[Tuple[str, str], int] = {}

        # Read PM and PM-Location columns in one shot (fast)
        pm_range = ws.Range(ws.Cells(DATA_START_ROW, pm_col), ws.Cells(last_row, pm_col)).Value
        loc_range = ws.Range(ws.Cells(DATA_START_ROW, loc_col), ws.Cells(last_row, loc_col)).Value

        # These come back as tuples of tuples: ((v1,), (v2,), ...)
        def _col_to_list(v):
            if v is None:
                return []
            if isinstance(v, tuple):
                out = []
                for row in v:
                    if isinstance(row, tuple) and len(row) == 1:
                        out.append(row[0])
                    else:
                        out.append(row)
                return out
            return [v]

        pm_list = _col_to_list(pm_range)
        loc_list = _col_to_list(loc_range)

        n = min(len(pm_list), len(loc_list))
        for i in range(n):
            r = DATA_START_ROW + i
            pm = normalize_pm(pm_list[i])
            loc = normalize_loc(loc_list[i])
            if not pm and not loc:
                continue
            key = (pm, loc)
            if key not in tracker_index:
                tracker_index[key] = r

        print(f"[MWC49 Tracker] Indexed tracker keys={len(tracker_index)}")

        # Apply updates for each mapping key (log each attempt)
        for i, (key, new_note_raw) in enumerate(mapping.items(), start=1):
            pm, loc = key
            new_note = (new_note_raw or "").strip()

            if debug_print_keys and printed < debug_limit:
                print(f"\n[MWC49 Tracker] ({i}/{len(mapping)}) Try match PM#={repr(pm)} | PM-Location={repr(loc)}")
                printed += 1

            row = tracker_index.get(key)
            if row is None:
                no_match += 1
                missing_keys.append(key)
                if debug_print_keys and printed <= debug_limit:
                    print("[MWC49 Tracker]   ❌ No match")
                continue

            if not new_note:
                empty_new_note += 1
                if debug_print_keys and printed <= debug_limit:
                    print(f"[MWC49 Tracker]   ⚠️ Match at row {row}, but new note empty -> skip")
                continue

            cell = ws.Cells(row, notes_col)
            old_val = "" if cell.Value is None else str(cell.Value).strip()

            # idempotency: if already starts with same note, skip
            if old_val and old_val.casefold().startswith(new_note.casefold()):
                duplicates_skipped += 1
                if debug_print_keys and printed <= debug_limit:
                    print(f"[MWC49 Tracker]   ↩️ Already starts with same note at row {row} -> skip")
                continue

            combined = f"{new_note} {old_val}".strip() if old_val else new_note
            cell.Value = combined
            updated += 1

            if debug_print_keys and printed <= debug_limit:
                prev = new_note[:120] + ("..." if len(new_note) > 120 else "")
                print(f"[MWC49 Tracker]   ✅ Updated row {row} (prepended: {repr(prev)})")

        # Save in-place (Excel preserves external ranges)
        wb.Save()
        print(f"\n[MWC49 Tracker] Saved successfully (Excel COM): {tracker_path}")

    finally:
        # Clean shutdown to avoid orphan Excel.exe processes
        try:
            if wb is not None:
                wb.Close(SaveChanges=True)
        except Exception:
            pass
        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass

    if missing_keys:
        print("\n[MWC49 Tracker] Sample missing keys (first 25):")
        for pm, loc in missing_keys[:25]:
            print(f"  - PM#={repr(pm)} | PM-Location={repr(loc)}")
        if len(missing_keys) > 25:
            print(f"  ... and {len(missing_keys) - 25} more")

    return (
        f"MWC49 Tracker updates:\n"
        f"- File: {tracker_path}\n"
        f"- Mapping entries: {len(mapping)}\n"
        f"- Indexed tracker keys: {len(tracker_index)}\n"
        f"- Rows updated: {updated}\n"
        f"- Duplicate-start skipped: {duplicates_skipped}\n"
        f"- Empty new note skipped: {empty_new_note}\n"
        f"- Mapping keys not found in tracker: {no_match}"
    )
