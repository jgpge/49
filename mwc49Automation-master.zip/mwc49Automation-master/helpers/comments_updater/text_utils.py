# helpers/comments_updater/text_utils.py
from __future__ import annotations

import re
from typing import Any


_DATE_PATTERNS = [
    # 12/31 or 12-31 or 12/31/2025 or 12-31-25
    r"\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b",
    # 2025-12-31 or 2025/12/31
    r"\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b",
]

_DATE_RE = re.compile("|".join(_DATE_PATTERNS))


def normalize_pm(v: Any) -> str:
    """
    Normalize PM # values:
      - strips whitespace
      - converts floats like 12345.0 -> 12345
    """
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""

    # strip trailing .0 patterns
    if s.endswith(".0"):
        return s[:-2].strip()

    # if numeric-like float
    if "." in s:
        try:
            f = float(s)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass

    return s


def normalize_loc(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def trim_to_latest_update_chunk(note: str) -> str:
    """
    Keep only the first (latest) update chunk from a chronological notes string,
    where each chunk usually begins with a date token.

    We detect the first date token and the second date token; keep substring
    from start up to just before the second date token.

    If we can't find a second date token, return the original note stripped.
    """
    if note is None:
        return ""
    s = str(note).strip()
    if not s:
        return ""

    # Find date tokens. Notes are "latest first", so we want the first chunk.
    matches = list(_DATE_RE.finditer(s))
    if len(matches) < 2:
        # no clear second date; return as-is
        return s

    # Keep from beginning up to the start of the 2nd date match
    cut = matches[1].start()
    out = s[:cut].strip()

    # Clean common trailing separators
    out = out.rstrip(" -•|;,:")
    return out.strip()
