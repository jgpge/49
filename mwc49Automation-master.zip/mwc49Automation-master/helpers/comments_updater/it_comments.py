# helpers/comments_updater/it_comments.py
from __future__ import annotations

import os
from datetime import datetime
from typing import Dict, Tuple, Any, Optional, List

import pandas as pd
from openpyxl import load_workbook

from helpers.comments_updater.text_utils import (
    normalize_pm,
    normalize_loc,
    trim_to_latest_update_chunk,
)

# Original marker (keep as reference)
MARKER_TEXT = "2026 JOBS FOR IT SURVEY WO"

# We will match using tokens to tolerate small text variations.
# (e.g., "2026 JOBS FOR IT SURVEY W/O", extra spaces, etc.)
MARKER_TOKENS = ["2026", "jobs", "survey", "wo"]  # 'it' is often present but not required


# These are the only columns we need from the IT table
COL_PM = "PM #"
COL_LOC = "PM-LOCATION"
COL_NOTES = "Escalation and/or Status Notes"


def _parse_sheet_date(name: str) -> Optional[datetime]:
    """
    Parses sheet names like '11-06-25' (mm-dd-yy).
    Returns a datetime if it matches, else None.
    """
    s = str(name).strip()
    try:
        return datetime.strptime(s, "%m-%d-%y")
    except Exception:
        return None


def _pick_latest_dated_sheet(sheetnames: list[str]) -> str:
    """
    Picks the sheet with the latest DATE among sheets named like mm-dd-yy.
    Example: ['11-06-25','11-05-25','10-08-25'] -> '11-06-25'
    """
    dated: list[tuple[datetime, str]] = []
    for name in sheetnames:
        d = _parse_sheet_date(name)  # parses %m-%d-%y
        if d is not None:
            dated.append((d, name))

    if not dated:
        raise ValueError(
            "Could not find any sheets named like mm-dd-yy in IT Comments workbook."
        )

    latest_dt, latest_name = max(dated, key=lambda x: x[0])

    # Console logs so you can verify
    dated_sorted = [n for _, n in sorted(dated, key=lambda x: x[0])]
    print(f"[IT Comments] Date-like sheets found (sorted): {dated_sorted}")
    print(f"[IT Comments] Using latest sheet by date: {latest_name} ({latest_dt.strftime('%m-%d-%y')})")

    return latest_name


def _cell_matches_marker(v) -> bool:
    if v is None:
        return False
    s = str(v).strip().casefold()
    if not s:
        return False

    # Token-based match
    return all(tok in s for tok in MARKER_TOKENS)


def _dump_col_a(ws, max_lines: int = 40) -> None:
    """
    Console dump: first N non-empty values in column A with row numbers.
    Helpful for debugging marker text / placement.
    """
    print("[IT Comments] Debug dump: first non-empty values in column A:")
    printed = 0
    for r in range(1, ws.max_row + 1):
        v = ws.cell(row=r, column=1).value
        if v is None:
            continue
        s = str(v).strip()
        if not s:
            continue
        print(f"  A{r}: {s}")
        printed += 1
        if printed >= max_lines:
            break
    if printed == 0:
        print("  (No non-empty values found in column A)")


def _find_marker_row(ws) -> int:
    """
    Find row index (1-based) where column A contains the marker.
    More robust: looks for tokens like ['2026','jobs','survey','wo'].
    """
    for r in range(1, ws.max_row + 1):
        v = ws.cell(row=r, column=1).value
        if _cell_matches_marker(v):
            print(f"[IT Comments] Marker matched in column A at row {r}: {str(v).strip()}")
            return r

    # If not found, dump useful info to console
    print(f"[IT Comments] Marker not found using tokens={MARKER_TOKENS}")
    _dump_col_a(ws, max_lines=40)

    # Raise a clearer error (still concise for UI)
    raise ValueError(
        f'Could not find "{MARKER_TEXT}" (or equivalent token match) in column A of the latest sheet.'
    )


def _header_to_col_index(ws, header_row: int) -> dict[str, int]:
    """
    Returns mapping of header text -> 1-based column index for that row.
    """
    out: dict[str, int] = {}
    for c in range(1, ws.max_column + 1):
        v = ws.cell(row=header_row, column=c).value
        if v is None:
            continue
        txt = str(v).strip()
        if txt:
            out[txt] = c
    return out


def build_it_comments_mapping(it_workbook_path: str) -> Tuple[Dict[Tuple[str, str], str], Dict[str, Any]]:
    """
    Returns:
      mapping: {(pm, pm_location): trimmed_latest_note}
      meta: {sheet, rows, nonempty, trimmed, df_preview_rows}
    """
    ext = os.path.splitext(it_workbook_path)[1].lower()
    if ext not in (".xlsx", ".xlsm"):
        raise ValueError("IT Comments workbook must be .xlsx or .xlsm")

    wb = load_workbook(it_workbook_path, read_only=True, data_only=True)

    # --- DEBUG: list all sheets ---
    all_sheets = list(wb.sheetnames or [])
    print(f"[IT Comments] Workbook has {len(all_sheets)} sheets:")
    for i, s in enumerate(all_sheets, start=1):
        print(f"  {i:02d}. {repr(s)}")

    sheet = _pick_latest_dated_sheet(all_sheets)
    ws = wb[sheet]

    marker_row = _find_marker_row(ws)
    header_row = marker_row + 1
    data_start = marker_row + 2

    hdr = _header_to_col_index(ws, header_row)

    # Ensure required columns exist
    for need in (COL_PM, COL_LOC, COL_NOTES):
        if need not in hdr:
            print(f"[IT Comments] Headers found at row {header_row}: {list(hdr.keys())}")
            raise ValueError(
                f'IT table is missing required column "{need}" under the "{MARKER_TEXT}" section.'
            )

    pm_col = hdr[COL_PM]
    loc_col = hdr[COL_LOC]
    notes_col = hdr[COL_NOTES]

    mapping: Dict[Tuple[str, str], str] = {}

    rows_read = 0
    nonempty = 0
    trimmed = 0

    # We'll also build a debug df (final after trimming) to print
    df_rows: list[dict[str, str]] = []

    # Iterate until we hit a fully blank key row (pm and location empty) + empty notes
    for r in range(data_start, ws.max_row + 1):
        pm_raw = ws.cell(row=r, column=pm_col).value
        loc_raw = ws.cell(row=r, column=loc_col).value
        notes_raw = ws.cell(row=r, column=notes_col).value

        pm = normalize_pm(pm_raw)
        loc = normalize_loc(loc_raw)

        if (pm == "" and loc == "" and (notes_raw is None or str(notes_raw).strip() == "")):
            break

        rows_read += 1

        if not pm or not loc:
            continue

        notes = "" if notes_raw is None else str(notes_raw).strip()
        if not notes:
            continue

        nonempty += 1
        latest_only = trim_to_latest_update_chunk(notes).strip()
        if latest_only != notes.strip():
            trimmed += 1

        mapping[(pm, loc)] = latest_only

        # for debug printing
        df_rows.append(
            {
                "PM #": pm,
                "PM-LOCATION": loc,
                "Escalation and/or Status Notes": latest_only,
            }
        )

    # --- DEBUG: print final df after trimming older comments ---
    try:
        df_dbg = pd.DataFrame(df_rows, columns=["PM #", "PM-LOCATION", "Escalation and/or Status Notes"])
        print("\n[IT Comments] FINAL DF (after trimming older comments):")
        print(f"[IT Comments] Rows: {len(df_dbg)} | Cols: {list(df_dbg.columns)}")
        if len(df_dbg) > 0:
            # print a reasonable chunk
            print(df_dbg.head(80).to_string(index=False))
        else:
            print("(empty)")
    except Exception as e:
        print(f"[IT Comments] DEBUG print(final df) failed: {e}")

    print(f"\n[IT Comments] Built mapping entries: {len(mapping)} (rows_read={rows_read}, notes_nonempty={nonempty}, trimmed={trimmed})")

    meta = {
        "sheet": sheet,
        "rows": rows_read,
        "nonempty": nonempty,
        "trimmed": trimmed,
    }
    return mapping, meta
