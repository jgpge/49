# helpers/dcd_reports/current_stakeholder_holdup.py
from __future__ import annotations

import sqlite3
from typing import Tuple, List, Optional
import pandas as pd

from ledgers.rcc.dcd_holdup_stakeholder_mapping import DCD_HOLDUP_TO_STAKEHOLDER


_IGNORE_HOLDUPS = {
    "job hold",
    "job cancelled",
    "job canceled",
    "job deferred",
}


def _norm(v) -> str:
    return str(v).strip() if v is not None else ""


def _norm_casefold(v) -> str:
    return _norm(v).casefold()


def make_current_stakeholder_holdup_table(
    db_path: str,
    table_name: str,
) -> Tuple[List[str], List[List[str]], int, Optional[str], int]:
    """
    DCD Current Stakeholder Holdup

    Steps:
      1) find latest timestamp in dcd table
      2) filter rows to only latest timestamp
      3) remove rows whose Primary Hold-Up is in {Job hold, Job cancelled, Job deferred}
      4) keep cols: PM, Notification #, Mat Code, Primary Hold-Up
      5) add Stakeholder via mapping dict (unmapped -> "UNMAPPED")
      6) return columns, rows, total_raw_latest, latest_ts, unmapped_count
    """
    columns = ["PM", "Notification #", "Mat Code", "Primary Hold-Up", "Stakeholder"]

    with sqlite3.connect(db_path) as con:
        # 1) latest timestamp
        cur = con.cursor()
        cur.execute(f'SELECT MAX("timestamp") FROM "{table_name}"')
        latest_ts = cur.fetchone()[0]

        if not latest_ts:
            return columns, [], 0, None, 0

        # 2) read latest snapshot
        df = pd.read_sql_query(
            f"""
            SELECT
                "PM",
                "Notification #",
                "Mat Code",
                "Primary Hold-Up"
            FROM "{table_name}"
            WHERE "timestamp" = ?
            """,
            con,
            params=(latest_ts,),
        )

    total_raw_latest = len(df)

    if df.empty:
        return columns, [], total_raw_latest, latest_ts, 0

    # 3) filter ignored holdups
    df["__ph_norm"] = df["Primary Hold-Up"].map(_norm_casefold)
    df = df[~df["__ph_norm"].isin(_IGNORE_HOLDUPS)].copy()
    df.drop(columns=["__ph_norm"], inplace=True, errors="ignore")

    # 4/5) map stakeholder
    def map_stk(v):
        key = _norm(v)
        if not key:
            return "UNMAPPED"
        return DCD_HOLDUP_TO_STAKEHOLDER.get(key, "UNMAPPED")

    df["Stakeholder"] = df["Primary Hold-Up"].map(map_stk)
    unmapped = int((df["Stakeholder"] == "UNMAPPED").sum())

    # Ensure ordering + string safety for UI/export
    df = df[["PM", "Notification #", "Mat Code", "Primary Hold-Up", "Stakeholder"]].copy()
    df = df.fillna("")

    rows: List[List[str]] = df.astype(str).values.tolist()
    return columns, rows, total_raw_latest, latest_ts, unmapped
