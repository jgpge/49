from html import escape
from typing import Iterable, Sequence

def build_email_table_body(
    rows: Iterable[Sequence[str]],
    *,
    title: str | None = None
) -> str:
    """
    Returns an HTML string suitable for Outlook's compose window.
    - rows: iterable of [line_item, value]
    - title: optional heading above the table
    """
    # Inline CSS for Outlook safety (duplicate font on all elements for Outlook)
    base_font = "font-family:Arial; font-size:11pt;"
    wrapper_style = f"{base_font} color:#000000;"
    table_style   = (
        "border-collapse:collapse; width:800px;"
        "border:1px solid #D1D5DB; table-layout:fixed;"
    )
    th_style = (
        f"text-align:left; padding:8px; border:1px solid #D1D5DB;"
        f"background:#F3F4F6; font-weight:bold; vertical-align:middle; {base_font}"
    )
    # Shared cell styles
    td_style_common = (
        f"padding:8px; border:1px solid #D1D5DB; vertical-align:middle; "
        f"word-wrap:break-word; {base_font}"
    )
    # First column (bold)
    td_left_style = td_style_common + " font-weight:bold;"
    # Second column (normal)
    td_right_style = td_style_common

    # Build rows with zebra striping (no CSS selectors in Outlook -> set per-row bg)
    row_html_parts = []
    for i, r in enumerate(rows):
        line_item = escape(str(r[0])) if len(r) > 0 else ""
        value = escape(str(r[1])) if len(r) > 1 else ""
        bg = "#FFFFFF" if i % 2 == 0 else "#FAFAFA"
        row_html_parts.append(
            f'<tr style="background:{bg};">'
            f'<td style="{td_left_style}">{line_item}</td>'
            f'<td style="{td_right_style}">{value}</td>'
            '</tr>'
        )

    title_html = (
        f'<h3 style="margin:0 0 8px 0; {base_font}">{escape(title)}</h3>'
        if title else ""
    )

    body_html = (
        f'<div style="{wrapper_style}">'
        f'{title_html}'
        f'<table role="table" style="{table_style}">'
        f'<thead><tr>'
        f'<th style="{th_style}"></th>'
        f'<th style="{th_style}"></th>'
        f'</tr></thead>'
        f'<tbody>'
        + "".join(row_html_parts if row_html_parts else [
            f'<tr><td style="{td_left_style}" colspan="2"><em>No items</em></td></tr>'
        ])
        + '</tbody></table></div>'
    )
    return body_html