# text_extractor.py
# Helper for extracting text from a fixed box on a PDF page
# (0,0) is interpreted at the TOP-LEFT of the page.

from __future__ import annotations
import re
import fitz  # PyMuPDF


def _top_left_to_pdf_rect(page: fitz.Page, x_pt: float, y_pt: float, w_pt: float, h_pt: float) -> fitz.Rect:
    """
    Convert a rectangle defined in TOP-LEFT origin coordinates (x,y,w,h) [points]
    into a PyMuPDF Rect (PDF coords: origin bottom-left), then clip to page.
    """
    page_w, page_h = page.rect.width, page.rect.height
    x0 = x_pt
    y_top = y_pt
    x1 = x0 + w_pt
    y1 = page_h - y_top      # top edge in PDF coord
    y0 = y1 - h_pt           # bottom edge
    rect = fitz.Rect(x0, y0, x1, y1)
    return rect & page.rect   # clip to page bounds


class PDFTextExtractor:
    """
    Create once per PDF, then call .extract(page_number, x, y, w, h).

    Notes:
      - page_number is 1-based (1 = first page).
      - x, y, w, h are in points. (0,0) is TOP-LEFT of the page.
      - If the region contains no text, returns "".
    """

    def __init__(self, pdf_path: str):
        self._doc = fitz.open(pdf_path)

    def close(self):
        if self._doc is not None:
            self._doc.close()
            self._doc = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def extract(self, page_number: int, x: float, y: float, w: float, h: float) -> str:
        if self._doc is None:
            raise RuntimeError("PDF is already closed.")

        if page_number < 1 or page_number > self._doc.page_count:
            raise ValueError(f"page_number out of range: {page_number} (1..{self._doc.page_count})")

        page = self._doc.load_page(page_number - 1)
        clip_rect = _top_left_to_pdf_rect(page, x, y, w, h)

        if clip_rect.is_empty or clip_rect.get_area() <= 0:
            return ""

        txt = page.get_text("text", clip=clip_rect)
        # Normalize line breaks into spaces and collapse whitespace
        txt = txt.replace("\r\n", "\n").replace("\r", "\n")  # normalize CRLF -> LF
        txt = re.sub(r"\n\s*\n+", "\n", txt)                 # collapse blank lines to a single \n
        return txt
