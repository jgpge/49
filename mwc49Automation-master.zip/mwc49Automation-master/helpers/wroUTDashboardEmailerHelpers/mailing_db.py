# helpers/mailing_db.py
from __future__ import annotations
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Iterable, Optional

# Minimal seed to keep EA/Non-EA info if table is empty
LEGACY_EA_SEED = {
    "T.0010248": "EA",
    "T.0010513": "EA",
    "T.0004281": "EA",
    "T.0009715": "EA",
}

PM_SEED_ROWS: list[tuple[str, str]] = [
    ("Craig Steigerwalt", "c7s0@pge.com"),
    ("Tori Evins", "vxe8@pge.com"),
    ("Brook Priest", "b4po@pge.com"),
    ("Mike Neer", "mcn3@pge.com"),
    ("Matt Grant", "mogl@pge.com"),
    ("Omar Shabana", "o1s7@pge.com"),
    ("Brigitte Perera", "b4pe@pge.com"),
    ("Ronak Mehrabi", "rr1q@pge.com"),
    ("Ali Hasanain", "a5hr@pge.com"),
    ("Gary Bagga", "g5by@pge.com"),
    ("Alejandro Puffelis", "a0pv@pge.com"),
    ("Nadia Temacini", "n2tv@pge.com"),
    ("Jigar Thakkar", "jzt8@pge.com"),
]

# ----------------------------
# Schemas
# ----------------------------

# V3: add pm_name column (new order: tdot, pm_name, project_name, ea_non_ea)
SCHEMA_SQL_MAILING_V3 = """
CREATE TABLE IF NOT EXISTS mailing_list (
    tdot TEXT PRIMARY KEY,
    pm_name TEXT NOT NULL,
    project_name TEXT NOT NULL,
    ea_non_ea TEXT NOT NULL
);
"""

SCHEMA_SQL_PM_DIR = """
CREATE TABLE IF NOT EXISTS pm_directory (
    lan_id TEXT PRIMARY KEY,
    pm_name TEXT NOT NULL
);
"""

class MailingDB:
    def __init__(self, db_path: str | Path = "data/mailing_list.db"):
        self.db_path = str(Path(db_path).resolve())
        self._ensure()

    @staticmethod
    def _get_columns(con: sqlite3.Connection, table: str) -> list[str]:
        try:
            rows = con.execute(f"PRAGMA table_info('{table}')").fetchall()
            return [r[1] for r in rows]
        except sqlite3.Error:
            return []

    def _ensure(self):
        with sqlite3.connect(self.db_path) as con:
            con.execute("PRAGMA journal_mode=WAL;")

            # PM directory exists & seed
            con.execute(SCHEMA_SQL_PM_DIR)
            (n_pm,) = con.execute("SELECT COUNT(*) FROM pm_directory;").fetchone()
            if n_pm == 0:
                con.executemany(
                    "INSERT OR IGNORE INTO pm_directory (lan_id, pm_name) VALUES (?, ?);",
                    [(lan.strip(), name.strip()) for (name, lan) in PM_SEED_ROWS],
                )

            # Mailing list migrations
            existing_cols = self._get_columns(con, "mailing_list")

            if not existing_cols:
                # Fresh DB
                con.execute(SCHEMA_SQL_MAILING_V3)
            else:
                old_like = {"tdot", "to_emails", "cc_emails", "ea_non_ea"}                # legacy
                v2_like  = {"tdot", "project_name", "ea_non_ea"}                           # V2
                v3_like  = {"tdot", "pm_name", "project_name", "ea_non_ea"}               # V3

                s = set(existing_cols)
                if s == v3_like:
                    pass  # already good
                elif s == v2_like:
                    # Add pm_name (default '')
                    con.execute("ALTER TABLE mailing_list RENAME TO mailing_list_old;")
                    con.execute(SCHEMA_SQL_MAILING_V3)
                    con.execute("""
                        INSERT INTO mailing_list (tdot, pm_name, project_name, ea_non_ea)
                        SELECT tdot, '' AS pm_name, project_name, ea_non_ea
                        FROM mailing_list_old;
                    """)
                    con.execute("DROP TABLE mailing_list_old;")
                elif s == old_like:
                    # Legacy -> V3 (preserve tdot & ea_non_ea; project empty; pm_name empty)
                    con.execute("ALTER TABLE mailing_list RENAME TO mailing_list_old;")
                    con.execute(SCHEMA_SQL_MAILING_V3)
                    con.execute("""
                        INSERT INTO mailing_list (tdot, pm_name, project_name, ea_non_ea)
                        SELECT tdot, '' AS pm_name, '' AS project_name, ea_non_ea
                        FROM mailing_list_old;
                    """)
                    con.execute("DROP TABLE mailing_list_old;")
                else:
                    # Unknown; preserve old as backup and create clean V3
                    con.execute("ALTER TABLE mailing_list RENAME TO mailing_list_backup;")
                    con.execute(SCHEMA_SQL_MAILING_V3)

            # Seed if empty
            (n_mail,) = con.execute("SELECT COUNT(*) FROM mailing_list;").fetchone()
            if n_mail == 0 and LEGACY_EA_SEED:
                con.executemany(
                    "INSERT OR IGNORE INTO mailing_list (tdot, pm_name, project_name, ea_non_ea) VALUES (?, ?, ?, ?);",
                    [(tdot, "", "", ea) for tdot, ea in LEGACY_EA_SEED.items()],
                )

            con.commit()

    # ----------------------------
    # mailing_list (V3: tdot, pm_name, project_name, ea_non_ea)
    # ----------------------------
    def all_rows(self) -> list[tuple[str, str, str, str]]:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute("""
                SELECT tdot, pm_name, project_name, ea_non_ea
                FROM mailing_list
                ORDER BY tdot;
            """)
            return cur.fetchall()

    def add_row(self, tdot: str, pm_name: str, project_name: str, ea_non_ea: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "INSERT INTO mailing_list (tdot, pm_name, project_name, ea_non_ea) VALUES (?, ?, ?, ?);",
                (tdot.strip(), pm_name.strip(), project_name.strip(), ea_non_ea.strip()),
            )
            con.commit()

    def update_row(self, tdot: str, pm_name: str, project_name: str, ea_non_ea: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "UPDATE mailing_list SET pm_name = ?, project_name = ?, ea_non_ea = ? WHERE tdot = ?;",
                (pm_name.strip(), project_name.strip(), ea_non_ea.strip(), tdot.strip()),
            )
            con.commit()

    def delete_row(self, tdot: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("DELETE FROM mailing_list WHERE tdot = ?;", (tdot.strip(),))
            con.commit()

    def replace_all(self, rows: Iterable[tuple[str, str, str, str]]) -> None:
        """
        rows: Iterable of (tdot, pm_name, project_name, ea_non_ea)
        """
        with sqlite3.connect(self.db_path) as con:
            con.execute("DELETE FROM mailing_list;")
            con.executemany(
                "INSERT INTO mailing_list (tdot, pm_name, project_name, ea_non_ea) VALUES (?, ?, ?, ?);",
                [(tdot.strip(), pm.strip(), proj.strip(), ea.strip()) for (tdot, pm, proj, ea) in rows],
            )
            con.commit()

    def get_row(self, tdot: str) -> Optional[tuple[str, str, str, str]]:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute(
                "SELECT tdot, pm_name, project_name, ea_non_ea FROM mailing_list WHERE tdot = ?;",
                (tdot.strip(),),
            )
            return cur.fetchone()

    # ----------------------------
    # PM Directory helpers
    # ----------------------------
    def pm_all(self) -> list[tuple[str, str]]:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute("SELECT lan_id, pm_name FROM pm_directory ORDER BY pm_name COLLATE NOCASE;")
            return cur.fetchall()

    def pm_names(self) -> list[str]:
        """Return just PM names, sorted case-insensitively (for dropdowns)."""
        return [name for _, name in self.pm_all()]

    def pm_add(self, pm_name: str, lan_id: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "INSERT INTO pm_directory (lan_id, pm_name) VALUES (?, ?);",
                (lan_id.strip(), pm_name.strip()),
            )
            con.commit()

    def pm_update(self, lan_id: str, pm_name: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("UPDATE pm_directory SET pm_name = ? WHERE lan_id = ?;", (pm_name.strip(), lan_id.strip()))
            con.commit()

    def pm_delete(self, lan_id: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("DELETE FROM pm_directory WHERE lan_id = ?;", (lan_id.strip(),))
            con.commit()

    def pm_replace_all(self, rows: Iterable[tuple[str, str]]) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute("DELETE FROM pm_directory;")
            con.executemany(
                "INSERT INTO pm_directory (lan_id, pm_name) VALUES (?, ?);",
                [(lan.strip(), name.strip()) for (name, lan) in rows],
            )
            con.commit()

    def pm_get_by_lan(self, lan_id: str) -> Optional[tuple[str, str]]:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute("SELECT lan_id, pm_name FROM pm_directory WHERE lan_id = ?;", (lan_id.strip(),))
            return cur.fetchone()

    def pm_get_by_name(self, pm_name: str) -> list[tuple[str, str]]:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute(
                "SELECT lan_id, pm_name FROM pm_directory WHERE pm_name LIKE ? ORDER BY pm_name COLLATE NOCASE;",
                (f"%{pm_name}%",),
            )
            return cur.fetchall()

    def pm_get_lan_exact(self, pm_name: str) -> str | None:
        with sqlite3.connect(self.db_path) as con, closing(con.cursor()) as cur:
            cur.execute("SELECT lan_id FROM pm_directory WHERE LOWER(pm_name) = LOWER(?) LIMIT 1;", (pm_name.strip(),))
            row = cur.fetchone()
            return row[0] if row else None
