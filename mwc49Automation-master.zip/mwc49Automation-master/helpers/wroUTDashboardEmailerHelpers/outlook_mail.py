# outlook_mail.py
from __future__ import annotations
from pathlib import Path
import win32com.client as win32
import os, shutil, win32com
import win32com.client.gencache as gencache

def create_outlook_draft_with_attachment(
    *,
    to: str = "",
    cc: str = "",
    subject: str = "",
    body_html: str = ""
) -> None:
    """
    Opens an Outlook compose window (draft) with the given attachment.
    User can fill To/CC/Subject/Body and click Send.
    """
    
    outlook = win32.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)  # 0 = olMailItem

    # Show the window first so Outlook loads the default signature
    mail.Display()  # non-modal; use Display(True) if you want modal

    # If you want to prefill anything, do it after Display() so the signature stays:
    if subject:
        mail.Subject = subject
    if to:
        mail.To = to
    if cc:
        mail.CC = cc
    if body_html:
        # Append to existing signature
        mail.HTMLBody = body_html + mail.HTMLBody
