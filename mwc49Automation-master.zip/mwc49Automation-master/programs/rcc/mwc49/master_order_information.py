# programs/rcc/mwc49/master_order_information.py
from __future__ import annotations

import os
import sqlite3
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

from core.base import ToolView  # Frame-like base


RCC_DB_PATH = os.path.join("data", "RCC.db")
MWC49_TABLE = "mwc49"

# --- Columns to show in the "MPP Data" table (in this exact order) ---
MPP_FIELDS = [
    "PM #",
    "CLICK End Date",
    "Current Mat",
    "Division",
    "Construction Resource",
    "Main Work Center",
    "SAP Order User Status",  # <- alias-resolve this one
    "Work Plan Date",
    "Project Reporting Year",
    "Completion Deadline Date",
    "Notification Status",
    "Region",
    "Program Name",
    "MPP Sub-Category",
]

# --- Columns for the multi-row table (show ALL rows on latest date for this PM #) ---
LOCATION_FIELDS = [
    "Location #",
    "New Operating Number",
    "Device Type",
    "Latitude",
    "Longitude",
]

# --- Aliases (DB column name drift) ---
COLUMN_ALIASES: dict[str, list[str]] = {
    "SAP Order User Status": [
        "SAP Order User Status",
        "Order User Status",
        "SAP Order UserStatus",
        "SAP Order User status",
        "SAP Order User Status ",
        "SAP Order User Stat",
    ],
}


def _dash_if_blank(v) -> str:
    s = "" if v is None else str(v).strip()
    return s if s else "-"


def _fmt_mdy_from_any(v) -> str:
    """
    Convert common date/datetime strings to mm/dd/yyyy.
    """
    if v is None:
        return "-"
    s = str(v).strip()
    if not s:
        return "-"

    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(s, fmt)
            return dt.strftime("%m/%d/%Y")
        except Exception:
            pass

    # Fallback: slice YYYY-MM-DD if present
    try:
        if len(s) >= 10 and s[4] == "-" and s[7] == "-":
            dt = datetime.strptime(s[:10], "%Y-%m-%d")
            return dt.strftime("%m/%d/%Y")
    except Exception:
        pass

    return s


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
    return cur.fetchone() is not None


def _get_table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    cur = conn.cursor()
    cur.execute(f'PRAGMA table_info("{table}")')
    return {r[1] for r in cur.fetchall()}


def _resolve_db_column(existing_cols: set[str], ui_field: str) -> str | None:
    candidates = COLUMN_ALIASES.get(ui_field, [ui_field])
    for c in candidates:
        if c in existing_cols:
            return c
    return None


def _get_global_latest_timestamp_date(conn: sqlite3.Connection) -> str | None:
    """
    Returns the latest DATE (YYYY-MM-DD) based on mwc49.timestamp, ignoring time.
    """
    cur = conn.cursor()
    cur.execute(
        f"""
        SELECT MAX(date("timestamp"))
        FROM "{MWC49_TABLE}"
        WHERE "timestamp" IS NOT NULL AND trim("timestamp") <> ''
        """
    )
    row = cur.fetchone()
    if not row or not row[0]:
        return None
    return str(row[0])


def _fetch_rows_for_pm_on_latest_date(
    conn: sqlite3.Connection, pm_value: str
) -> tuple[str | None, list[sqlite3.Row]]:
    """
    Returns (latest_date_yyyy_mm_dd, rows) for this PM # on the global latest date.
    rows contains ALL matching rows (ordered by timestamp desc).
    """
    if not _table_exists(conn, MWC49_TABLE):
        return None, []

    latest_date = _get_global_latest_timestamp_date(conn)
    if not latest_date:
        return None, []

    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(
        f"""
        SELECT *
        FROM "{MWC49_TABLE}"
        WHERE "PM #" = ?
          AND date("timestamp") = ?
        ORDER BY "timestamp" DESC
        """,
        (pm_value, latest_date),
    )
    return latest_date, cur.fetchall()


def _row_value(row: sqlite3.Row, col: str):
    """
    sqlite3.Row has no .get(). Safely access by key.
    """
    try:
        return row[col]
    except Exception:
        return None


def _build_mpp_record_from_first_row(existing_cols: set[str], row: sqlite3.Row) -> dict[str, str]:
    """
    MPP Data panel = ONLY the first row, map requested fields.
    Applies alias resolution for SAP Order User Status.
    Formats Work Plan Date and Completion Deadline Date.
    """
    out: dict[str, str] = {}
    for ui_field in MPP_FIELDS:
        db_col = _resolve_db_column(existing_cols, ui_field)
        if not db_col:
            out[ui_field] = "-"
            continue
        out[ui_field] = _dash_if_blank(_row_value(row, db_col))

    out["Work Plan Date"] = _fmt_mdy_from_any(out.get("Work Plan Date"))
    out["Completion Deadline Date"] = _fmt_mdy_from_any(out.get("Completion Deadline Date"))
    return out


def _build_location_rows(existing_cols: set[str], rows: list[sqlite3.Row]) -> list[dict[str, str]]:
    out_rows: list[dict[str, str]] = []
    for r in rows:
        rec: dict[str, str] = {}
        for ui_field in LOCATION_FIELDS:
            db_col = _resolve_db_column(existing_cols, ui_field)
            rec[ui_field] = "-" if not db_col else _dash_if_blank(_row_value(r, db_col))
        out_rows.append(rec)
    return out_rows


class MWC49_Master_Order_Information(ToolView):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)

        heading_font = ("Segoe UI", 10, "bold")
        self.heading_var = tk.StringVar(value="Master Order Information (MWC49)")
        ttk.Label(self, textvariable=self.heading_var, font=heading_font).grid(
            row=3, column=0, columnspan=4, sticky="w", padx=16, pady=(8, 6)
        )

        ttk.Label(self, text="PM #:").grid(row=3, column=1, sticky="e", padx=(0, 6))
        self.pm_query_var = tk.StringVar()
        self.pm_entry = ttk.Entry(self, textvariable=self.pm_query_var, width=26)
        self.pm_entry.grid(row=3, column=2, sticky="we", padx=(0, 6))

        self.search_btn = ttk.Button(self, text="Search", command=self._on_search, state="disabled")
        self.search_btn.grid(row=3, column=3, sticky="w", padx=(10, 16))

        self.pm_entry.bind("<Return>", lambda e: self._on_search())
        self.pm_entry.bind("<KP_Enter>", lambda e: self._on_search())
        self.pm_query_var.trace_add("write", lambda *_: self._update_search_state())

        self.columnconfigure(2, weight=1)
        self.rowconfigure(4, weight=1)

        self.results = ttk.Frame(self)
        self.results.grid(row=4, column=0, columnspan=4, sticky="nsew", padx=16, pady=(4, 12))
        self.results.columnconfigure(0, weight=1)
        self.results.rowconfigure(0, weight=1)
        self.results.rowconfigure(1, weight=1)

        self.mpp_frame = ttk.Frame(self.results)
        self.mpp_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 8))
        self._build_mpp_panel(self.mpp_frame)

        self.loc_frame = ttk.Frame(self.results)
        self.loc_frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        self._build_locations_panel(self.loc_frame)

        try:
            self.pm_entry.focus_set()
        except Exception:
            pass

    def _update_search_state(self):
        q = self.pm_query_var.get().strip()
        self.search_btn.configure(state=("normal" if q else "disabled"))

    def _on_search(self):
        pm = self.pm_query_var.get().strip()
        if not pm:
            return

        self._clear_tree(self.mpp_tree)
        self._clear_tree(self.loc_tree)
        self.heading_var.set("Master Order Information (MWC49) – searching…")

        if not os.path.isfile(RCC_DB_PATH):
            self.heading_var.set("Master Order Information (MWC49)")
            messagebox.showerror("Database Not Found", f"Could not find database:\n{RCC_DB_PATH}")
            return

        try:
            with sqlite3.connect(RCC_DB_PATH) as conn:
                if not _table_exists(conn, MWC49_TABLE):
                    self.heading_var.set("Master Order Information (MWC49)")
                    messagebox.showerror("Table Not Found", f"Could not find table '{MWC49_TABLE}' in RCC.db.")
                    return

                existing_cols = _get_table_columns(conn, MWC49_TABLE)
                latest_date, rows = _fetch_rows_for_pm_on_latest_date(conn, pm)

        except Exception as e:
            self.heading_var.set("Master Order Information (MWC49)")
            messagebox.showerror("Search Failed", f"Failed to query RCC.db:\n{e}")
            return

        if not rows or not latest_date:
            self.heading_var.set("Master Order Information (MWC49)")
            messagebox.showinfo(
                "Not Found",
                f"No rows found for PM # '{pm}' on the global latest timestamp date in table '{MWC49_TABLE}'.",
            )
            return

        first = rows[0]
        mpp_record = _build_mpp_record_from_first_row(existing_cols, first)
        self._populate_mpp_table(mpp_record)

        loc_rows = _build_location_rows(existing_cols, rows)
        self._populate_locations_table(loc_rows)

        self.heading_var.set(
            f"Master Order Information (MWC49) – PM # {pm} (Latest: {_fmt_mdy_from_any(latest_date)})"
        )

    # -------------------------
    # Panels
    # -------------------------
    def _build_mpp_panel(self, parent: ttk.Frame):
        lf = ttk.LabelFrame(parent, text="MPP Data")
        lf.pack(fill="both", expand=True)

        cols = ("field", "value")
        self.mpp_tree = ttk.Treeview(lf, columns=cols, show="headings")
        self.mpp_tree.heading("field", text="Field")
        self.mpp_tree.heading("value", text="Value")
        self.mpp_tree.column("field", width=240, anchor="w")
        self.mpp_tree.column("value", width=520, anchor="w")
        self.mpp_tree.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(lf, orient="vertical", command=self.mpp_tree.yview)
        self.mpp_tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

    def _populate_mpp_table(self, record: dict[str, str]):
        self._clear_tree(self.mpp_tree)
        for k in MPP_FIELDS:
            v = record.get(k, "-")
            self.mpp_tree.insert("", "end", values=(k, "" if v is None else str(v)))

    def _build_locations_panel(self, parent: ttk.Frame):
        lf = ttk.LabelFrame(parent, text="Locations")
        lf.pack(fill="both", expand=True)

        cols = tuple(LOCATION_FIELDS)
        self.loc_tree = ttk.Treeview(lf, columns=cols, show="headings")
        for c in cols:
            self.loc_tree.heading(c, text=c)
            if c in ("Latitude", "Longitude"):
                self.loc_tree.column(c, width=120, anchor="w")
            elif c == "Device Type":
                self.loc_tree.column(c, width=170, anchor="w")
            else:
                self.loc_tree.column(c, width=160, anchor="w")

        self.loc_tree.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(lf, orient="vertical", command=self.loc_tree.yview)
        self.loc_tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        hsb = ttk.Scrollbar(lf, orient="horizontal", command=self.loc_tree.xview)
        self.loc_tree.configure(xscrollcommand=hsb.set)
        hsb.pack(side="bottom", fill="x")

    def _populate_locations_table(self, rows: list[dict[str, str]]):
        self._clear_tree(self.loc_tree)
        for r in rows:
            self.loc_tree.insert("", "end", values=tuple(r.get(c, "-") for c in LOCATION_FIELDS))

    # -------------------------
    # Shared helpers
    # -------------------------
    @staticmethod
    def _clear_tree(tree: ttk.Treeview):
        for item in tree.get_children(""):
            tree.delete(item)
