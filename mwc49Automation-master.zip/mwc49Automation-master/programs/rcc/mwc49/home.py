# programs/rcc/mwc49/home.py
from __future__ import annotations
import os
from datetime import datetime
from typing import Sequence
import pandas as pd
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import StringVar, DISABLED, NORMAL
from core.base import ToolView, FONT_H2
from services.db.rcc_db import RCCDB, TABLE_NAME, MINIMAL_DATA_COLS
import threading

# ----------------------------- Config -----------------------------
SHEET_NAME = "49 Programs 2026"
HEADER_ROW_INDEX = 10  # 0-based; Excel row 11 has headers

# Columns to ingest from Excel (matches DB schema minus metadata)
SELECTED_COLUMNS: Sequence[str] = [
    # keys / basics
    "PM #",
    "Primary Hold-Up",
    "Secondary Hold-Up",
    "Stakeholder",
    "Stage of Job",
    "New Operating Number",
    "CLICK End Date",
    "Resolve Date",
    "Resolve Date2",
    "MPP MAT",
    "Device Type",
    "Division",
    "Construction Resource",
    "Main Work Center",
    "SAP Order User Status ",
    "CN24 Status",

    # NEW tracker fields
    "Work Plan Date",
    "Project Reporting Year",
    "Anticipated Complete Date",
    "Completion Deadline Date",
    "Notification #",
    "Notification Status",
    "Region",
    "Program Name",
    "Construction Contact / Div Director",
    "MPP Sub-Category",
    "On linda's list?",

    # survey / DLT / comms
    "IT Survey Request Date",
    "IT Survey WO",
    "IT Survey Site Status (Pass/Fail)",
    "DLT Site Visit Status (NOTN/INPR/COMP)",
    "Comm WO Request Date",
    "Controller Delivered to DLT Date",

    # settings / materials
    "Settings Requested Date",
    "Settings Received Date",
    "Material Requested Date",
    "Material Delivered Date",

    # flags / deps
    "DS83 Completed (Yes)",
    "Open Dependencies",
    "Dependency Estimated Out Date",
    "ESTS Actual Out Date",
    "ESTS Planned Out Date",
    "Field Install Completed (Yes)",

    # SCADA group
    "SCADA Build Request Date",
    "SCADA Build Ready Date",
    "SCADA WO Status",
    "SCADA ADMS Test Date",

    #Acticipated Completion Date
    "Dynamic ACD",

    #New Columns
    "Location #",
    "Latitude",
    "Longitude",
    "Notes and Updates",
    "SCADA Enabled?",
    "SAP Equipment ID"
]

class MWC49_Home(ToolView):
    """
    - Row 1: workbook path (entry + browse)
    - Row 2: actions (Update Database, Clear Database Entry, Clear Database)
    - Row 3+: split: left 'Database Updates', right 'Snapshot Preview'
    """

    def __init__(self, parent, program_name, tool_name):
        super().__init__(parent, program_name, tool_name)

        # DB service
        self.db = RCCDB()
        # Create table on startup (fresh ingest scenario)
        self.db.ensure_table(MINIMAL_DATA_COLS)

        # now safe to normalize (no-op on fresh table)
        try:
            self.db.normalize_pm_numbers()
        except Exception:
            pass

        self._selected_snapshot: tuple[str, str] | None = None  # (timestamp, file_name)
        self.selected_paths: list[str] = []  # supports multi-file selection

        self.columnconfigure(0, weight=1)

        # ---------- File picker ----------
        row = 3
        top = ttk.Frame(self)
        top.grid(row=row, column=0, sticky="ew", padx=16, pady=(8, 4))
        top.columnconfigure(1, weight=1)

        ttk.Label(top, text="Workbook path:").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.path_var = StringVar()
        ttk.Entry(top, textvariable=self.path_var).grid(row=0, column=1, sticky="ew")
        ttk.Button(top, text="Browse…", command=self._browse).grid(row=0, column=2, padx=(8, 0))

        # ---------- Actions ----------
        row += 1
        actions = ttk.Frame(self)
        actions.grid(row=row, column=0, sticky="w", padx=16, pady=(4, 10))

        self.btn_update = ttk.Button(actions, text="Update Database", command=self._update_db, state=DISABLED)
        self.btn_update.grid(row=0, column=0, padx=(0, 8))

        self.btn_clear_entry = ttk.Button(actions, text="Clear Database Entry", command=self._clear_selected_entry, state=DISABLED)
        self.btn_clear_entry.grid(row=0, column=1, padx=(0, 8))

        self.btn_clear_all = ttk.Button(actions, text="Clear Database", command=self._clear_all, state=DISABLED)
        self.btn_clear_all.grid(row=0, column=2, padx=(0, 8))

        self.path_var.trace_add("write", lambda *_: self._toggle_update_button())

        # ---------- Upper block ----------
        row += 1
        block = ttk.Frame(self)
        block.grid(row=row, column=0, sticky="nsew", padx=16, pady=(0, 8))
        self.rowconfigure(row, weight=1)
        block.columnconfigure(0, weight=1)
        block.columnconfigure(1, weight=1)
        block.rowconfigure(1, weight=1)

        ttk.Label(block, text="Database Updates", font=FONT_H2).grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Label(block, text="Snapshot Preview", font=FONT_H2).grid(row=0, column=1, sticky="w", pady=(0, 6))

        # LEFT: history
        left = ttk.Frame(block)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        cols_hist = ("Last Update", "File Name", "_key")
        self.hist = ttk.Treeview(left, columns=cols_hist, show="headings", selectmode="browse")
        self.hist.heading("Last Update", text="Last Update")
        self.hist.heading("File Name", text="File Name")
        self.hist.heading("_key", text="_key")
        self.hist.column("Last Update", width=180, anchor="w")
        self.hist.column("File Name", anchor="w", stretch=True)
        self.hist.column("_key", width=0, minwidth=0, stretch=False)

        vsb_hist = ttk.Scrollbar(left, orient="vertical", command=self.hist.yview)
        self.hist.configure(yscrollcommand=vsb_hist.set)
        self.hist.grid(row=0, column=0, sticky="nsew")
        vsb_hist.grid(row=0, column=1, sticky="ns")
        self.hist.bind("<Double-1>", self._on_hist_dblclick)

        # RIGHT: preview
        right = ttk.Frame(block)
        right.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)

        cols_prev = ("Timestamp", "PM #", "New Operating Number")
        self.preview = ttk.Treeview(right, columns=cols_prev, show="headings", selectmode="browse")
        for c in cols_prev:
            self.preview.heading(c, text=c)
        self.preview.column("Timestamp", width=180, anchor="w")
        self.preview.column("PM #", anchor="w", stretch=True)
        self.preview.column("New Operating Number", width=200, anchor="w")

        vsb_prev = ttk.Scrollbar(right, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=vsb_prev.set)
        self.preview.grid(row=0, column=0, sticky="nsew")
        vsb_prev.grid(row=0, column=1, sticky="ns")

        # initial load
        self._refresh_history()
        self._update_clear_buttons_enabled()

    # ----------------------- UI Handlers -----------------------
    def _ask_snapshot_timestamp(self) -> str | None:
        dlg = tk.Toplevel(self)
        dlg.title("Set snapshot timestamp")
        dlg.transient(self)
        dlg.grab_set()
        dlg.resizable(False, False)

        now = datetime.now()
        date_var = StringVar(value=now.strftime("%m/%d/%Y"))
        time_var = StringVar(value=now.strftime("%H:%M"))

        frm = ttk.Frame(dlg, padding=12)
        frm.grid(sticky="nsew")
        frm.columnconfigure(1, weight=1)

        ttk.Label(frm, text="Date (MM/DD/YYYY):").grid(row=0, column=0, sticky="w", padx=(0,8), pady=(0,6))
        ttk.Entry(frm, textvariable=date_var, width=14).grid(row=0, column=1, sticky="w", pady=(0,6))

        ttk.Label(frm, text="Time (HH:MM, 24h):").grid(row=1, column=0, sticky="w", padx=(0,8))
        ttk.Entry(frm, textvariable=time_var, width=14).grid(row=1, column=1, sticky="w")

        btns = ttk.Frame(frm)
        btns.grid(row=2, column=0, columnspan=2, sticky="e", pady=(10,0))

        result = {"iso": None}

        def on_ok():
            d = (date_var.get() or "").strip()
            t = (time_var.get() or "").strip()
            try:
                d_dt = datetime.strptime(d, "%m/%d/%Y")
            except Exception:
                messagebox.showerror("Invalid date", "Please use MM/DD/YYYY (e.g., 10/21/2025).", parent=dlg)
                return

            for f in ("%H:%M:%S", "%H:%M"):
                try:
                    parsed_time = datetime.strptime(t, f)
                    break
                except Exception:
                    parsed_time = None
            if parsed_time is None:
                messagebox.showerror("Invalid time", "Use HH:MM or HH:MM:SS (24h).", parent=dlg)
                return

            combined = datetime(d_dt.year, d_dt.month, d_dt.day,
                                parsed_time.hour, parsed_time.minute, getattr(parsed_time, "second", 0))
            result["iso"] = combined.strftime("%Y-%m-%d %H:%M:%S")
            dlg.destroy()

        def on_cancel():
            result["iso"] = None
            dlg.destroy()

        ttk.Button(btns, text="Cancel", command=on_cancel).pack(side="right", padx=(0,6))
        ttk.Button(btns, text="OK", command=on_ok).pack(side="right")

        dlg.update_idletasks()
        try:
            px = self.winfo_rootx()
            py = self.winfo_rooty()
            pw = self.winfo_width()
            ph = self.winfo_height()
            dw = dlg.winfo_width()
            dh = dlg.winfo_height()
            dlg.geometry(f"+{px + (pw-dw)//2}+{py + (ph-dh)//2}")
        except Exception:
            pass

        dlg.wait_window()
        return result["iso"]

    def _browse(self):
        paths = filedialog.askopenfilenames(
            title="Select one or more Excel workbooks",
            filetypes=[("Excel files", "*.xlsx *.xlsm *.xlsb *.xls"), ("All files", "*.*")]
        )
        if not paths:
            return
        self.selected_paths = list(paths)
        if len(self.selected_paths) == 1:
            self.path_var.set(self.selected_paths[0])
        else:
            self.path_var.set(f"{len(self.selected_paths)} files selected")
        self._toggle_update_button()

    def _toggle_update_button(self):
        self.btn_update.config(state=(NORMAL if self.selected_paths else DISABLED))

    def _refresh_history(self):
        for iid in self.hist.get_children():
            self.hist.delete(iid)
        snapshots = self.db.distinct_snapshots()
        for ts, fname, _cnt in snapshots:
            key = f"{ts}||{fname}"
            self.hist.insert("", "end", values=(ts, fname, key))
        self.btn_clear_all.config(state=(NORMAL if snapshots else DISABLED))
        self._selected_snapshot = None
        self.btn_clear_entry.config(state=DISABLED)
        self._clear_preview()

    def _clear_preview(self):
        for iid in self.preview.get_children():
            self.preview.delete(iid)

    def _on_hist_dblclick(self, _event=None):
        item = self.hist.focus()
        if not item:
            return
        vals = self.hist.item(item, "values")
        if len(vals) < 3:
            return
        ts, fname, _key = vals
        self._selected_snapshot = (ts, fname)
        self._refresh_preview_for_selected()
        self._update_clear_buttons_enabled()

    def _refresh_preview_for_selected(self):
        self._clear_preview()
        if not self._selected_snapshot:
            return
        ts, fname = self._selected_snapshot
        rows = self.db.snapshot_pm_preview(ts, fname)
        for row in rows:
            self.preview.insert("", "end", values=row)

    def _update_clear_buttons_enabled(self):
        self.btn_clear_entry.config(state=(NORMAL if self._selected_snapshot else DISABLED))

    # -------------------- Actions / DB Ops ---------------------
    def _update_db(self):
        if not self.selected_paths:
            messagebox.showinfo("No file(s)", "Please select one or more workbooks first.")
            return

        paths = list(self.selected_paths)

        manual_ts: str | None = None
        if len(paths) == 1:
            manual_ts = self._ask_snapshot_timestamp()
            if manual_ts is None:
                return

        mbox = _MultiBusyDialog(self, total=len(paths))
        self._set_actions_enabled(False)

        result: dict[str, object] = {
            "inserted_total": 0,
            "processed": 0,
            "errors": [],
        }

        def worker():
            inserted_total = 0
            errors: list[str] = []

            for idx, path in enumerate(paths, start=1):
                try:
                    if not os.path.exists(path):
                        raise FileNotFoundError(f"Path not found: {path}")

                    ts = manual_ts if manual_ts else _extract_ts_from_filename_with_current_time(path)

                    # ---- ROBUST READ: allow missing columns; fill with NULLs ----
                    df = _read_sheet_robust(
                        path=path,
                        sheet_name=SHEET_NAME,
                        header_row=HEADER_ROW_INDEX,
                        wanted_cols=list(SELECTED_COLUMNS),
                    )

                    # ---- Map new Excel headers back to legacy DB headers ----
                    rename_map = {
                        "MPP MAT": "Current Mat",
                        "Anticipated Complete Date": "Anticipated Complete Date (VOID)",
                    }
                    df = df.rename(columns=rename_map)

                    # Drop rows with completely empty keys (if both present)
                    key_subset = [c for c in ["PM #", "New Operating Number"] if c in df.columns]
                    if key_subset:
                        df = df.dropna(how="all", subset=key_subset)

                    # Attach metadata
                    df["timestamp"] = ts
                    df["file_name"] = os.path.basename(path)

                    # Let the DB layer handle types, NULLs, and NOM '?????'
                    n = self.db.insert_dataframe(df)
                    inserted_total += n

                except Exception as e:
                    errors.append(f"{os.path.basename(path)}: {e}")

                finally:
                    result["processed"] = idx
                    try:
                        mbox.update_progress(idx)
                    except Exception:
                        pass

            result["inserted_total"] = inserted_total
            result["errors"] = errors

        t = threading.Thread(target=worker, daemon=True)
        t.start()

        def poll():
            if t.is_alive():
                self.after(100, poll)
                return

            try:
                mbox.close()
            except Exception:
                pass

            # optional: normalize NOM again post-ingest
            try:
                self.db.backfill_nom_placeholders()
            except Exception:
                pass

            inserted_total = result.get("inserted_total", 0)
            errors = result.get("errors", [])
            processed = result.get("processed", 0)

            if errors:
                err_text = "\n".join(errors)[:2000]
                messagebox.showwarning(
                    "Completed with errors",
                    f"Processed {processed} file(s).\nInserted {inserted_total} rows.\n\nErrors:\n{err_text}"
                )
            else:
                messagebox.showinfo(
                    "Success",
                    f"Processed {processed} file(s).\nInserted {inserted_total} rows into {TABLE_NAME}."
                )

            self._refresh_history()
            self._set_actions_enabled(True)

        self.after(120, poll)

    def _clear_selected_entry(self):
        if not self._selected_snapshot:
            return
        ts, fname = self._selected_snapshot
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Delete the snapshot for:\n\nTimestamp: {ts}\nFile: {fname}\n\nThis cannot be undone."
        ):
            return
        try:
            deleted = self.db.delete_snapshot(ts, fname)
            messagebox.showinfo("Deleted", f"Deleted {deleted} rows for the selected snapshot.")
        except Exception as e:
            messagebox.showerror("DB Error", f"Failed to delete snapshot:\n{e}")
            return
        self._refresh_history()

    def _clear_all(self):
        if not messagebox.askyesno(
            "Confirm Delete All",
            "Delete ALL rows in the MWC49 table? This cannot be undone."
        ):
            return
        try:
            deleted = self.db.delete_all()
            messagebox.showinfo("Deleted", f"Deleted {deleted} rows from {TABLE_NAME}.")
        except Exception as e:
            messagebox.showerror("DB Error", f"Failed to clear database:\n{e}")
            return
        self._refresh_history()

    def _set_actions_enabled(self, enabled: bool):
        state = NORMAL if enabled else DISABLED
        self.btn_update.config(state=state if (self.path_var.get() or "").strip() else DISABLED)
        self.btn_clear_entry.config(state=state if self._selected_snapshot else DISABLED)
        self.btn_clear_all.config(state=state if self.db.distinct_snapshots() else DISABLED)


# --------------------------- Helpers -----------------------------
def _pick_engine(path: str) -> str | None:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return "openpyxl"
    if ext == ".xlsb":
        return "pyxlsb"
    return None  # let pandas choose for .xls, etc.

def _extract_ts_from_filename_with_current_time(path: str) -> str:
    """
    Filename format: ends with '-YYYY-MM-DD' before extension.
    Returns 'YYYY-MM-DD HH:MM:SS'.
    """
    base = os.path.basename(path)
    name, _ext = os.path.splitext(base)
    import re
    m = re.search(r'(\d{4}-\d{2}-\d{2})$', name)
    date_part = m.group(1) if m else datetime.now().strftime("%Y-%m-%d")
    now = datetime.now()
    return f"{date_part} {now.strftime('%H:%M:%S')}"

def _read_sheet_robust(path: str, sheet_name: str, header_row: int, wanted_cols: list[str]) -> pd.DataFrame:
    """
    Reads the Excel sheet, *never* failing if some wanted columns are missing.
    - Uses a callable `usecols` to include only columns that match (case-insensitive).
    - Adds any still-missing columns with pd.NA.
    - Returns a DataFrame with EXACTLY the wanted columns, in order.
    """
    norm_wanted = {c.strip().lower() for c in wanted_cols}
    print(norm_wanted)
    df = pd.read_excel(
        path,
        sheet_name=sheet_name,
        header=header_row,
        engine=_pick_engine(path),
        usecols=lambda c: str(c).strip().lower() in norm_wanted,  # skips unknown; doesn't error
        dtype="string"
    )

    print(df.columns)

    # Add any missing columns as NULLs
    for col in wanted_cols:
        if col not in df.columns:
            df[col] = pd.NA

    # Order columns
    df = df[wanted_cols]
    return df

class _MultiBusyDialog(tk.Toplevel):
    def __init__(self, parent, *, total: int):
        super().__init__(parent)
        self.title("Uploading…")
        self.transient(parent)
        self.resizable(False, False)
        self.grab_set()

        self.total = max(1, int(total))
        self.count = 0

        frm = ttk.Frame(self, padding=12)
        frm.grid(sticky="nsew")
        frm.columnconfigure(0, weight=1)

        self.msg_var = tk.StringVar(value=f"Loaded 0 of {self.total} file(s)…")
        ttk.Label(frm, textvariable=self.msg_var).grid(row=0, column=0, sticky="w")

        self.pb = ttk.Progressbar(frm, mode="determinate", length=260, maximum=self.total)
        self.pb.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.pb["value"] = 0

        self.update_idletasks()
        try:
            px, py = parent.winfo_rootx(), parent.winfo_rooty()
            pw, ph = parent.winfo_width(), parent.winfo_height()
            sw, sh = self.winfo_width(), self.winfo_height()
            self.geometry(f"+{px + (pw - sw)//2}+{py + (ph - sh)//2}")
        except Exception:
            pass

    def update_progress(self, loaded: int):
        self.count = max(0, min(self.total, int(loaded)))
        try:
            self.pb["value"] = self.count
        except Exception:
            pass
        self.msg_var.set(f"Loaded {self.count} of {self.total} file(s)…")
        self.update_idletasks()

    def close(self):
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()
