# programs/rcc/mwc49/master_emailer.py
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, List, Optional

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from core.base import ToolView, FONT_H2
from helpers.emailHelpers.email import df_to_excelish_html

from helpers.emailHelpers.master_email_helpers.master_emailer_helper_functions import (
    # Settings existing
    build_settings_request_tables_from_tracker,
    TABLE1_COLUMNS,
    TABLE2_COLUMNS,
    # Materials UPDATED
    build_material_release_precommissioning_tables_from_tracker,
    MATERIALS_TABLE1_EMAIL_COLUMNS,
    MATERIALS_TABLE2_EMAIL_COLUMNS,
)

EMAIL_CATEGORIES = [
    "Settings: Request for Settings and Updates",
    "Materials: Release Request for PreCommissioning",
]

class MWC49_Master_Emailer(ToolView):
    def __init__(self, master: tk.Misc | None = None, **kwargs: Any) -> None:
        super().__init__(master, **kwargs)

        self.category_var = tk.StringVar()
        self.tracker_path_var = tk.StringVar()

        self.to_var = tk.StringVar()
        self.cc_var = tk.StringVar()
        self.subject_var = tk.StringVar()

        # Settings state
        self._df_1: pd.DataFrame = pd.DataFrame(columns=TABLE1_COLUMNS)
        self._df_2: pd.DataFrame = pd.DataFrame(columns=TABLE2_COLUMNS)
        self._cols_1: List[str] = TABLE1_COLUMNS.copy()
        self._cols_2: List[str] = TABLE2_COLUMNS.copy()

        # Materials state
        self._df_mat_1: pd.DataFrame = pd.DataFrame()
        self._df_mat_2: pd.DataFrame = pd.DataFrame()
        self._cols_mat_1: List[str] = []
        self._cols_mat_2: List[str] = []

        self.category_dd: ttk.Combobox | None = None

        self.body_text_1: tk.Text | None = None
        self.body_text_2: tk.Text | None = None
        self.body_text_3: tk.Text | None = None

        self.tree_1: ttk.Treeview | None = None
        self.tree_2: ttk.Treeview | None = None

        self.btn_send: ttk.Button | None = None

        self._build_ui()
        self._wire_signals()

        if EMAIL_CATEGORIES:
            self.category_var.set(EMAIL_CATEGORIES[0])
            self._apply_template_for_category()
            self._refresh_tables_for_category()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        self.columnconfigure(0, weight=1)
        label_width = 16

        fr0 = ttk.Frame(self)
        fr0.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 4))
        fr0.columnconfigure(1, weight=1)

        ttk.Label(fr0, text="Email Category:", width=label_width).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        dd = ttk.Combobox(
            fr0,
            textvariable=self.category_var,
            state="readonly",
            values=EMAIL_CATEGORIES,
            width=48,
        )
        dd.grid(row=0, column=1, sticky="w")
        self.category_dd = dd

        fr1 = ttk.Frame(self)
        fr1.grid(row=1, column=0, sticky="ew", padx=16, pady=2)
        fr1.columnconfigure(1, weight=1)

        ttk.Label(fr1, text="Tracker File:", width=label_width).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        ttk.Entry(fr1, textvariable=self.tracker_path_var).grid(
            row=0, column=1, sticky="ew"
        )
        ttk.Button(fr1, text="Browse", command=self._on_browse_tracker).grid(
            row=0, column=2, sticky="e", padx=(8, 0)
        )

        fr2 = ttk.Frame(self)
        fr2.grid(row=2, column=0, sticky="ew", padx=16, pady=2)
        fr2.columnconfigure(1, weight=1)

        ttk.Label(fr2, text="To:", width=label_width).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        ttk.Entry(fr2, textvariable=self.to_var).grid(row=0, column=1, sticky="ew")

        fr3 = ttk.Frame(self)
        fr3.grid(row=3, column=0, sticky="ew", padx=16, pady=2)
        fr3.columnconfigure(1, weight=1)

        ttk.Label(fr3, text="CC:", width=label_width).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        ttk.Entry(fr3, textvariable=self.cc_var).grid(row=0, column=1, sticky="ew")

        fr4 = ttk.Frame(self)
        fr4.grid(row=4, column=0, sticky="ew", padx=16, pady=2)
        fr4.columnconfigure(1, weight=1)

        ttk.Label(fr4, text="Subject:", width=label_width).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        ttk.Entry(fr4, textvariable=self.subject_var).grid(row=0, column=1, sticky="ew")

        ttk.Label(self, text="Body:", font=FONT_H2).grid(
            row=5, column=0, sticky="w", padx=16, pady=(10, 2)
        )
        fr5 = ttk.Frame(self)
        fr5.grid(row=6, column=0, sticky="nsew", padx=16, pady=(0, 8))
        fr5.columnconfigure(0, weight=1)
        fr5.rowconfigure(0, weight=1)

        body1 = tk.Text(fr5, height=6, wrap="word")
        body1.grid(row=0, column=0, sticky="nsew")
        sb1 = ttk.Scrollbar(fr5, orient="vertical", command=body1.yview)
        sb1.grid(row=0, column=1, sticky="ns")
        body1.configure(yscrollcommand=sb1.set)
        self.body_text_1 = body1

        lf1 = ttk.LabelFrame(self, text="Table")
        lf1.grid(row=7, column=0, sticky="nsew", padx=16, pady=(0, 10))
        lf1.columnconfigure(0, weight=1)
        lf1.rowconfigure(0, weight=1)

        t1 = ttk.Treeview(lf1, columns=self._cols_1, show="headings", height=10)
        t1.grid(row=0, column=0, sticky="nsew")
        vsb1 = ttk.Scrollbar(lf1, orient="vertical", command=t1.yview)
        hsb1 = ttk.Scrollbar(lf1, orient="horizontal", command=t1.xview)
        t1.configure(yscrollcommand=vsb1.set, xscrollcommand=hsb1.set)
        vsb1.grid(row=0, column=1, sticky="ns")
        hsb1.grid(row=1, column=0, sticky="ew")
        self.tree_1 = t1

        ttk.Label(self, text="Body 2:", font=FONT_H2).grid(
            row=8, column=0, sticky="w", padx=16, pady=(4, 2)
        )
        fr7 = ttk.Frame(self)
        fr7.grid(row=9, column=0, sticky="nsew", padx=16, pady=(0, 8))
        fr7.columnconfigure(0, weight=1)
        fr7.rowconfigure(0, weight=1)

        body2 = tk.Text(fr7, height=4, wrap="word")
        body2.grid(row=0, column=0, sticky="nsew")
        sb2 = ttk.Scrollbar(fr7, orient="vertical", command=body2.yview)
        sb2.grid(row=0, column=1, sticky="ns")
        body2.configure(yscrollcommand=sb2.set)
        self.body_text_2 = body2

        lf2 = ttk.LabelFrame(self, text="Table 2")
        lf2.grid(row=10, column=0, sticky="nsew", padx=16, pady=(0, 10))
        lf2.columnconfigure(0, weight=1)
        lf2.rowconfigure(0, weight=1)

        t2 = ttk.Treeview(lf2, columns=self._cols_2, show="headings", height=8)
        t2.grid(row=0, column=0, sticky="nsew")
        vsb2 = ttk.Scrollbar(lf2, orient="vertical", command=t2.yview)
        hsb2 = ttk.Scrollbar(lf2, orient="horizontal", command=t2.xview)
        t2.configure(yscrollcommand=vsb2.set, xscrollcommand=hsb2.set)
        vsb2.grid(row=0, column=1, sticky="ns")
        hsb2.grid(row=1, column=0, sticky="ew")
        self.tree_2 = t2

        ttk.Label(self, text="Body 3:", font=FONT_H2).grid(
            row=11, column=0, sticky="w", padx=16, pady=(4, 2)
        )
        fr9 = ttk.Frame(self)
        fr9.grid(row=12, column=0, sticky="nsew", padx=16, pady=(0, 8))
        fr9.columnconfigure(0, weight=1)
        fr9.rowconfigure(0, weight=1)

        body3 = tk.Text(fr9, height=3, wrap="word")
        body3.grid(row=0, column=0, sticky="nsew")
        sb3 = ttk.Scrollbar(fr9, orient="vertical", command=body3.yview)
        sb3.grid(row=0, column=1, sticky="ns")
        body3.configure(yscrollcommand=sb3.set)
        self.body_text_3 = body3

        fr10 = ttk.Frame(self)
        fr10.grid(row=13, column=0, sticky="e", padx=16, pady=(4, 14))

        self.btn_send = ttk.Button(
            fr10,
            text="Send Email",
            command=self._on_send_email,
            state="disabled",
        )
        self.btn_send.grid(row=0, column=0, sticky="e")

        self.rowconfigure(7, weight=1)
        self.rowconfigure(10, weight=1)

    def _wire_signals(self) -> None:
        if self.category_dd is not None:
            self.category_dd.bind("<<ComboboxSelected>>", self._on_category_changed)

        self.to_var.trace_add("write", lambda *_: self._update_send_state())
        self.subject_var.trace_add("write", lambda *_: self._update_send_state())
        self.tracker_path_var.trace_add("write", lambda *_: self._refresh_tables_for_category())

    # ------------------------------------------------------------------
    # Category handling
    # ------------------------------------------------------------------
    def _on_category_changed(self, _event: Any) -> None:
        self._apply_template_for_category()
        self._refresh_tables_for_category()

    def _apply_template_for_category(self) -> None:
        cat = (self.category_var.get() or "").strip()
        today = datetime.now()
        subject_date = today.strftime("%m/%d/%Y")
        due_date = (today + timedelta(days=14)).strftime("%m/%d/%Y")

        if cat == "Settings: Request for Settings and Updates":
            self.to_var.set("e2ma@pge.com")
            self.cc_var.set("yxzk@pge.com; o1s7@pge.com; jg57@pge.com; aipo@pge.com; uxgj@pge.com")
            self.subject_var.set(f"49 Program - Settings Request {subject_date}")

            if self.body_text_1 is not None:
                self.body_text_1.delete("1.0", "end")
                self.body_text_1.insert(
                    "1.0",
                    "Hi Erik,\n\n"
                    "The PMs below are ready for settings and the mapping is completed. Can you please generate settings for us and drop it in the SharePoint file linked here once completed?\n"
                    "Or alternatively, you can notify us when you've given it to DLTs.\n\n"
                    f"As always, we expect a 2 weeks turnaround (due date of {due_date}).\n\n"
                )

            if self.body_text_2 is not None:
                self.body_text_2.delete("1.0", "end")
                self.body_text_2.insert("1.0", "I also wanted to check in on the progress for the following PM#s.\n\n")

            if self.body_text_3 is not None:
                self.body_text_3.delete("1.0", "end")
                self.body_text_3.insert("1.0", "These settings are passed due. Do you have an ETA for when your team will have them completed?\n")

        elif cat == "Materials: Release Request for PreCommissioning":
            self.to_var.set("")
            self.cc_var.set("c7db@pge.com; yxzk@pge.com; o1s7@pge.com; jg57@pge.com; aipo@pge.com")
            self.subject_var.set(f"[<Construction Resource>] - [<Div>] - Material Release Request for PreCommissioning - Week of {subject_date}")

            if self.body_text_1 is not None:
                self.body_text_1.delete("1.0", "end")
                self.body_text_1.insert(
                    "1.0",
                    "Hi <First Name>,\n\n"
                    "These job(s) below are resources to <Construction Resource> in <Division>. "
                    f'Please release device materials to the respective DLT Shops (as mentioned in the "DLT Address" column below) by {due_date} - 2 week turnaround time. '
                    "DLTs will need the device for pre-commissioning. Please confirm the order and provide the delivery ETA, if available.\n\n"
                    "To move these jobs to UNSC (Ready for Construction status) - these particular materials need to be released to the DLT shops to complete pre-commissioning.\n\n"
                )

            if self.body_text_2 is not None:
                self.body_text_2.delete("1.0", "end")
                self.body_text_2.insert(
                    "1.0",
                    "I also wanted to check about the material delivery status of the following orders. "
                    "They are past due there forecasted delivery date.\n\n"
                )

            if self.body_text_3 is not None:
                self.body_text_3.delete("1.0", "end")

        else:
            self.to_var.set("")
            self.cc_var.set("")
            self.subject_var.set("")
            if self.body_text_1 is not None:
                self.body_text_1.delete("1.0", "end")
            if self.body_text_2 is not None:
                self.body_text_2.delete("1.0", "end")
            if self.body_text_3 is not None:
                self.body_text_3.delete("1.0", "end")

        self._update_send_state()

    # ------------------------------------------------------------------
    # Tracker browse
    # ------------------------------------------------------------------
    def _on_browse_tracker(self) -> None:
        path = filedialog.askopenfilename(
            title="Select Tracker File",
            filetypes=[("Excel files", "*.xlsx *.xlsm *.xls"), ("All files", "*.*")],
        )
        if path:
            self.tracker_path_var.set(path)

    # ------------------------------------------------------------------
    # Tables: build from tracker
    # ------------------------------------------------------------------
    def _refresh_tables_for_category(self) -> None:
        cat = (self.category_var.get() or "").strip()
        path = (self.tracker_path_var.get() or "").strip()

        if cat == "Settings: Request for Settings and Updates" and path:
            try:
                df1, cols1, df2, cols2 = build_settings_request_tables_from_tracker(path)
                self._df_1, self._cols_1 = df1, cols1
                self._df_2, self._cols_2 = df2, cols2
            except Exception as e:
                messagebox.showerror("Tracker Read Error", f"Failed to process tracker file:\n\n{type(e).__name__}: {e}")
                self._df_1 = pd.DataFrame(columns=TABLE1_COLUMNS)
                self._df_2 = pd.DataFrame(columns=TABLE2_COLUMNS)
                self._cols_1 = TABLE1_COLUMNS.copy()
                self._cols_2 = TABLE2_COLUMNS.copy()

            self._populate_tree(self.tree_1, self._df_1, self._cols_1)
            self._populate_tree(self.tree_2, self._df_2, self._cols_2)

        elif cat == "Materials: Release Request for PreCommissioning" and path:
            try:
                dfm1, colsm1, dfm2, colsm2 = build_material_release_precommissioning_tables_from_tracker(path)
                self._df_mat_1, self._cols_mat_1 = dfm1, colsm1
                self._df_mat_2, self._cols_mat_2 = dfm2, colsm2
            except Exception as e:
                messagebox.showerror("Tracker Read Error", f"Failed to process tracker file:\n\n{type(e).__name__}: {e}")
                self._df_mat_1 = pd.DataFrame()
                self._df_mat_2 = pd.DataFrame()
                self._cols_mat_1 = []
                self._cols_mat_2 = []

            self._populate_tree(self.tree_1, self._df_mat_1, self._cols_mat_1)
            self._populate_tree(self.tree_2, self._df_mat_2, self._cols_mat_2)

        else:
            self._df_1 = pd.DataFrame(columns=TABLE1_COLUMNS)
            self._df_2 = pd.DataFrame(columns=TABLE2_COLUMNS)
            self._cols_1 = TABLE1_COLUMNS.copy()
            self._cols_2 = TABLE2_COLUMNS.copy()

            self._df_mat_1 = pd.DataFrame()
            self._df_mat_2 = pd.DataFrame()
            self._cols_mat_1 = []
            self._cols_mat_2 = []

            self._populate_tree(self.tree_1, self._df_1, self._cols_1)
            self._populate_tree(self.tree_2, self._df_2, self._cols_2)

        self._update_send_state()

    def _populate_tree(
        self,
        tree: Optional[ttk.Treeview],
        df: pd.DataFrame,
        columns: List[str],
    ) -> None:
        if tree is None:
            return

        for iid in tree.get_children(""):
            tree.delete(iid)

        tree["columns"] = columns
        for c in columns:
            tree.heading(c, text=c)

            base = 140
            if c in ("PM-Location", "Circuit Name", "DLT Address"):
                base = 220
            if c in ("Engineer", "Construction Contact", "Construction Contact / Div Director", "Construction Resource"):
                base = 240
            if c in ("Latitude", "Longitude"):
                base = 140
            if c in ("IT Survey WO", "SAP Equipment ID", "Local DLT LAN ID"):
                base = 170
            if c in ("Request Date", "Forecasted Ready Date", "Resolve Date", "Material Requested Date", "Forecasted Delivery Date"):
                base = 190
            if c in ("Email ID",):
                base = 220

            tree.column(c, width=base, anchor="w", stretch=True)

        if df is None or df.empty:
            return

        for _, row in df.iterrows():
            vals = [row.get(c, "") for c in columns]
            tree.insert("", "end", values=vals)

    # ------------------------------------------------------------------
    # Send Email
    # ------------------------------------------------------------------
    def _update_send_state(self) -> None:
        if self.btn_send is None:
            return

        cat = (self.category_var.get() or "").strip()
        subj_ok = bool(self.subject_var.get().strip())

        if cat == "Materials: Release Request for PreCommissioning":
            df_ok = (
                (self._df_mat_1 is not None and not self._df_mat_1.empty)
                or (self._df_mat_2 is not None and not self._df_mat_2.empty)
            )
            self.btn_send.configure(state=("normal" if df_ok and subj_ok else "disabled"))
            return

        to_ok = bool(self.to_var.get().strip())
        self.btn_send.configure(state=("normal" if to_ok and subj_ok else "disabled"))

    def _on_send_email(self) -> None:
        cat = (self.category_var.get() or "").strip()

        if cat == "Materials: Release Request for PreCommissioning":
            self._send_material_release_precommissioning_emails()
            return

        # Settings flow unchanged (omitted here for brevity)...
        messagebox.showerror("Not Implemented Here", "Settings flow unchanged in this snippet.")

    # ------------------------------------------------------------------
    # Materials multi-email sender (UPDATED column control)
    # ------------------------------------------------------------------
    def _send_material_release_precommissioning_emails(self) -> None:
        df1 = self._df_mat_1
        df2 = self._df_mat_2

        if (df1 is None or df1.empty) and (df2 is None or df2.empty):
            messagebox.showinfo("No Rows", "No rows matched (Primary Hold-Up = Device Delivery Pending).")
            return

        # Email ID needed for grouping (in UI schemas it exists for both)
        if (df1 is not None and not df1.empty and "Email ID" not in df1.columns) or (
            df2 is not None and not df2.empty and "Email ID" not in df2.columns
        ):
            messagebox.showerror("Missing Email ID", 'One of the materials tables does not contain "Email ID".')
            return

        cc_addr = self.cc_var.get().strip() or "c7db@pge.com; yxzk@pge.com; o1s7@pge.com; jg57@pge.com; aipo@pge.com"

        today = datetime.now()
        week_of = today.strftime("%m/%d/%Y")
        due_date = (today + timedelta(days=14)).strftime("%m/%d/%Y")

        body1_template = self.body_text_1.get("1.0", "end").strip() if self.body_text_1 is not None else ""
        if not body1_template:
            body1_template = (
                "Hi <First Name>,\n\n"
                "These job(s) below are resources to <Construction Resource> in <Division>. "
                f'Please release device materials to the respective DLT Shops (as mentioned in the "DLT Address" column below) by {due_date} - 2 week turnaround time. '
                "DLTs will need the device for pre-commissioning. Please confirm the order and provide the delivery ETA, if available.\n\n"
                "To move these jobs to UNSC (Ready for Construction status) - these particular materials need to be released to the DLT shops to complete pre-commissioning.\n\n"
            )

        body2_text = self.body_text_2.get("1.0", "end").strip() if self.body_text_2 is not None else ""
        if not body2_text:
            body2_text = (
                "I also wanted to check about the material delivery status of the following orders. "
                "They are past due there forecasted delivery date."
            )

        def _nl2br(s: str) -> str:
            return s.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")

        def _first_names_from_contact(contact: str) -> str:
            s = (contact or "").strip()
            if not s:
                return "there"
            if "(" in s:
                s = s.split("(", 1)[0].strip()
            parts = [p.strip() for p in s.split(",") if p.strip()]
            if not parts:
                return "there"
            firsts = []
            for p in parts:
                toks = [t for t in p.split() if t.strip()]
                if toks:
                    firsts.append(toks[0])
            if not firsts:
                return "there"
            if len(firsts) == 1:
                return firsts[0]
            if len(firsts) == 2:
                return f"{firsts[0]} and {firsts[1]}"
            return ", ".join(firsts[:-1]) + f", and {firsts[-1]}"

        try:
            import win32com.client as win32
        except ImportError:
            messagebox.showerror(
                "Outlook Automation Error",
                "pywin32 is required for Outlook automation.\n\nInstall it with:\n  pip install pywin32",
            )
            return

        try:
            app = win32.Dispatch("Outlook.Application")
        except Exception as e:
            messagebox.showerror("Outlook Error", f"Failed to access Outlook:\n\n{type(e).__name__}: {e}")
            return

        # union recipients
        emails = set()
        if df1 is not None and not df1.empty:
            emails |= set(df1["Email ID"].astype(str).tolist())
        if df2 is not None and not df2.empty:
            emails |= set(df2["Email ID"].astype(str).tolist())

        recipients = sorted(
            {e.strip() for e in emails if e and e.strip() and e.strip().lower() not in {"nan", "nat", "none"}}
        )

        created = 0
        for to_addr in recipients:
            sub1 = df1[df1["Email ID"].astype(str).str.strip() == to_addr].copy() if (df1 is not None and not df1.empty) else pd.DataFrame()
            sub2 = df2[df2["Email ID"].astype(str).str.strip() == to_addr].copy() if (df2 is not None and not df2.empty) else pd.DataFrame()
            if sub1.empty and sub2.empty:
                continue

            if not sub2.empty and "Forecasted Delivery Date" in sub2.columns:
                # reuse same formatting logic as helper (MM/DD/YYYY)
                sub2["Forecasted Delivery Date"] = sub2["Forecasted Delivery Date"].apply(
                    lambda v: "" if pd.isna(v) else pd.to_datetime(v, errors="coerce").strftime("%m/%d/%Y") if not pd.isna(pd.to_datetime(v, errors="coerce")) else str(v).strip()
                )

            pick = sub1 if not sub1.empty else sub2

            div = str(pick["Division"].iloc[0]).strip() if "Division" in pick.columns else ""
            resource = str(pick["Construction Resource"].iloc[0]).strip() if "Construction Resource" in pick.columns else ""
            contact = str(pick["Construction Contact"].iloc[0]).strip() if "Construction Contact" in pick.columns else ""

            subject = f"[{resource}] - [{div}] - Material Release Request for PreCommissioning - Week of {week_of}"
            first_name = _first_names_from_contact(contact)

            body1 = body1_template.replace("<First Name>", first_name).replace("<Construction Resource>", resource).replace("<Division>", div)
            safe_body1 = _nl2br(body1)
            safe_body2 = _nl2br(body2_text)

            html_parts: List[str] = []

            # Table 1 email columns
            if not sub1.empty:
                cols1 = [c for c in MATERIALS_TABLE1_EMAIL_COLUMNS if c in sub1.columns]
                t1_html = df_to_excelish_html(sub1[cols1].copy(), cols1)
                html_parts.append(f"<p>{safe_body1}</p>")
                html_parts.append(t1_html)

            # Table 2 email columns
            if not sub2.empty:
                cols2 = [c for c in MATERIALS_TABLE2_EMAIL_COLUMNS if c in sub2.columns]
                t2_html = df_to_excelish_html(sub2[cols2].copy(), cols2)
                html_parts.append(f"<p>{safe_body2}</p>")
                html_parts.append(t2_html)

            if not html_parts:
                continue

            try:
                mail = app.CreateItem(0)
                mail.To = to_addr
                if cc_addr:
                    mail.CC = cc_addr
                mail.Subject = subject
                mail.HTMLBody = "".join(html_parts) + "<p>Thank you.</p>"
                mail.Display(True)
                created += 1
            except Exception as e:
                messagebox.showerror(
                    "Email Error",
                    f"Failed to create Outlook email draft for {to_addr}:\n\n{type(e).__name__}: {e}",
                )

        if created == 0:
            messagebox.showinfo(
                "No Emails Created",
                "No emails were created. This usually means all rows had blank Email IDs (no matches in static_lists.db).",
            )
