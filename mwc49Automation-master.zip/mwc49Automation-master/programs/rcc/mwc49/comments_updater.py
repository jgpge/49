# programs/rcc/mwc49/comments_updater.py
from __future__ import annotations

import os
import threading
from typing import Optional

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import StringVar, DISABLED, NORMAL

from core.base import ToolView, FONT_H2

from helpers.comments_updater.it_comments import build_it_comments_mapping
from helpers.comments_updater.mwc49_tracker import apply_it_comments_to_mwc49_tracker


CATEGORY_IT = "IT Comments"
CATEGORIES = [CATEGORY_IT]


class MWC49_Comments_Updates(ToolView):
    """
    MWC49 Comments Updater

    Row 3:
      - Categories dropdown

    Row 4:
      - IT Comments workbook picker

    Row 5:
      - MWC49 Tracker workbook picker

    Row 6:
      - Update Comments button
    """

    def __init__(self, parent, program_name, tool_name):
        super().__init__(parent, program_name, tool_name)

        self.columnconfigure(0, weight=1)

        # ---------- State ----------
        self.category_var = tk.StringVar(value=CATEGORIES[0])

        self.it_path: Optional[str] = None
        self.tracker_path: Optional[str] = None

        self.it_path_var = StringVar()
        self.tracker_path_var = StringVar()

        # ---------- Layout ----------
        row = 3  # start from row 3 (as requested)

        # Row 3: Category dropdown
        cat = ttk.Frame(self)
        cat.grid(row=row, column=0, sticky="ew", padx=16, pady=(8, 6))
        cat.columnconfigure(1, weight=1)

        ttk.Label(cat, text="Categories:", font=FONT_H2).grid(row=0, column=0, sticky="w", padx=(0, 10))
        dd = ttk.Combobox(cat, textvariable=self.category_var, values=CATEGORIES, state="readonly", width=30)
        dd.grid(row=0, column=1, sticky="w")
        dd.bind("<<ComboboxSelected>>", lambda _e: self._on_category_change())

        # Row 4: IT Comments file picker
        row += 1
        it = ttk.Frame(self)
        it.grid(row=row, column=0, sticky="ew", padx=16, pady=(2, 6))
        it.columnconfigure(1, weight=1)

        self.lbl_it = ttk.Label(it, text="IT Comments:")
        self.lbl_it.grid(row=0, column=0, sticky="w", padx=(0, 10))
        self.ent_it = ttk.Entry(it, textvariable=self.it_path_var)
        self.ent_it.grid(row=0, column=1, sticky="ew")
        self.btn_it = ttk.Button(it, text="Browse", command=self._browse_it)
        self.btn_it.grid(row=0, column=2, padx=(10, 0))

        # Row 5: Tracker file picker
        row += 1
        tr = ttk.Frame(self)
        tr.grid(row=row, column=0, sticky="ew", padx=16, pady=(2, 6))
        tr.columnconfigure(1, weight=1)

        self.lbl_tr = ttk.Label(tr, text="MWC49 Tracker:")
        self.lbl_tr.grid(row=0, column=0, sticky="w", padx=(0, 10))
        self.ent_tr = ttk.Entry(tr, textvariable=self.tracker_path_var)
        self.ent_tr.grid(row=0, column=1, sticky="ew")
        self.btn_tr = ttk.Button(tr, text="Browse", command=self._browse_tracker)
        self.btn_tr.grid(row=0, column=2, padx=(10, 0))

        # Row 6: Update button
        row += 1
        actions = ttk.Frame(self)
        actions.grid(row=row, column=0, sticky="w", padx=16, pady=(8, 10))

        self.btn_update = ttk.Button(actions, text="Update Comments", command=self._update_comments, state=DISABLED)
        self.btn_update.grid(row=0, column=0)

        # Status line
        row += 1
        self.status_var = tk.StringVar(value="")
        ttk.Label(self, textvariable=self.status_var).grid(row=row, column=0, sticky="w", padx=16, pady=(0, 8))

        # Traces
        self.it_path_var.trace_add("write", lambda *_: self._sync_paths_from_vars())
        self.tracker_path_var.trace_add("write", lambda *_: self._sync_paths_from_vars())

        # Initial category UI
        self._on_category_change()
        self._toggle_update_button()

    # ---------------- UI helpers ----------------
    def _on_category_change(self):
        """
        For now only IT Comments category exists, but this is where we'd
        show/hide future category-specific widgets.
        """
        self._toggle_update_button()

    def _sync_paths_from_vars(self):
        self.it_path = self.it_path_var.get().strip() or None
        self.tracker_path = self.tracker_path_var.get().strip() or None
        self._toggle_update_button()

    def _toggle_update_button(self):
        ok = (
            self.category_var.get() == CATEGORY_IT
            and bool(self.it_path_var.get().strip())
            and bool(self.tracker_path_var.get().strip())
        )
        self.btn_update.config(state=(NORMAL if ok else DISABLED))

    def _browse_it(self):
        path = filedialog.askopenfilename(
            title="Select IT Comments workbook",
            filetypes=[("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")]
        )
        if not path:
            return
        self.it_path_var.set(path)

    def _browse_tracker(self):
        path = filedialog.askopenfilename(
            title="Select MWC49 Tracker workbook",
            filetypes=[("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")]
        )
        if not path:
            return
        self.tracker_path_var.set(path)

    # ---------------- Core action ----------------
    def _update_comments(self):
        category = self.category_var.get()
        if category != CATEGORY_IT:
            messagebox.showinfo("Not implemented", "Only IT Comments is implemented right now.")
            return

        it_path = (self.it_path_var.get() or "").strip()
        tracker_path = (self.tracker_path_var.get() or "").strip()

        if not it_path or not os.path.exists(it_path):
            messagebox.showerror("Missing file", "Please select a valid IT Comments workbook.")
            return
        if not tracker_path or not os.path.exists(tracker_path):
            messagebox.showerror("Missing file", "Please select a valid MWC49 Tracker workbook.")
            return

        # Guard: openpyxl cannot write .xlsb; also ensures user doesn't pick it
        for p in (it_path, tracker_path):
            ext = os.path.splitext(p)[1].lower()
            if ext == ".xlsb":
                messagebox.showerror(
                    "Unsupported file type",
                    f"This tool currently does not support .xlsb editing:\n\n{p}\n\nPlease save as .xlsx or .xlsm."
                )
                return

        busy = _BusyDialog(self, message="Updating comments…")
        self._set_enabled(False)
        self.status_var.set("Working…")

        result: dict[str, object] = {"error": None, "summary": ""}

        def worker():
            try:
                # 1) Build mapping from IT comments workbook
                mapping, meta = build_it_comments_mapping(it_path)

                # 2) Apply mapping to tracker workbook in-place
                summary = apply_it_comments_to_mwc49_tracker(
                    tracker_path=tracker_path,
                    mapping=mapping,
                )

                # Compose user-facing summary
                it_sheet = meta.get("sheet", "")
                it_rows = meta.get("rows", 0)
                it_nonempty = meta.get("nonempty", 0)
                it_trimmed = meta.get("trimmed", 0)

                result["summary"] = (
                    f"IT Comments: sheet={it_sheet} | rows read={it_rows} | notes kept={it_nonempty} | trimmed={it_trimmed}\n"
                    f"{summary}\n\n"
                    f"Updated file (in-place):\n{tracker_path}"
                )
            except Exception as e:
                result["error"] = str(e)

        t = threading.Thread(target=worker, daemon=True)
        t.start()

        def poll():
            if t.is_alive():
                self.after(120, poll)
                return

            try:
                busy.close()
            except Exception:
                pass

            self._set_enabled(True)

            err = result.get("error")
            if err:
                self.status_var.set("Failed.")
                messagebox.showerror("Update failed", f"Could not update comments:\n\n{err}")
            else:
                self.status_var.set("Done.")
                messagebox.showinfo("Update complete", str(result.get("summary") or "Done."))

        self.after(150, poll)

    def _set_enabled(self, enabled: bool):
        state = NORMAL if enabled else DISABLED
        self.btn_it.config(state=state)
        self.btn_tr.config(state=state)
        self.ent_it.config(state=state)
        self.ent_tr.config(state=state)
        # dropdown: disable while running
        # ttk.Combobox uses 'state' with strings
        # keep readonly when enabled
        # (simpler: just ignore)
        self.btn_update.config(state=DISABLED if not enabled else NORMAL)
        self._toggle_update_button()


class _BusyDialog(tk.Toplevel):
    def __init__(self, parent, message: str = "Working…"):
        super().__init__(parent)
        self.title("Please wait")
        self.transient(parent)
        self.resizable(False, False)
        self.grab_set()

        frm = ttk.Frame(self, padding=12)
        frm.grid(sticky="nsew")
        frm.columnconfigure(0, weight=1)

        self.msg_var = tk.StringVar(value=message)
        ttk.Label(frm, textvariable=self.msg_var).grid(row=0, column=0, sticky="w")

        self.pb = ttk.Progressbar(frm, mode="indeterminate", length=280)
        self.pb.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        try:
            self.pb.start(12)
        except Exception:
            pass

        self.update_idletasks()
        try:
            px, py = parent.winfo_rootx(), parent.winfo_rooty()
            pw, ph = parent.winfo_width(), parent.winfo_height()
            sw, sh = self.winfo_width(), self.winfo_height()
            self.geometry(f"+{px + (pw - sw)//2}+{py + (ph - sh)//2}")
        except Exception:
            pass

    def close(self):
        try:
            self.pb.stop()
        except Exception:
            pass
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()
