# programs/rcc/mwc49/tracker_builder.py
from __future__ import annotations

import os
import threading
import queue
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from core.base import ToolView, FONT_H2
from services.db import mwc49 as mwc49_db


class MWC49_Tracker_Builder(ToolView):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self._container = (
            getattr(self, "body", None)
            or getattr(self, "frame", None)
            or getattr(self, "content", None)
            or self
        )

        self._q: "queue.Queue[tuple]" = queue.Queue()
        self._polling = False
        self._active_job: str | None = None  # "mpp" or "psps"

        self._build_ui()

    def _build_ui(self) -> None:
        # -------------------------
        # MPP Update Section
        # -------------------------
        title = tk.Label(self._container, text="MPP Update", font=FONT_H2)
        title.grid(row=3, column=0, columnspan=6, sticky="w", padx=10, pady=(10, 6))

        lbl = tk.Label(self._container, text="MPP Source File:")
        lbl.grid(row=4, column=0, sticky="w", padx=10, pady=4)

        self.mpp_path_var = tk.StringVar(value="")
        self.mpp_entry = ttk.Entry(self._container, textvariable=self.mpp_path_var, width=80)
        self.mpp_entry.grid(row=4, column=1, columnspan=3, sticky="we", padx=(0, 8), pady=4)

        self.browse_btn = ttk.Button(self._container, text="Browse", command=self._browse_mpp)
        self.browse_btn.grid(row=4, column=4, sticky="e", padx=(0, 8), pady=4)

        self.update_btn = ttk.Button(self._container, text="Update MPP Database", command=self._start_update_mpp)
        self.update_btn.grid(row=4, column=5, sticky="e", padx=(0, 10), pady=4)
        self.update_btn.state(["disabled"])

        # MPP Progress UI (below MPP URL bar)
        self.mpp_progress = ttk.Progressbar(self._container, mode="indeterminate", length=240)
        self.mpp_progress.grid(row=5, column=1, sticky="w", padx=(0, 8), pady=(6, 10))

        self.mpp_status_var = tk.StringVar(value="")
        self.mpp_status_lbl = tk.Label(self._container, textvariable=self.mpp_status_var)
        self.mpp_status_lbl.grid(row=5, column=2, columnspan=4, sticky="w", padx=(0, 10), pady=(6, 10))

        # -------------------------
        # PSPS SCADA TCom Section
        # -------------------------
        psps_title = tk.Label(self._container, text="PSPS SCADA TCom Tracker", font=FONT_H2)
        psps_title.grid(row=6, column=0, columnspan=6, sticky="w", padx=10, pady=(10, 6))

        psps_lbl = tk.Label(self._container, text="PSPS SCADA TCom Tracker:")
        psps_lbl.grid(row=7, column=0, sticky="w", padx=10, pady=4)

        self.psps_path_var = tk.StringVar(value="")
        self.psps_entry = ttk.Entry(self._container, textvariable=self.psps_path_var, width=80)
        self.psps_entry.grid(row=7, column=1, columnspan=3, sticky="we", padx=(0, 8), pady=4)

        self.psps_browse_btn = ttk.Button(self._container, text="Browse", command=self._browse_psps)
        self.psps_browse_btn.grid(row=7, column=4, sticky="e", padx=(0, 8), pady=4)

        self.psps_update_btn = ttk.Button(
            self._container,
            text="Update PSPS SCADA TCom Tracker",
            command=self._start_update_psps,
        )
        self.psps_update_btn.grid(row=7, column=5, sticky="e", padx=(0, 10), pady=4)
        self.psps_update_btn.state(["disabled"])

        # PSPS Progress UI (below PSPS URL bar)  <-- THIS IS WHAT YOU ASKED FOR
        self.psps_progress = ttk.Progressbar(self._container, mode="indeterminate", length=240)
        self.psps_progress.grid(row=8, column=1, sticky="w", padx=(0, 8), pady=(6, 10))

        self.psps_status_var = tk.StringVar(value="")
        self.psps_status_lbl = tk.Label(self._container, textvariable=self.psps_status_var)
        self.psps_status_lbl.grid(row=8, column=2, columnspan=4, sticky="w", padx=(0, 10), pady=(6, 10))

        # Make columns expand nicely
        try:
            self._container.grid_columnconfigure(1, weight=1)
            self._container.grid_columnconfigure(2, weight=0)
            self._container.grid_columnconfigure(3, weight=0)
        except Exception:
            pass

        # Enable/disable buttons based on path
        self.mpp_path_var.trace_add("write", lambda *_: self._refresh_update_states())
        self.psps_path_var.trace_add("write", lambda *_: self._refresh_update_states())
        self._refresh_update_states()

    # -------------------------
    # Browse handlers
    # -------------------------
    def _browse_mpp(self) -> None:
        path = filedialog.askopenfilename(
            title="Select MPP CSV File",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.mpp_path_var.set(path)

    def _browse_psps(self) -> None:
        path = filedialog.askopenfilename(
            title="Select PSPS SCADA TCom Excel File",
            filetypes=[("Excel files", "*.xlsx;*.xlsm;*.xltx;*.xltm"), ("All files", "*.*")],
        )
        if path:
            self.psps_path_var.set(path)

    def _refresh_update_states(self) -> None:
        mpp = (self.mpp_path_var.get() or "").strip()
        psps = (self.psps_path_var.get() or "").strip()

        if mpp and os.path.isfile(mpp):
            self.update_btn.state(["!disabled"])
        else:
            self.update_btn.state(["disabled"])

        if psps and os.path.isfile(psps):
            self.psps_update_btn.state(["!disabled"])
        else:
            self.psps_update_btn.state(["disabled"])

    # -------------------------
    # Lock/unlock UI (prevent double-runs)
    # -------------------------
    def _lock_ui(self) -> None:
        self.update_btn.state(["disabled"])
        self.browse_btn.state(["disabled"])
        self.mpp_entry.state(["disabled"])

        self.psps_update_btn.state(["disabled"])
        self.psps_browse_btn.state(["disabled"])
        self.psps_entry.state(["disabled"])

    def _unlock_ui(self) -> None:
        self.browse_btn.state(["!disabled"])
        self.mpp_entry.state(["!disabled"])
        self.psps_browse_btn.state(["!disabled"])
        self.psps_entry.state(["!disabled"])
        self._refresh_update_states()

    # -------------------------
    # Start update jobs
    # -------------------------
    def _start_update_mpp(self) -> None:
        csv_path = (self.mpp_path_var.get() or "").strip()
        if not csv_path or not os.path.isfile(csv_path):
            messagebox.showerror("Missing file", "Please select a valid MPP CSV file.")
            return

        self._active_job = "mpp"
        self._lock_ui()

        # Start MPP loader UI
        self.mpp_status_var.set("Loading MPP CSV → updating database…")
        self.mpp_progress.start(10)

        t = threading.Thread(target=self._worker_mpp, args=(csv_path,), daemon=True)
        t.start()

        if not self._polling:
            self._polling = True
            self._poll_queue()

    def _start_update_psps(self) -> None:
        xlsx_path = (self.psps_path_var.get() or "").strip()
        if not xlsx_path or not os.path.isfile(xlsx_path):
            messagebox.showerror("Missing file", "Please select a valid PSPS SCADA TCom Excel file.")
            return

        self._active_job = "psps"
        self._lock_ui()

        # Start PSPS loader UI
        self.psps_status_var.set('Loading "PSPS SCADA Tcom Tracker" → updating database…')
        self.psps_progress.start(10)

        t = threading.Thread(target=self._worker_psps, args=(xlsx_path,), daemon=True)
        t.start()

        if not self._polling:
            self._polling = True
            self._poll_queue()

    # -------------------------
    # Worker threads
    # -------------------------
    def _worker_mpp(self, csv_path: str) -> None:
        try:
            def _on_prog(n: int) -> None:
                self._q.put(("progress", "mpp", n))

            inserted = mwc49_db.replace_mpp_data_from_csv(csv_path, on_progress=_on_prog)
            self._q.put(("done", "mpp", inserted))
        except Exception as e:
            self._q.put(("error", "mpp", str(e)))

    def _worker_psps(self, xlsx_path: str) -> None:
        try:
            def _on_prog(n: int) -> None:
                self._q.put(("progress", "psps", n))

            inserted = mwc49_db.replace_psps_scada_tcom_from_excel(xlsx_path, on_progress=_on_prog)
            self._q.put(("done", "psps", inserted))
        except Exception as e:
            self._q.put(("error", "psps", str(e)))

    # -------------------------
    # Queue polling
    # -------------------------
    def _poll_queue(self) -> None:
        try:
            while True:
                msg = self._q.get_nowait()
                kind = msg[0]

                if kind == "progress":
                    job = msg[1]
                    n = msg[2]
                    if job == "mpp":
                        self.mpp_status_var.set(f"MPP: Inserted {n:,} rows into data/mwc49.db …")
                    else:
                        self.psps_status_var.set(f"PSPS SCADA TCom: Inserted {n:,} rows into data/mwc49.db …")

                elif kind == "done":
                    job = msg[1]
                    inserted = msg[2]
                    if job == "mpp":
                        self._finish_mpp(success=True, message=f"Done. Inserted {inserted:,} rows into mpp_data.")
                    else:
                        self._finish_psps(success=True, message=f"Done. Inserted {inserted:,} rows into psps_scada_tcom_data.")
                    return

                elif kind == "error":
                    job = msg[1]
                    err = msg[2]
                    if job == "mpp":
                        self._finish_mpp(success=False, message=err)
                    else:
                        self._finish_psps(success=False, message=err)
                    return

        except queue.Empty:
            pass

        self._container.after(150, self._poll_queue)

    # -------------------------
    # Finish handlers (separate per section)
    # -------------------------
    def _finish_mpp(self, *, success: bool, message: str) -> None:
        self.mpp_progress.stop()
        self._unlock_ui()

        self._polling = False
        self._active_job = None

        if success:
            self.mpp_status_var.set(message)
            messagebox.showinfo("MPP Update", message)
        else:
            self.mpp_status_var.set("Failed.")
            messagebox.showerror("MPP Update Failed", message)

    def _finish_psps(self, *, success: bool, message: str) -> None:
        self.psps_progress.stop()
        self._unlock_ui()

        self._polling = False
        self._active_job = None

        if success:
            self.psps_status_var.set(message)
            messagebox.showinfo("PSPS SCADA TCom Update", message)
        else:
            self.psps_status_var.set("Failed.")
            messagebox.showerror("PSPS SCADA TCom Update Failed", message)
