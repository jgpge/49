# programs/rcc/mwc49/emailer.py
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog

from core.base import ToolView
from routers.mwc49_risk_tracker_router import mwc49_risk_tracker_email_router


class Emailer(ToolView):
    """
    RCC MWC49 Emailer view.

    Row layout (starting at row 3 as requested):

      Row 3: "Generate email for:" [dropdown]    [file path entry] [Browse...]
      Row 4: "Options:"
      Row 5+: checkbox list (depends on dropdown; currently only "Construction")
      Row N: "Generate Email(s)" button (disabled until file + at least one option)
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        # --- state variables ---
        self.file_var = tk.StringVar()
        self.template_var = tk.StringVar(value="Risk Tracker")

        # Will hold BooleanVars for checkboxes keyed by label text
        self.option_vars: dict[str, tk.BooleanVar] = {}

        # placeholder for button so type checkers don't complain
        self.generate_btn: ttk.Button | None = None

        # --- build UI ---
        self._build_ui()

        # --- traces / bindings for enabling Generate button ---
        self.file_var.trace_add("write", self._on_state_changed)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        # Row 3: Label + dropdown + file path + Browse button
        row = 3

        lbl_template = ttk.Label(self, text="Generate email for:")
        lbl_template.grid(row=row, column=0, padx=5, pady=5, sticky="w")

        self.template_combo = ttk.Combobox(
            self,
            textvariable=self.template_var,
            state="readonly",
            values=["Risk Tracker"],
            width=20,
        )
        self.template_combo.grid(row=row, column=1, padx=5, pady=5, sticky="w")
        self.template_combo.bind("<<ComboboxSelected>>", self._on_template_changed)

        # File path entry ("URL bar") + Browse button
        self.file_entry = ttk.Entry(self, textvariable=self.file_var, width=50)
        self.file_entry.grid(row=row, column=2, padx=5, pady=5, sticky="we")

        browse_btn = ttk.Button(self, text="Browse...", command=self._on_browse)
        browse_btn.grid(row=row, column=3, padx=5, pady=5, sticky="w")

        # Make column 2 expand if the parent allows resizing
        self.grid_columnconfigure(2, weight=1)

        # Row 4: Options label
        row += 1
        options_lbl = ttk.Label(self, text="Options:")
        options_lbl.grid(row=row, column=0, padx=5, pady=(10, 5), sticky="w")

        # Row 5: frame that will contain checkboxes
        row += 1
        self.options_frame = ttk.Frame(self)
        self.options_frame.grid(
            row=row,
            column=0,
            columnspan=4,
            padx=5,
            pady=(0, 10),
            sticky="w",
        )

        # Row below options: Generate button (initially disabled but visible)
        self.generate_btn = ttk.Button(
            self,
            text="Generate Email(s)",
            command=self._on_generate,
            state="disabled",   # greyed out initially
        )
        self.generate_btn.grid(row=row + 1, column=0, padx=5, pady=10, sticky="w")

        # Populate options for initial template (after button exists)
        self._rebuild_options_for_template(self.template_var.get())

    # ------------------------------------------------------------------
    # Options handling
    # ------------------------------------------------------------------
    def _rebuild_options_for_template(self, template_name: str) -> None:
        """
        Rebuild the checkbox list based on the dropdown selection.
        For now, only "Risk Tracker" → ["Construction"].
        """
        # Clear previous options
        for child in self.options_frame.winfo_children():
            child.destroy()
        self.option_vars.clear()

        # Decide which options to show based on template
        if template_name == "Risk Tracker":
            option_labels = ["Construction"]
        else:
            option_labels = []

        for i, label in enumerate(option_labels):
            var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(
                self.options_frame,
                text=label,
                variable=var,
                command=self._on_state_changed,  # when clicked, re-evaluate button state
            )
            cb.grid(row=i, column=0, padx=5, pady=2, sticky="w")
            self.option_vars[label] = var

        # After rebuilding options, re-evaluate button state
        self._update_generate_button_state()

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------
    def _on_browse(self) -> None:
        """Open a file dialog to pick the input file path."""
        path = filedialog.askopenfilename(
            title="Select input file",
            filetypes=[
                ("Excel / CSV files", "*.xlsx *.xls *.xlsb *.csv"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.file_var.set(path)

    def _on_template_changed(self, event=None) -> None:
        """Called when the dropdown selection changes."""
        template_name = self.template_var.get()
        self._rebuild_options_for_template(template_name)

    def _on_state_changed(self, *args) -> None:
        """Called when file path or any checkbox changes."""
        self._update_generate_button_state()

    def _update_generate_button_state(self) -> None:
        """
        Enable Generate button only if we have a file path and at least one option checked.
        Guarded so it doesn't crash during early construction.
        """
        # If button hasn't been created yet, do nothing
        if not hasattr(self, "generate_btn") or self.generate_btn is None:
            return

        file_ok = bool(self.file_var.get().strip())
        any_checked = any(var.get() for var in self.option_vars.values())

        if file_ok and any_checked:
            self.generate_btn.config(state="normal")
        else:
            self.generate_btn.config(state="disabled")

    def _on_generate(self) -> None:
        """
        For now, just log to console:
          - file path
          - dropdown option selected
          - checkboxes selected
        """
        file_path = self.file_var.get().strip()
        template_name = self.template_var.get()
        selected_options = [name for name, var in self.option_vars.items() if var.get()]

        if template_name == "Risk Tracker":
            mwc49_risk_tracker_email_router(file_path, selected_options)
