from core.base import ProgramSpec, ToolSpec
from .home import MWC49_Home
from .reports import MWC49_Reports
from .emailer import Emailer
from .comments_updater import MWC49_Comments_Updates
from .tracker_builder import MWC49_Tracker_Builder
from .master_emailer import MWC49_Master_Emailer
from .master_order_information import MWC49_Master_Order_Information

MWC49_PROGRAM = ProgramSpec(
    id="mwc49",
    name="MWC 49",
    tools=[
        ToolSpec("home", "Home", MWC49_Home),
        ToolSpec("reports", "Reports", MWC49_Reports),
        ToolSpec("emailer", "Emailer", Emailer),
        ToolSpec("comments_updater", "Comments Updater", MWC49_Comments_Updates),
        ToolSpec("tracker_builder", "Tracker Builder", MWC49_Tracker_Builder),
        ToolSpec("master_emailer", "Master Emailer", MWC49_Master_Emailer),
        ToolSpec("master_order_information", "Master Order Information", MWC49_Master_Order_Information)
    ],
)