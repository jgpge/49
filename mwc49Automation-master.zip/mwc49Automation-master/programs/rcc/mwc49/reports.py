# programs/rcc/mwc49/reports.py
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, timedelta
from typing import Optional, List, Tuple
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import pandas as pd

from core.base import ToolView, FONT_H2
from services.db.rcc_db import RCCDB

# refactored helpers
from helpers.mwc49_reports.common_helpers import (
    parse_mmddyyyy,
    STAKEHOLDER_CHOICES,
    STAKEHOLDER_ALL_LABEL,
    STAKEHOLDER_ORDER,   # for lifecycle graph x-axis
)
from helpers.mwc49_reports.construction_delay_report import make_construction_delay_table
from helpers.mwc49_reports.stakeholder_holdup import make_stakeholder_holdup_table
from helpers.mwc49_reports.stakeholder_holdup_lifecycle import (
    make_stakeholder_holdup_lifecycle_table,
)
from helpers.mwc49_reports.stakeholder_holdup_lifecycle_accurate import (
    make_stakeholder_holdup_lifecycle_accurate,
    ACCURATE_STAKEHOLDER_CHOICES,
)
from helpers.mwc49_reports.job_complete_report import make_job_complete_table
from helpers.mwc49_reports.risk_tracker import make_risk_tracker_table, RISK_STAKEHOLDER_CHOICES
from helpers.mwc49_reports.change_tracker import make_change_tracker_table
from helpers.mwc49_reports.dynamic_acd_report import make_dynamic_acd_table

# report names
REPORT_CONSTR = "Construction Delay Report"
REPORT_CURRENT_STK = "Current Stakeholder Holdup"
REPORT_LIFECYCLE = "Stakeholder Holdup Lifecycle"
REPORT_LIFECYCLE_ACCURATE = "Stakeholder Holdup Lifecycle (Accurate)"
REPORT_JOB_COMPLETE = "Job Complete Report"
REPORT_RISK_TRACKER = "Risk Tracker"
REPORT_CHANGE = "Change Report"
REPORT_DYNAMIC_ACD = "Dynamic ACD Report"

REPORT_OPTIONS = [
    REPORT_CONSTR,
    REPORT_CURRENT_STK,
    REPORT_LIFECYCLE,
    REPORT_LIFECYCLE_ACCURATE,
    REPORT_JOB_COMPLETE,
    REPORT_RISK_TRACKER,
    REPORT_CHANGE,
    REPORT_DYNAMIC_ACD,
]


class MWC49_Reports(ToolView):
    def __init__(self, parent, program_name, tool_name):
        super().__init__(parent, program_name, tool_name)

        self.db = RCCDB()

        # ---------- State ----------
        self.report_var = tk.StringVar(value=REPORT_OPTIONS[0])
        self._last_columns: list[str] = []
        self._last_rows: list[list[str]] = []

        # for "Current Stakeholder Holdup"
        self.stakeholder_var = tk.StringVar(value=(STAKEHOLDER_ALL_LABEL if STAKEHOLDER_CHOICES else ""))
        self.threshold_var = tk.IntVar(value=5)

        # for "Stakeholder Holdup Lifecycle"
        # view mode: "table" or "graph"
        self.lifecycle_view_var = tk.StringVar(value="table")
        # for graph view (Stakeholder Holdup Lifecycle)
        self._chart_canvas = None
        self._chart_figure = None
        self.pm_search_var = tk.StringVar(value="")

        # for "Change Report" – which field to track
        # "mat" = Current Mat, "wpd" = Work Plan Date, "pry" = Project Reporting Year
        self.change_field_var = tk.StringVar(value="mat")

        # Date range (defaults to last 30 days)
        today = datetime.today().date()
        default_from = today - timedelta(days=30)
        self.from_var = tk.StringVar(value=default_from.strftime("%m/%d/%Y"))
        self.to_var = tk.StringVar(value=today.strftime("%m/%d/%Y"))

        # ---------- Layout ----------
        self.columnconfigure(0, weight=1)
        row = 3

        # Header
        hdr = ttk.Frame(self)
        hdr.grid(row=row, column=0, sticky="ew", padx=16, pady=(8, 6))
        hdr.columnconfigure(1, weight=1)

        ttk.Label(hdr, text="Reports", font=FONT_H2).grid(row=0, column=0, sticky="w", padx=(0, 12))
        sel = ttk.Combobox(hdr, textvariable=self.report_var, values=REPORT_OPTIONS, state="readonly", width=40)
        sel.grid(row=0, column=1, sticky="w")
        sel.bind("<<ComboboxSelected>>", lambda _e: self._on_report_change())

        self.btn_export = ttk.Button(hdr, text="Export Current View", command=self._export_current_view, state="disabled")
        self.btn_export.grid(row=0, column=2, sticky="e")

        # Body split
        row += 1
        body = ttk.Frame(self)
        body.grid(row=row, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.rowconfigure(row, weight=1)
        body.columnconfigure(0, weight=1)  # LEFT grows
        body.columnconfigure(1, weight=0)  # RIGHT fixed
        body.rowconfigure(0, weight=1)

        # LEFT: results area (treeview or graph)
        self.results_wrap = ttk.Frame(body)
        self.results_wrap.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)
        self.tree = None
        self.vsb = None
        self.hsb = None
        self.graph_canvas = None  # when we draw graph

        # RIGHT: settings
        self.settings = ttk.Frame(body)
        self.settings.grid(row=0, column=1, sticky="n")
        self._build_settings(self.settings)

        # Initial render
        self._on_report_change()

    # ---------- Settings UI ----------
    def _build_settings(self, parent: ttk.Frame):
        parent.columnconfigure(0, weight=0)

        # Title
        ttk.Label(parent, text="Settings", font=FONT_H2).grid(
            row=0, column=0, sticky="w", pady=(0, 6)
        )

        # 1) Date range (always visible)
        grp_dates = ttk.LabelFrame(parent, text="Date Range")
        grp_dates.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        for i in range(2):
            grp_dates.columnconfigure(i, weight=1)

        ttk.Label(grp_dates, text="From (MM/DD/YYYY)").grid(
            row=0, column=0, sticky="w", padx=8, pady=(6, 2)
        )
        ttk.Entry(grp_dates, textvariable=self.from_var, width=14).grid(
            row=1, column=0, sticky="w", padx=8, pady=(0, 6)
        )

        ttk.Label(grp_dates, text="To (MM/DD/YYYY)").grid(
            row=0, column=1, sticky="w", padx=8, pady=(6, 2)
        )
        ttk.Entry(grp_dates, textvariable=self.to_var, width=14).grid(
            row=1, column=1, sticky="w", padx=8, pady=(0, 6)
        )

        btns = ttk.Frame(grp_dates)
        btns.grid(row=2, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 8))
        ttk.Button(btns, text="Last 30 days", command=lambda: self._set_last_days(30)).pack(side="left")
        ttk.Button(btns, text="Apply", command=self._draw).pack(side="right")

        # 2) Stakeholder picker (shown ONLY for "Current Stakeholder Holdup" & lifecycle stuff)
        self.grp_stk = ttk.LabelFrame(parent, text="Stakeholder")
        self.grp_stk.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        self.grp_stk.columnconfigure(0, weight=1)

        self.cmb_stakeholder = ttk.Combobox(
            self.grp_stk,
            textvariable=self.stakeholder_var,
            values=STAKEHOLDER_CHOICES,
            state="readonly",
            width=32,
        )
        self.cmb_stakeholder.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 8))
        self.cmb_stakeholder.bind("<<ComboboxSelected>>", lambda _e: self._draw())

        # 3) Threshold (days) – only for "Current Stakeholder Holdup"
        self.grp_thr = ttk.LabelFrame(parent, text="Threshold")
        self.grp_thr.grid(row=3, column=0, sticky="ew", pady=(0, 8))
        self.grp_thr.columnconfigure(1, weight=1)

        ttk.Label(self.grp_thr, text="Minimum days with stakeholder:").grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 2)
        )
        spin = ttk.Spinbox(self.grp_thr, from_=0, to=3650, textvariable=self.threshold_var, width=8)
        spin.grid(row=0, column=1, sticky="w", padx=(0, 8), pady=(8, 2))
        ttk.Button(self.grp_thr, text="Apply", command=self._draw).grid(
            row=0, column=2, sticky="e", padx=8
        )

        # PM filter (only for Accurate report)
        self.grp_pm_filter = ttk.LabelFrame(parent, text="PM Filter (optional)")
        self.grp_pm_filter.grid(row=4, column=0, sticky="ew", pady=(0, 8))
        self.grp_pm_filter.columnconfigure(1, weight=1)

        ttk.Label(self.grp_pm_filter, text="PM #").grid(row=0, column=0, sticky="w", padx=8, pady=(8, 6))
        ttk.Entry(self.grp_pm_filter, textvariable=self.pm_search_var, width=18).grid(
            row=0, column=1, sticky="w", padx=(0, 8), pady=(8, 6)
        )
        ttk.Button(self.grp_pm_filter, text="Apply", command=self._draw).grid(row=0, column=2, sticky="e", padx=8, pady=(8, 6))

        # 4) Delay filters (Construction Delay only)
        self.grp_filters = ttk.LabelFrame(parent, text="Filters")
        self.grp_filters.grid(row=5, column=0, sticky="ew", pady=(0, 8))
        self.grp_filters.columnconfigure(0, weight=1)

        self.f_no_delays_var = tk.BooleanVar(value=True)
        self.f_pushed_var = tk.BooleanVar(value=True)
        self.f_pulled_var = tk.BooleanVar(value=True)

        ttk.Checkbutton(
            self.grp_filters,
            text="No Delays",
            variable=self.f_no_delays_var,
            command=self._draw,
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(6, 2))

        ttk.Checkbutton(
            self.grp_filters,
            text="Pushed Back",
            variable=self.f_pushed_var,
            command=self._draw,
        ).grid(row=1, column=0, sticky="w", padx=8, pady=(0, 2))

        ttk.Checkbutton(
            self.grp_filters,
            text="Pulled Forward",
            variable=self.f_pulled_var,
            command=self._draw,
        ).grid(row=2, column=0, sticky="w", padx=8, pady=(0, 8))

        # 5) Change Report – field picker (only for Change Report)
        self.grp_change_field = ttk.LabelFrame(parent, text="Change Field")
        self.grp_change_field.grid(row=6, column=0, sticky="ew", pady=(0, 8))
        for i in range(3):
            self.grp_change_field.columnconfigure(i, weight=1)

        ttk.Radiobutton(
            self.grp_change_field,
            text="Current Mat",
            value="mat",
            variable=self.change_field_var,
            command=self._draw,
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(6, 4))

        ttk.Radiobutton(
            self.grp_change_field,
            text="Work Plan Date",
            value="wpd",
            variable=self.change_field_var,
            command=self._draw,
        ).grid(row=0, column=1, sticky="w", padx=8, pady=(6, 4))

        ttk.Radiobutton(
            self.grp_change_field,
            text="Project Reporting Year",
            value="pry",
            variable=self.change_field_var,
            command=self._draw,
        ).grid(row=0, column=2, sticky="w", padx=8, pady=(6, 4))

        # 6) View toggle (Table / Graph) — ONLY for "Stakeholder Holdup Lifecycle"
        self.grp_viewmode = ttk.LabelFrame(parent, text="View")
        self.grp_viewmode.grid(row=7, column=0, sticky="ew", pady=(0, 8))
        self.grp_viewmode.columnconfigure(0, weight=1)

        self.view_var = tk.StringVar(value="table")

        ttk.Radiobutton(
            self.grp_viewmode,
            text="Table",
            value="table",
            variable=self.view_var,
            command=self._draw,
        ).grid(row=0, column=0, padx=8, pady=4, sticky="w")

        ttk.Radiobutton(
            self.grp_viewmode,
            text="Graph",
            value="graph",
            variable=self.view_var,
            command=self._draw,
        ).grid(row=0, column=1, padx=8, pady=4, sticky="w")

        # 7) Info line (always at the bottom)
        self.info_var = tk.StringVar(value="")
        ttk.Label(parent, textvariable=self.info_var).grid(
            row=8, column=0, sticky="w", pady=(4, 0)
        )

        # 8) Progress (hidden by default; shown during long runs)
        self.progress_frame = ttk.Frame(parent)
        self.progress_frame.grid(row=9, column=0, sticky="ew", pady=(6, 0))
        self.progress_frame.columnconfigure(0, weight=1)
        self.progress_frame.grid_remove()  # hidden initially

        self.progress_text = tk.StringVar(value="")
        ttk.Label(self.progress_frame, textvariable=self.progress_text).grid(
            row=0, column=0, sticky="w", padx=0, pady=(0, 4)
        )

        self.progress_var = tk.IntVar(value=0)
        self.progress_bar = ttk.Progressbar(
            self.progress_frame, orient="horizontal", mode="determinate",
            variable=self.progress_var, maximum=100, length=220
        )
        self.progress_bar.grid(row=1, column=0, sticky="ew")

    # ---------- Event handlers ----------
    def _on_report_change(self):
        self._update_settings_visibility()
        self._draw()

    def _update_settings_visibility(self):
        report = self.report_var.get()

        # stakeholder picker
        if report in ("Current Stakeholder Holdup", "Stakeholder Holdup", REPORT_LIFECYCLE_ACCURATE):
            if report == REPORT_LIFECYCLE_ACCURATE:
                self.cmb_stakeholder.config(values=ACCURATE_STAKEHOLDER_CHOICES)
                if self.stakeholder_var.get() not in ACCURATE_STAKEHOLDER_CHOICES:
                    self.stakeholder_var.set(ACCURATE_STAKEHOLDER_CHOICES[0])
            else:
                self.cmb_stakeholder.config(values=STAKEHOLDER_CHOICES)
                if self.stakeholder_var.get() not in STAKEHOLDER_CHOICES:
                    self.stakeholder_var.set(STAKEHOLDER_CHOICES[0])
            self.grp_stk.grid()
        else:
            self.grp_stk.grid_remove()

        # threshold only for non-accurate "Current Stakeholder Holdup"
        if report in ("Current Stakeholder Holdup", "Stakeholder Holdup"):
            self.grp_thr.grid()
        else:
            self.grp_thr.grid_remove()

        # construction-only filters
        if report == REPORT_CONSTR:
            self.grp_filters.grid()
        else:
            self.grp_filters.grid_remove()

        # Change Report field picker
        if report == REPORT_CHANGE:
            self.grp_change_field.grid()
        else:
            self.grp_change_field.grid_remove()

        # lifecycle chart toggle (classic lifecycle only)
        if report == REPORT_LIFECYCLE:
            self.grp_viewmode.grid()
        else:
            self.grp_viewmode.grid_remove()

        # PM filter group only for Accurate report
        if report == REPORT_LIFECYCLE_ACCURATE:
            self.grp_viewmode.grid_remove()  # not using graph for Accurate
            self.grp_filters.grid_remove()
            self.grp_thr.grid_remove()
            self.grp_stk.grid()
            self.cmb_stakeholder.config(values=ACCURATE_STAKEHOLDER_CHOICES)
            if self.stakeholder_var.get() not in ACCURATE_STAKEHOLDER_CHOICES:
                self.stakeholder_var.set(ACCURATE_STAKEHOLDER_CHOICES[0])
            self.grp_pm_filter.grid()
        else:
            self.grp_pm_filter.grid_remove()

        # for Job Complete Report: only date range is relevant
        if report == REPORT_JOB_COMPLETE:
            self.grp_stk.grid_remove()
            self.grp_thr.grid_remove()
            self.grp_filters.grid_remove()
            self.grp_viewmode.grid_remove()
            self.grp_pm_filter.grid_remove()
            self.grp_change_field.grid_remove()
        # for Risk Tracker: date range + stakeholder (Risk choices)
        if report == REPORT_RISK_TRACKER:
            self.grp_filters.grid_remove()
            self.grp_thr.grid_remove()
            self.grp_viewmode.grid_remove()
            self.grp_pm_filter.grid_remove()
            self.grp_change_field.grid_remove()
            # reuse the existing stakeholder combobox with risk choices
            self.grp_stk.grid()
            self.cmb_stakeholder.config(values=RISK_STAKEHOLDER_CHOICES)
            if self.stakeholder_var.get() not in RISK_STAKEHOLDER_CHOICES:
                self.stakeholder_var.set(RISK_STAKEHOLDER_CHOICES[0])

        # Dynamic ACD Report: no settings (besides the always-visible date range)
        if report == REPORT_DYNAMIC_ACD:
            self.grp_stk.grid_remove()
            self.grp_thr.grid_remove()
            self.grp_filters.grid_remove()
            self.grp_viewmode.grid_remove()
            self.grp_pm_filter.grid_remove()
            self.grp_change_field.grid_remove()


    def _set_last_days(self, days: int):
        today = datetime.today().date()
        start = today - timedelta(days=days)
        self.from_var.set(start.strftime("%m/%d/%Y"))
        self.to_var.set(today.strftime("%m/%d/%Y"))
        self._draw()

    # ---------- Progress helpers ----------
    def _progress_start(self, total: int):
        total = max(1, int(total or 1))
        self._progress_total = total
        self._progress_done = 0
        self.progress_var.set(0)
        self.progress_text.set(f"Processing 0 of {total}…")
        self.progress_frame.grid()  # show
        self.update_idletasks()

    def _progress_update(self, done: int):
        self._progress_done = max(0, min(done, getattr(self, "_progress_total", 1)))
        pct = int(self._progress_done * 100 / max(1, getattr(self, "_progress_total", 1)))
        self.progress_var.set(pct)
        self.progress_text.set(f"Processing {self._progress_done} of {getattr(self, '_progress_total', 1)}…")
        self.update_idletasks()

    def _progress_end(self):
        self.progress_var.set(100)
        self.update_idletasks()
        self.progress_frame.grid_remove()

    # ---------- Draw / Data ----------
    def _draw(self):
        report = self.report_var.get()
        try:
            dt_from = parse_mmddyyyy(self.from_var.get())
            dt_to   = parse_mmddyyyy(self.to_var.get())
        except ValueError:
            messagebox.showerror("Invalid dates", "Please use MM/DD/YYYY for From/To.")
            return

        ts_from = datetime(dt_from.year, dt_from.month, dt_from.day, 0, 0, 0).strftime("%Y-%m-%d %H:%M:%S")
        ts_to   = datetime(dt_to.year,   dt_to.month,   dt_to.day,   23, 59, 59).strftime("%Y-%m-%d %H:%M:%S")

        if report == REPORT_CONSTR:
            self._draw_construction_delay(ts_from, ts_to)

        elif report == REPORT_CURRENT_STK:
            self._draw_current_stakeholder_holdup(ts_from, ts_to)

        elif report == REPORT_LIFECYCLE:
            df = self.db.fetch_primary_holdup_series(ts_from, ts_to)
            self._draw_stakeholder_lifecycle(dt_from, dt_to, ts_from, ts_to)

        elif report == REPORT_LIFECYCLE_ACCURATE:
            df = self.db.fetch_accurate_series(ts_from, ts_to)

            # optional per-PM search
            pm_filter = (self.pm_search_var.get() or "").strip()
            if pm_filter:
                df = df[df["PM #"].astype(str).str.strip() == pm_filter]

            window_start = datetime(dt_from.year, dt_from.month, dt_from.day, 0, 0, 0)
            window_end   = datetime(dt_to.year,   dt_to.month,   dt_to.day,   23, 59, 59)

            sel_stk = (self.stakeholder_var.get() or "").strip()
            if not sel_stk:
                sel_stk = ACCURATE_STAKEHOLDER_CHOICES[0]

            # wire progress
            try:
                total_groups = df["PM #"].astype(str).str.strip().nunique()
            except Exception:
                total_groups = 0
            self._progress_start(total_groups or 1)

            def _cb(done: int, total: int):
                # if helper's total differs (e.g., after filtering), adopt it
                if getattr(self, "_progress_total", 0) != max(1, total):
                    self._progress_start(max(1, total))
                self._progress_update(done)

            columns, rows, total_raw = make_stakeholder_holdup_lifecycle_accurate(
                df, window_start, window_end, sel_stk, progress_cb=_cb
            )

            self._progress_end()

            self.info_var.set(
                f"Window: {self.from_var.get()} → {self.to_var.get()} | Stakeholder: {sel_stk} | "
                f"Raw rows: {total_raw} | PM in report: {len(rows)}"
            )

            self._last_columns = columns
            self._last_rows = rows
            self._render_table(columns, rows)
            self.btn_export.config(state=("normal" if rows else "disabled"))

        elif report == REPORT_JOB_COMPLETE:
            df = self.db.fetch_accurate_series(ts_from, ts_to)

            columns, rows, total_raw = make_job_complete_table(df)

            self.info_var.set(
                f"Window: {self.from_var.get()} → {self.to_var.get()} | Raw rows: {total_raw} | PM in report: {len(rows)}"
            )

            self._last_columns = columns
            self._last_rows = rows
            self._render_table(columns, rows)
            self.btn_export.config(state=("normal" if rows else "disabled"))

        elif report == REPORT_RISK_TRACKER:
            df = self.db.fetch_click_series(ts_from, ts_to)

            try:
                total_groups = df[["PM #", "New Operating Number"]].astype(str).applymap(str.strip).dropna().drop_duplicates().shape[0]
            except Exception:
                total_groups = 0
            self._progress_start(total_groups or 1)

            def _cb(done: int, total: int):
                if getattr(self, "_progress_total", 0) != max(1, total):
                    self._progress_start(max(1, total))
                self._progress_update(done)

            sel_stk = (self.stakeholder_var.get() or "").strip() or RISK_STAKEHOLDER_CHOICES[0]

            columns, rows, total_raw = make_risk_tracker_table(
                df,
                datetime(dt_from.year, dt_from.month, dt_from.day, 0, 0, 0),
                datetime(dt_to.year,   dt_to.month,   dt_to.day,   23, 59, 59),
                sel_stk,
                progress_cb=_cb,
            )

            self._progress_end()

            self.info_var.set(
                f"Window: {self.from_var.get()} → {self.to_var.get()} | Stakeholder: {sel_stk} | "
                f"Raw rows: {total_raw} | At risk: {len(rows)}"
            )

            self._last_columns = columns
            self._last_rows = rows
            self._render_table(columns, rows)
            self.btn_export.config(state=("normal" if rows else "disabled"))

        elif report == REPORT_CHANGE:
            # Change Report: we use the click-series fetch (has timestamp, PH, WPD, PRY, MAT, etc.)
            df = self.db.fetch_click_series(ts_from, ts_to)

            # progress based on number of (PM#, NOM) combos
            try:
                total_groups = df[["PM #", "New Operating Number"]].astype(str).applymap(str.strip).dropna().drop_duplicates().shape[0]
            except Exception:
                total_groups = 0
            self._progress_start(total_groups or 1)

            def _cb(done: int, total: int):
                if getattr(self, "_progress_total", 0) != max(1, total):
                    self._progress_start(max(1, total))
                self._progress_update(done)

            field_mode = self.change_field_var.get() or "mat"
            display_name = {
                "mat": "Current Mat",
                "wpd": "Work Plan Date",
                "pry": "Project Reporting Year",
            }.get(field_mode, "Current Mat")

            columns, rows, total_raw = make_change_tracker_table(
                df,
                field_mode=field_mode,
                progress_cb=_cb,
            )

            self._progress_end()

            self.info_var.set(
                f"Window: {self.from_var.get()} → {self.to_var.get()} | Field: {display_name} | "
                f"Raw rows: {total_raw} | Cases with changes: {len(rows)}"
            )

            self._last_columns = columns
            self._last_rows = rows
            self._render_table(columns, rows)
            self.btn_export.config(state=("normal" if rows else "disabled"))

        elif report == REPORT_DYNAMIC_ACD:
            self._draw_dynamic_acd()

        else:
            self._clear_results_area()
            ttk.Label(self.results_wrap, text="Unsupported report").grid(row=0, column=0, sticky="nsew")

    # ---------- Specific report drawers ----------
    def _draw_dynamic_acd(self):
        """
        Dynamic ACD Report:
            - Uses the latest_update_date = date of global latest timestamp in the mwc49 table snapshot
            - Includes only groups (PM#, NOM) whose latest timestamp date == latest_update_date
            - Displays only the latest row per included group
        """
        # IMPORTANT: This report must be based on the GLOBAL latest timestamp,
        # not the currently selected date range. So we fetch a wide window.
        ts_from = "1900-01-01 00:00:00"
        ts_to   = "2999-12-31 23:59:59"

        df = self.db.fetch_click_series(ts_from, ts_to)

        columns, rows, total_raw, latest_update_date_str, included, rejected = make_dynamic_acd_table(df)

        self.info_var.set(
            f"Latest Update Date: {latest_update_date_str or '-'} | "
            f"Raw rows: {total_raw} | Groups included: {included} | Groups rejected: {rejected}"
        )

        self._last_columns = columns
        self._last_rows = rows
        self._render_table(columns, rows)
        self.btn_export.config(state=("normal" if rows else "disabled"))


    def _draw_construction_delay(self, ts_from: str, ts_to: str):
        df = self.db.fetch_click_series(ts_from, ts_to)
        columns, rows, totals, total_raw = make_construction_delay_table(df)

        # Apply UI filters
        show_zero  = self.f_no_delays_var.get()
        show_pos   = self.f_pushed_var.get()
        show_neg   = self.f_pulled_var.get()

        filtered_rows: List[List[str]] = []
        for row, tot in zip(rows, totals):
            if (tot == 0 and show_zero) or (tot > 0 and show_pos) or (tot < 0 and show_neg):
                filtered_rows.append(row)

        self.info_var.set(
            f"Window: {self.from_var.get()} → {self.to_var.get()} | Raw rows: {total_raw} | "
            f"PM with changes: {len(rows)} | After filters: {len(filtered_rows)}"
        )

        self._last_columns = columns
        self._last_rows = filtered_rows
        self._render_table(columns, filtered_rows)
        self.btn_export.config(state=("normal" if filtered_rows else "disabled"))

    def _draw_current_stakeholder_holdup(self, ts_from: str, ts_to: str):
        df = self.db.fetch_primary_holdup_series(ts_from, ts_to)
        sel = (self.stakeholder_var.get() or "").strip()
        threshold_days = max(0, int(self.threshold_var.get() or 0))

        columns, rows, total_raw = make_stakeholder_holdup_table(df, sel, threshold_days)

        chosen = sel if sel else STAKEHOLDER_ALL_LABEL
        self.info_var.set(
            f"Window: {self.from_var.get()} → {self.to_var.get()} | Stakeholder: {chosen} | "
            f"Raw rows: {total_raw} | Matches: {len(rows)}"
        )

        self._last_columns = columns
        self._last_rows = rows
        self._render_table(columns, rows)
        self.btn_export.config(state=("normal" if rows else "disabled"))

    def _draw_stakeholder_lifecycle(self, dt_from, dt_to, ts_from: str, ts_to: str):
        """
        For the lifecycle report, we always compute the table first, then either display
        the table or a graph depending on self.lifecycle_view_var.
        """
        df = self.db.fetch_primary_holdup_series(ts_from, ts_to)
        # optional PM filter
        pm_filter = (self.pm_search_var.get() or "").strip()
        if pm_filter:
            df = df[df["PM #"].astype(str).str.strip() == pm_filter]

        columns, rows, total_raw = make_stakeholder_holdup_lifecycle_table(
            df,
            datetime(dt_from.year, dt_from.month, dt_from.day, 0, 0, 0),
            datetime(dt_to.year,   dt_to.month,   dt_to.day,   23, 59, 59),
        )

        self.info_var.set(
            f"Window: {self.from_var.get()} → {self.to_var.get()} | Raw rows: {total_raw} | PM in report: {len(rows)}"
        )

        # cache ALWAYS so export works even from graph
        self._last_columns = columns
        self._last_rows = rows

        mode = self.lifecycle_view_var.get() or "table"
        if mode == "graph":
            averages = self._compute_lifecycle_averages(columns, rows)
            self._render_graph(averages)
            self.btn_export.config(state=("normal" if rows else "disabled"))
        else:
            self._render_table(columns, rows)
            self.btn_export.config(state=("normal" if rows else "disabled"))

    # ---------- Helpers for lifecycle graph ----------
    def _render_stakeholder_lifecycle_graph(self, stakeholders, avg_days):
        self._clear_results_area()

        fig = Figure(figsize=(10, 4), dpi=100)
        ax = fig.add_subplot(111)

        x_pos = range(len(stakeholders))
        ax.bar(x_pos, avg_days, width=0.6, edgecolor="black")

        for x, val in zip(x_pos, avg_days):
            if val is None:
                continue
            ax.text(
                x,
                val + (max(avg_days) * 0.015 if max(avg_days) else 0.5),
                f"{val:.1f}",
                ha="center",
                va="bottom",
                fontsize=8,
            )

        ax.set_xticks(list(x_pos))
        ax.set_xticklabels(stakeholders, rotation=45, ha="right", fontsize=8)
        ax.set_xlabel("Stakeholder")
        ax.set_ylabel("average holdup duration (days)")
        ax.set_title("average holdup duration (days)", fontsize=10, pad=8)

        fig.tight_layout(pad=1.1)

        canvas = FigureCanvasTkAgg(fig, master=self.results_wrap)
        widget = canvas.get_tk_widget()
        widget.grid(row=0, column=0, sticky="nsew")
        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)

        canvas.draw()

        self._chart_canvas = canvas
        self._chart_figure = fig

    def _clear_results_area(self):
        for w in self.results_wrap.grid_slaves():
            w.destroy()

        self.tree = None
        self.vsb = None
        self.hsb = None

        if self._chart_canvas is not None:
            try:
                self._chart_canvas.get_tk_widget().destroy()
            except Exception:
                pass
            self._chart_canvas = None
            self._chart_figure = None

        self.graph_canvas = None

    def _compute_lifecycle_averages(self, columns: List[str], rows: List[List[str]]) -> List[Tuple[str, float]]:
        if not rows:
            return [(s, 0.0) for s in STAKEHOLDER_ORDER]

        totals = {s: 0 for s in STAKEHOLDER_ORDER}
        counts = {s: 0 for s in STAKEHOLDER_ORDER}

        for r in rows:
            for idx, s in enumerate(STAKEHOLDER_ORDER, start=2):
                if idx >= len(r):
                    continue
                cell = r[idx]
                val = 0
                if isinstance(cell, str) and cell.strip().endswith("days"):
                    try:
                        val = int(cell.strip().split()[0])
                    except Exception:
                        val = 0
                else:
                    try:
                        val = int(cell)
                    except Exception:
                        val = 0

                if val > 0:
                    totals[s] += val
                    counts[s] += 1

        averages: List[Tuple[str, float]] = []
        for s in STAKEHOLDER_ORDER:
            if counts[s] > 0:
                avg = totals[s] / counts[s]
            else:
                avg = 0.0
            averages.append((s, avg))

        return averages

    def _render_graph(self, averages: List[Tuple[str, float]]):
        self._clear_results_area()

        canvas = tk.Canvas(self.results_wrap, background="white")
        canvas.grid(row=0, column=0, sticky="nsew")
        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)
        self.graph_canvas = canvas

        width = 1100
        height = 520
        try:
            canvas.config(width=width, height=height)
        except Exception:
            pass

        left_margin = 80
        right_margin = 40
        top_margin = 40
        bottom_margin = 120

        max_val = max((v for (_, v) in averages), default=0.0)
        if max_val == 0:
            max_val = 1.0

        plot_width = width - left_margin - right_margin
        plot_height = height - top_margin - bottom_margin

        x0 = left_margin
        y0 = top_margin
        x1 = left_margin
        y1 = top_margin + plot_height

        canvas.create_line(x0, y0, x1, y1, width=2)
        canvas.create_line(x1, y1, x1 + plot_width, y1, width=2)

        canvas.create_text(left_margin, 15, text="average holdup duration (days)", anchor="w", font=("Segoe UI", 10, "bold"))
        canvas.create_text(width // 2, height - 40, text="Stakeholder", anchor="center", font=("Segoe UI", 10, "bold"))

        n = len(averages)
        if n == 0:
            return

        bar_space = plot_width / max(n, 1)
        bar_width = bar_space * 0.6

        for i, (name, val) in enumerate(averages):
            bar_h = (val / max_val) * plot_height
            x_center = x1 + (i + 0.5) * bar_space
            x_left = x_center - bar_width / 2
            x_right = x_center + bar_width / 2
            y_top = y1 - bar_h

            canvas.create_rectangle(x_left, y_top, x_right, y1, outline="black", fill="lightgray")
            canvas.create_text(x_center, y_top - 10, text=f"{val:.1f}", anchor="s", font=("Segoe UI", 8))
            canvas.create_line(x_center, y1, x_center, y1 + 5)

            label_lines = name.split(" ")
            txt = "\n".join(label_lines)
            canvas.create_text(x_center, y1 + 10, text=txt, anchor="n", font=("Segoe UI", 8))

    # ---------- Table / Export ----------
    def _export_current_view(self):
        if not self._last_columns or not self._last_rows:
            messagebox.showinfo("Nothing to export", "There is no data in the current view.")
            return

        default_name = f"{self.report_var.get()}.xlsx"
        path = filedialog.asksaveasfilename(
            title="Export Current View",
            defaultextension=".xlsx",
            initialfile=default_name,
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not path:
            return

        try:
            df_out = pd.DataFrame(self._last_rows, columns=self._last_columns)
            df_out.to_excel(path, index=False)
        except Exception as e:
            messagebox.showerror("Export failed", f"Could not export the current view:\n\n{e}")
            return

        messagebox.showinfo("Export complete", f"Saved:\n{path}")

    def _render_table(self, columns: List[str], data_rows: List[List[str]]):
        self._clear_results_area()

        self.tree = ttk.Treeview(self.results_wrap, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=max(120, min(220, len(col) * 12)), anchor="w", stretch=False)

        self.vsb = ttk.Scrollbar(self.results_wrap, orient="vertical", command=self.tree.yview)
        self.hsb = ttk.Scrollbar(self.results_wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        self.vsb.grid(row=0, column=1, sticky="ns")
        self.hsb.grid(row=1, column=0, sticky="ew")

        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)

        for r in data_rows:
            if len(r) < len(columns):
                r = r + ["-"] * (len(columns) - len(r))
            self.tree.insert("", "end", values=r)
