from core.base import ProgramSpec, ToolSpec
from .home import DCD_Home
from .reports import DCD_Reports

DCD_PROGRAM = ProgramSpec(
    id="dcd",
    name="DCD",
    tools=[
        ToolSpec("home", "Home", DCD_Home),
        ToolSpec("reports", "Reports", DCD_Reports),
    ],
)