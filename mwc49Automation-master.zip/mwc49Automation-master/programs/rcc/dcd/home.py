# programs/rcc/dcd/home.py
from __future__ import annotations

import os
from datetime import datetime
import threading
from typing import Sequence

import pandas as pd
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import StringVar, DISABLED, NORMAL

from core.base import ToolView, FONT_H2
from services.db.dcd_db import DCDDB, TABLE_NAME, MINIMAL_DATA_COLS

# ----------------------------- Config -----------------------------
SHEET_NAME = "DCD Program Tracker 2026"
HEADER_ROW_INDEX = 10  # 0-based; Excel row 11 has headers, row 12 starts data

# Columns to ingest from Excel (modular: add more here later)
SELECTED_COLUMNS: Sequence[str] = [
    "PM",
    "Mat Code",
    "Notification #",
    "Primary Hold-Up",
]


class DCD_Home(ToolView):
    """
    DCD ingest UI (single-file for now).

    - Row 3: workbook path (entry + browse)
    - Row 4: actions (Update Database, Clear Database Entry, Clear Database)
    - Row 5+: split: left 'Database Updates', right 'Snapshot Preview'
    """

    def __init__(self, parent, program_name, tool_name):
        super().__init__(parent, program_name, tool_name)

        # DB service
        self.db = DCDDB()
        self.db.ensure_table(MINIMAL_DATA_COLS)

        # optional hygiene (no-op if nothing to fix)
        try:
            self.db.normalize_pm_numbers()
        except Exception:
            pass

        self._selected_snapshot: tuple[str, str] | None = None  # (timestamp, file_name)
        self.selected_path: str | None = None

        self.columnconfigure(0, weight=1)

        # ---------- File picker ----------
        row = 3  # start from row 3 (as requested)
        top = ttk.Frame(self)
        top.grid(row=row, column=0, sticky="ew", padx=16, pady=(8, 4))
        top.columnconfigure(1, weight=1)

        ttk.Label(top, text="Workbook path:").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.path_var = StringVar()
        ttk.Entry(top, textvariable=self.path_var).grid(row=0, column=1, sticky="ew")
        ttk.Button(top, text="Browse…", command=self._browse).grid(row=0, column=2, padx=(8, 0))

        # ---------- Actions ----------
        row += 1
        actions = ttk.Frame(self)
        actions.grid(row=row, column=0, sticky="w", padx=16, pady=(4, 10))

        self.btn_update = ttk.Button(actions, text="Update Database", command=self._update_db, state=DISABLED)
        self.btn_update.grid(row=0, column=0, padx=(0, 8))

        self.btn_clear_entry = ttk.Button(actions, text="Clear Database Entry", command=self._clear_selected_entry, state=DISABLED)
        self.btn_clear_entry.grid(row=0, column=1, padx=(0, 8))

        self.btn_clear_all = ttk.Button(actions, text="Clear Database", command=self._clear_all, state=DISABLED)
        self.btn_clear_all.grid(row=0, column=2, padx=(0, 8))

        self.path_var.trace_add("write", lambda *_: self._toggle_update_button())

        # ---------- Upper block ----------
        row += 1
        block = ttk.Frame(self)
        block.grid(row=row, column=0, sticky="nsew", padx=16, pady=(0, 8))
        self.rowconfigure(row, weight=1)
        block.columnconfigure(0, weight=1)
        block.columnconfigure(1, weight=1)
        block.rowconfigure(1, weight=1)

        ttk.Label(block, text="Database Updates", font=FONT_H2).grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Label(block, text="Snapshot Preview", font=FONT_H2).grid(row=0, column=1, sticky="w", pady=(0, 6))

        # LEFT: history
        left = ttk.Frame(block)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        cols_hist = ("Last Update", "File Name", "_key")
        self.hist = ttk.Treeview(left, columns=cols_hist, show="headings", selectmode="browse")
        self.hist.heading("Last Update", text="Last Update")
        self.hist.heading("File Name", text="File Name")
        self.hist.heading("_key", text="_key")
        self.hist.column("Last Update", width=180, anchor="w")
        self.hist.column("File Name", anchor="w", stretch=True)
        self.hist.column("_key", width=0, minwidth=0, stretch=False)

        vsb_hist = ttk.Scrollbar(left, orient="vertical", command=self.hist.yview)
        self.hist.configure(yscrollcommand=vsb_hist.set)
        self.hist.grid(row=0, column=0, sticky="nsew")
        vsb_hist.grid(row=0, column=1, sticky="ns")
        self.hist.bind("<Double-1>", self._on_hist_dblclick)

        # RIGHT: preview
        right = ttk.Frame(block)
        right.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)

        cols_prev = ("Timestamp", "PM", "Notification #", "Mat Code")
        self.preview = ttk.Treeview(right, columns=cols_prev, show="headings", selectmode="browse")
        for c in cols_prev:
            self.preview.heading(c, text=c)
        self.preview.column("Timestamp", width=180, anchor="w")
        self.preview.column("PM", anchor="w", stretch=True)
        self.preview.column("Notification #", width=160, anchor="w")
        self.preview.column("Mat Code", width=140, anchor="w")

        vsb_prev = ttk.Scrollbar(right, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=vsb_prev.set)
        self.preview.grid(row=0, column=0, sticky="nsew")
        vsb_prev.grid(row=0, column=1, sticky="ns")

        # initial load
        self._refresh_history()
        self._update_clear_buttons_enabled()

    # ----------------------- UI Handlers -----------------------
    def _browse(self):
        path = filedialog.askopenfilename(
            title="Select an Excel workbook",
            filetypes=[("Excel files", "*.xlsx *.xlsm *.xlsb *.xls"), ("All files", "*.*")]
        )
        if not path:
            return
        self.selected_path = path
        self.path_var.set(path)
        self._toggle_update_button()

    def _toggle_update_button(self):
        self.btn_update.config(state=(NORMAL if self.selected_path else DISABLED))

    def _refresh_history(self):
        for iid in self.hist.get_children():
            self.hist.delete(iid)

        snapshots = self.db.distinct_snapshots()
        for ts, fname, _cnt in snapshots:
            key = f"{ts}||{fname}"
            self.hist.insert("", "end", values=(ts, fname, key))

        self.btn_clear_all.config(state=(NORMAL if snapshots else DISABLED))
        self._selected_snapshot = None
        self.btn_clear_entry.config(state=DISABLED)
        self._clear_preview()

    def _clear_preview(self):
        for iid in self.preview.get_children():
            self.preview.delete(iid)

    def _on_hist_dblclick(self, _event=None):
        item = self.hist.focus()
        if not item:
            return
        vals = self.hist.item(item, "values")
        if len(vals) < 3:
            return
        ts, fname, _key = vals
        self._selected_snapshot = (ts, fname)
        self._refresh_preview_for_selected()
        self._update_clear_buttons_enabled()

    def _refresh_preview_for_selected(self):
        self._clear_preview()
        if not self._selected_snapshot:
            return
        ts, fname = self._selected_snapshot
        rows = self.db.snapshot_preview(ts, fname)
        for row in rows:
            self.preview.insert("", "end", values=row)

    def _update_clear_buttons_enabled(self):
        self.btn_clear_entry.config(state=(NORMAL if self._selected_snapshot else DISABLED))

    # -------------------- Actions / DB Ops ---------------------
    def _update_db(self):
        if not self.selected_path:
            messagebox.showinfo("No file", "Please select a workbook first.")
            return

        path = self.selected_path
        if not os.path.exists(path):
            messagebox.showerror("Not found", f"Path not found:\n{path}")
            return

        # timestamp = time when ingest happens
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        busy = _BusyDialog(self, message="Uploading…")
        self._set_actions_enabled(False)

        result: dict[str, object] = {"inserted": 0, "error": None}

        def worker():
            try:
                df = _read_sheet_robust(
                    path=path,
                    sheet_name=SHEET_NAME,
                    header_row=HEADER_ROW_INDEX,
                    wanted_cols=list(SELECTED_COLUMNS),
                )

                df = df.dropna(how="all", subset=list(SELECTED_COLUMNS))

                df["timestamp"] = ts
                df["file_name"] = os.path.basename(path)

                n = self.db.insert_dataframe(df)
                result["inserted"] = n
            except Exception as e:
                result["error"] = str(e)

        t = threading.Thread(target=worker, daemon=True)
        t.start()

        def poll():
            if t.is_alive():
                self.after(100, poll)
                return

            try:
                busy.close()
            except Exception:
                pass

            try:
                self.db.normalize_pm_numbers()
            except Exception:
                pass

            err = result.get("error")
            inserted = int(result.get("inserted", 0) or 0)

            if err:
                messagebox.showerror("Ingest failed", f"Could not ingest file:\n\n{err}")
            else:
                messagebox.showinfo("Success", f"Inserted {inserted} rows into {TABLE_NAME}.")

            self._refresh_history()
            self._set_actions_enabled(True)

        self.after(120, poll)

    def _clear_selected_entry(self):
        if not self._selected_snapshot:
            return
        ts, fname = self._selected_snapshot
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Delete the snapshot for:\n\nTimestamp: {ts}\nFile: {fname}\n\nThis cannot be undone."
        ):
            return
        try:
            deleted = self.db.delete_snapshot(ts, fname)
            messagebox.showinfo("Deleted", f"Deleted {deleted} rows for the selected snapshot.")
        except Exception as e:
            messagebox.showerror("DB Error", f"Failed to delete snapshot:\n{e}")
            return
        self._refresh_history()

    def _clear_all(self):
        if not messagebox.askyesno(
            "Confirm Delete All",
            f"Delete ALL rows in the {TABLE_NAME} table? This cannot be undone."
        ):
            return
        try:
            deleted = self.db.delete_all()
            messagebox.showinfo("Deleted", f"Deleted {deleted} rows from {TABLE_NAME}.")
        except Exception as e:
            messagebox.showerror("DB Error", f"Failed to clear database:\n{e}")
            return
        self._refresh_history()

    def _set_actions_enabled(self, enabled: bool):
        state = NORMAL if enabled else DISABLED
        self.btn_update.config(state=state if self.selected_path else DISABLED)
        self.btn_clear_entry.config(state=state if self._selected_snapshot else DISABLED)
        self.btn_clear_all.config(state=state if self.db.distinct_snapshots() else DISABLED)


# --------------------------- Helpers -----------------------------
def _pick_engine(path: str) -> str | None:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return "openpyxl"
    if ext == ".xlsb":
        return "pyxlsb"
    return None


def _read_sheet_robust(path: str, sheet_name: str, header_row: int, wanted_cols: list[str]) -> pd.DataFrame:
    """
    Reads the Excel sheet, *never* failing if some wanted columns are missing.
    - Uses a callable `usecols` to include only columns that match (case-insensitive).
    - Adds any still-missing columns with pd.NA.
    - Returns a DataFrame with EXACTLY the wanted columns, in order.
    """
    norm_wanted = {c.strip().lower() for c in wanted_cols}

    df = pd.read_excel(
        path,
        sheet_name=sheet_name,
        header=header_row,
        engine=_pick_engine(path),
        usecols=lambda c: str(c).strip().lower() in norm_wanted,
        dtype="string",
    )

    for col in wanted_cols:
        if col not in df.columns:
            df[col] = pd.NA

    df = df[wanted_cols]
    return df


class _BusyDialog(tk.Toplevel):
    def __init__(self, parent, message: str = "Working…"):
        super().__init__(parent)
        self.title("Please wait")
        self.transient(parent)
        self.resizable(False, False)
        self.grab_set()

        frm = ttk.Frame(self, padding=12)
        frm.grid(sticky="nsew")
        frm.columnconfigure(0, weight=1)

        self.msg_var = tk.StringVar(value=message)
        ttk.Label(frm, textvariable=self.msg_var).grid(row=0, column=0, sticky="w")

        self.pb = ttk.Progressbar(frm, mode="indeterminate", length=260)
        self.pb.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        try:
            self.pb.start(12)
        except Exception:
            pass

        self.update_idletasks()
        try:
            px, py = parent.winfo_rootx(), parent.winfo_rooty()
            pw, ph = parent.winfo_width(), parent.winfo_height()
            sw, sh = self.winfo_width(), self.winfo_height()
            self.geometry(f"+{px + (pw - sw)//2}+{py + (ph - sh)//2}")
        except Exception:
            pass

    def close(self):
        try:
            self.pb.stop()
        except Exception:
            pass
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()
