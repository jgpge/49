from core.base import ProgramSpec, ToolSpec
from .home import COE_Home
from .reports import COE_Reports

COE_PROGRAM = ProgramSpec(
    id="coe",
    name="COE",
    tools=[
        ToolSpec("home", "Home", COE_Home),
        ToolSpec("reports", "Reports", COE_Reports),
    ],
)