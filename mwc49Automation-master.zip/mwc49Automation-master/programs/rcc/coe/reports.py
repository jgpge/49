# programs/rcc/coe/reports.py
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import pandas as pd

from core.base import ToolView, FONT_H2
from services.db.coe_db import COEDB, TABLE_NAME

from helpers.coe_reports.current_stakeholder_holdup import make_current_stakeholder_holdup_table

REPORT_CURRENT_STK = "Current Stakeholder Holdup"
REPORT_OPTIONS = [REPORT_CURRENT_STK]


class COE_Reports(ToolView):
    def __init__(self, parent, program_name, tool_name):
        super().__init__(parent, program_name, tool_name)

        self.db = COEDB()

        # ---------- State ----------
        self.report_var = tk.StringVar(value=REPORT_OPTIONS[0])
        self._last_columns: list[str] = []
        self._last_rows: list[list[str]] = []

        # ---------- Layout ----------
        self.columnconfigure(0, weight=1)
        row = 3  # start from row 3 (as requested)

        # Header
        hdr = ttk.Frame(self)
        hdr.grid(row=row, column=0, sticky="ew", padx=16, pady=(8, 6))
        hdr.columnconfigure(1, weight=1)

        ttk.Label(hdr, text="Reports", font=FONT_H2).grid(row=0, column=0, sticky="w", padx=(0, 12))
        sel = ttk.Combobox(hdr, textvariable=self.report_var, values=REPORT_OPTIONS, state="readonly", width=40)
        sel.grid(row=0, column=1, sticky="w")
        sel.bind("<<ComboboxSelected>>", lambda _e: self._on_report_change())

        self.btn_export = ttk.Button(hdr, text="Export Current View", command=self._export_current_view, state="disabled")
        self.btn_export.grid(row=0, column=2, sticky="e")

        # Body split
        row += 1
        body = ttk.Frame(self)
        body.grid(row=row, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.rowconfigure(row, weight=1)
        body.columnconfigure(0, weight=1)  # LEFT grows
        body.columnconfigure(1, weight=0)  # RIGHT fixed
        body.rowconfigure(0, weight=1)

        # LEFT: results area (treeview)
        self.results_wrap = ttk.Frame(body)
        self.results_wrap.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)

        self.tree = None
        self.vsb = None
        self.hsb = None

        # RIGHT: settings (minimal but same style)
        self.settings = ttk.Frame(body)
        self.settings.grid(row=0, column=1, sticky="n")
        self._build_settings(self.settings)

        # Initial render
        self._on_report_change()

    # ---------- Settings UI ----------
    def _build_settings(self, parent: ttk.Frame):
        parent.columnconfigure(0, weight=0)

        ttk.Label(parent, text="Settings", font=FONT_H2).grid(row=0, column=0, sticky="w", pady=(0, 6))

        grp = ttk.LabelFrame(parent, text="Actions")
        grp.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        grp.columnconfigure(0, weight=1)

        ttk.Button(grp, text="Refresh", command=self._draw).grid(row=0, column=0, sticky="ew", padx=8, pady=8)

        self.info_var = tk.StringVar(value="")
        ttk.Label(parent, textvariable=self.info_var).grid(row=2, column=0, sticky="w", pady=(4, 0))

    # ---------- Event handlers ----------
    def _on_report_change(self):
        self._draw()

    # ---------- Draw ----------
    def _draw(self):
        report = self.report_var.get()
        if report != REPORT_CURRENT_STK:
            self._clear_results_area()
            ttk.Label(self.results_wrap, text="Unsupported report").grid(row=0, column=0, sticky="nsew")
            return

        # Build table based on latest timestamp snapshot
        columns, rows, total_raw, latest_ts, unmapped = make_current_stakeholder_holdup_table(
            db_path=self.db.db_path,
            table_name=self.db.table,
        )

        if latest_ts:
            self.info_var.set(
                f"Latest snapshot: {latest_ts} | Raw rows: {total_raw} | After filters: {len(rows)} | Unmapped: {unmapped}"
            )
        else:
            self.info_var.set("No data found in database yet. Please ingest a COE workbook first.")

        self._last_columns = columns
        self._last_rows = rows

        self._render_table(columns, rows)
        self.btn_export.config(state=("normal" if rows else "disabled"))

    # ---------- Table / Export ----------
    def _export_current_view(self):
        if not self._last_columns or not self._last_rows:
            messagebox.showinfo("Nothing to export", "There is no data in the current view.")
            return

        default_name = f"{self.report_var.get()}.xlsx"
        path = filedialog.asksaveasfilename(
            title="Export Current View",
            defaultextension=".xlsx",
            initialfile=default_name,
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not path:
            return

        try:
            df_out = pd.DataFrame(self._last_rows, columns=self._last_columns)
            df_out.to_excel(path, index=False)
        except Exception as e:
            messagebox.showerror("Export failed", f"Could not export the current view:\n\n{e}")
            return

        messagebox.showinfo("Export complete", f"Saved:\n{path}")

    def _render_table(self, columns: list[str], data_rows: list[list[str]]):
        self._clear_results_area()

        self.tree = ttk.Treeview(self.results_wrap, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=max(120, min(240, len(col) * 12)), anchor="w", stretch=False)

        self.vsb = ttk.Scrollbar(self.results_wrap, orient="vertical", command=self.tree.yview)
        self.hsb = ttk.Scrollbar(self.results_wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        self.vsb.grid(row=0, column=1, sticky="ns")
        self.hsb.grid(row=1, column=0, sticky="ew")

        self.results_wrap.columnconfigure(0, weight=1)
        self.results_wrap.rowconfigure(0, weight=1)

        for r in data_rows:
            if len(r) < len(columns):
                r = r + [""] * (len(columns) - len(r))
            self.tree.insert("", "end", values=r)

    def _clear_results_area(self):
        for w in self.results_wrap.grid_slaves():
            w.destroy()
        self.tree = None
        self.vsb = None
        self.hsb = None
