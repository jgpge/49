# services/analysis/change_tracker.py
from __future__ import annotations
import re
from typing import List, Dict, Tuple, Any

# Dependency → the two sheets we treat as a pair
GROUPS = {
    "Permit":     ["Permit", "BTag Permit"],
    "Joint Pole": ["Joint Pole", "BTag Joint Pole"],
    # Land / Enviro can be added later the same way
}

def _table_exists(con, name: str) -> bool:
    r = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    return r is not None

def _canon(s: str) -> str:
    return (s or "").strip().casefold()

def analyze_same_action(db, dependency: str, depth: int) -> List[Dict[str, Any]]:
    """
    Return rows like:
      {
        "order": str, "btag": "Y"/"N", "action": str,
        "file_latest": str, "ts_latest": str,
        "file_prev": str,   "ts_prev": str,
        ["file_prev2","ts_prev2"], ["file_prev3","ts_prev3"]
      }

    Auto-detects DB schema:
      - PolesDB: per-sheet tables ("Permit", "BTag Permit", …)
      - MaintenanceDB: normalized "sheet_row" table
    """
    con = db.con
    if _table_exists(con, "sheet_row"):
        return _analyze_from_sheet_row(con, dependency, depth)
    else:
        return _analyze_from_per_sheet_tables(con, dependency, depth)

# ---------- MaintenanceDB path (normalized schema) ----------
def _analyze_from_sheet_row(con, dependency: str, depth: int) -> List[Dict[str, Any]]:
    sheets = GROUPS.get(dependency)
    if not sheets:
        return []

    snaps = con.execute(
        "SELECT id, loaded_at, file_name FROM snapshot_meta ORDER BY loaded_at DESC LIMIT ?",
        (depth,)
    ).fetchall()
    if len(snaps) < depth:
        return []

    # Build per-snapshot map: key=(order,btag) -> (action, ts, file)
    per: List[Dict[Tuple[str, str], Tuple[str, str, str]]] = []
    placeholders = ",".join("?" * len(sheets))
    for sid, ts, fname in snaps:
        rows = con.execute(
            f"""
            SELECT sheet_name, "order" AS ord, action
            FROM sheet_row
            WHERE snapshot_id = ? AND sheet_name IN ({placeholders})
                  AND ord IS NOT NULL AND TRIM(ord) <> ''
            """,
            (int(sid), *sheets)
        ).fetchall()
        m: Dict[Tuple[str, str], Tuple[str, str, str]] = {}
        for sheet, ordv, act in rows:
            key = (str(ordv).strip(), "Y" if "BTag" in sheet else "N")
            m[key] = (str(act or "").strip(), str(ts), str(fname))
        per.append(m)  # order is latest -> older

    # Keys that exist in *all* snapshots
    keys = set(per[0].keys())
    for m in per[1:]:
        keys &= set(m.keys())

    out: List[Dict[str, Any]] = []
    for key in sorted(keys):
        acts = [per[i][key][0] for i in range(depth)]
        if all(_canon(a) and _canon(a) == _canon(acts[0]) for a in acts):
            order, btag = key
            latest = per[0][key]; prev = per[1][key]
            row = {
                "order": order,
                "btag": btag,
                "action": acts[0],
                "file_latest": latest[2],
                "ts_latest":   latest[1],
                "file_prev":   prev[2],
                "ts_prev":     prev[1],
            }
            if depth >= 3:
                prev2 = per[2][key]
                row["file_prev2"] = prev2[2]
                row["ts_prev2"]   = prev2[1]
            if depth >= 4:
                prev3 = per[3][key]
                row["file_prev3"] = prev3[2]
                row["ts_prev3"]   = prev3[1]
            out.append(row)
    return out

# ---------- PolesDB path (per-sheet tables) ----------
def _analyze_from_per_sheet_tables(con, dependency: str, depth: int) -> List[Dict[str, Any]]:
    sheets = GROUPS.get(dependency)
    if not sheets:
        return []

    snaps = con.execute(
        "SELECT id, loaded_at, file_name FROM snapshot_meta ORDER BY id DESC LIMIT ?",
        (depth,)
    ).fetchall()
    if len(snaps) < depth:
        return []

    def _find_order_col(sheet: str) -> str | None:
        cols = [r[1] for r in con.execute(f'PRAGMA table_info("{sheet}")').fetchall()]
        for c in cols:
            if c.lower() == "order":
                return c
        return None

    def _find_action_col(sheet: str) -> str | None:
        cols = [r[1] for r in con.execute(f'PRAGMA table_info("{sheet}")').fetchall()]
        def canon(s: str) -> str: return re.sub(r"[^a-z0-9]+", "", (s or "").lower())
        norm = {canon(c): c for c in cols}
        for alias in ("action", "currentaction", "actionitem", "actions"):
            if alias in norm:
                return norm[alias]
        for c in cols:
            if "action" in canon(c):
                return c
        return None

    per = []
    for sid, ts, fname in snaps:
        m = {}
        for sheet in sheets:
            ocol = _find_order_col(sheet)
            acol = _find_action_col(sheet)
            if not ocol or not acol:
                continue
            q = f'SELECT "{ocol}" AS ord, "{acol}" AS act FROM "{sheet}" WHERE snapshot_id=? AND ord IS NOT NULL AND TRIM(ord)<>""'
            for ordv, act in con.execute(q, (str(sid),)):
                key = (str(ordv).strip(), "Y" if "BTag" in sheet else "N")
                m[key] = (str(act or "").strip(), str(ts), str(fname))
        per.append(m)

    keys = set(per[0].keys())
    for m in per[1:]:
        keys &= set(m.keys())

    out = []
    for key in sorted(keys):
        acts = [per[i][key][0] for i in range(depth)]
        if all(_canon(a) and _canon(a) == _canon(acts[0]) for a in acts):
            order, btag = key
            latest = per[0][key]; prev = per[1][key]
            row = {
                "order": order,
                "btag": btag,
                "action": acts[0],
                "file_latest": latest[2],
                "ts_latest":   latest[1],
                "file_prev":   prev[2],
                "ts_prev":     prev[1],
            }
            if depth >= 3:
                prev2 = per[2][key]
                row["file_prev2"] = prev2[2]
                row["ts_prev2"]   = prev2[1]
            if depth >= 4:
                prev3 = per[3][key]
                row["file_prev3"] = prev3[2]
                row["ts_prev3"]   = prev3[1]
            out.append(row)
    return out