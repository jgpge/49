# sanity/joint_pole_sanity.py
# UI + logic for "Joint Pole Sanity Checks" (one row per action; BTag vs Non-Tag counts)
# Requires: pandas, openpyxl
import os
from pathlib import Path
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

# Action buckets (table rows)
ACTION_TYPES = [
    "released. verify pc20",
    "ou days exceeded. complete pc20 and ds48",
    "intent in ready to send status. please send to ou",
    "intent deleted/draft/cancelled",
]

# Exact Action values that roll up to the deleted/draft/cancelled bucket
DELETED_DRAFT_CANCELLED_VALUES = {
    "intent deleted. review and complete task if jp is not needed",
    "intent in draft. review and provide update",
    "intent cancelled. review and complete task if jp is not needed",
}

# Display Labels for Table
DISPLAY_LABELS = {
    "released. verify pc20": "Released. Verify PC20",
    "ou days exceeded. complete pc20 and ds48": "OU Days Exceeded. Complete PC20 and DS48",
    "intent in ready to send status. please send to ou": "Intent in Ready to Send Status. Please Send to OU",
    "intent deleted/draft/cancelled": "Intent Deleted/Draft/Cancelled",
}


# Sheet names
SHEET_NORMAL = "Joint Pole"
SHEET_BTAG   = "BTag Joint Pole"   # <- make sure this matches your workbook


def _load_actions(path: str, sheet: str, btag_yes: bool) -> pd.DataFrame:
    """
    Load a sheet and return DataFrame with: ['Order', 'Action', 'BTag (Y/N)'].
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Workbook not found:\n{path}")

    df = pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    df.columns = df.columns.str.strip()

    missing = [c for c in ["Order", "Action"] if c not in df.columns]
    if missing:
        raise KeyError(
            f"Missing expected column(s) in sheet '{sheet}': {missing}\n"
            f"Found columns: {list(df.columns)}"
        )

    out = df[["Order", "Action"]].copy()
    out["BTag (Y/N)"] = "Yes" if btag_yes else "No"
    return out


def _canonicalize_action(action_str: str) -> str | None:
    """
    Map raw Action to one of ACTION_TYPES (case-insensitive match), else None.
    """
    if not isinstance(action_str, str):
        return None
    s = action_str.strip().casefold()

    if s == "released. verify pc20":
        return "released. verify pc20"
    if s == "ou days exceeded. complete pc20 and ds48":
        return "ou days exceeded. complete pc20 and ds48"
    if s == "intent in ready to send status. please send to ou":
        return "intent in ready to send status. please send to ou"
    if s in DELETED_DRAFT_CANCELLED_VALUES:
        return "intent deleted/draft/cancelled"
    return None


def compute_joint_pole_sanity_summary(file_path: str) -> pd.DataFrame:
    """
    Returns a DataFrame with columns:
      ['Action Type', 'Order Count (BTag)', 'Order Count (Non-Tag)']
    One row per Action Type, with distinct-Order counts split by BTag Yes/No.
    """
    # Load both sheets
    df_norm = _load_actions(file_path, SHEET_NORMAL, btag_yes=False)
    df_btag = _load_actions(file_path, SHEET_BTAG,   btag_yes=True)

    # Combine & canonicalize
    df = pd.concat([df_norm, df_btag], ignore_index=True)
    df["Action Type"] = df["Action"].apply(_canonicalize_action)
    df = df[df["Action Type"].notna()].copy()

    # Normalize Order and decide counting mode
    df["Order"] = df["Order"].astype(str).str.strip()
    has_any_order = df["Order"].ne("").any()

    def counts_for(flag: str) -> pd.Series:
        sub = df[df["BTag (Y/N)"] == flag]
        if has_any_order:
            grp = sub[sub["Order"] != ""].groupby("Action Type")["Order"].nunique()
        else:
            grp = sub.groupby("Action Type").size()
        return grp.reindex(ACTION_TYPES, fill_value=0)

    btag_yes_counts = counts_for("Yes")
    btag_no_counts  = counts_for("No")

    result = pd.DataFrame({
        "Action Type": ACTION_TYPES,
        "Order Count (BTag)": btag_yes_counts.values.astype(int),
        "Order Count (Non-Tag)": btag_no_counts.values.astype(int),
    })
    return result


def build_joint_pole_sanity_ui(parent: tk.Widget, get_file_path) -> dict:
    """
    Build the UI into `parent`:
      - Header "Joint Pole Sanity Checks" + Refresh button
      - Read-only table with columns: Action Type | Order Count (BTag) | Order Count (Non-Tag)

    `get_file_path`: callable that returns the currently selected workbook path (str).
    Returns dict: {'frame': frame, 'refresh': refresh_func}
    """
    frame = ttk.Frame(parent)
    frame.grid(row=0, column=0, sticky="nsew")
    frame.columnconfigure(0, weight=1)
    frame.rowconfigure(1, weight=1)

    # Top row: header + refresh
    top = ttk.Frame(frame)
    top.grid(row=0, column=0, sticky="we", padx=8, pady=(8, 4))
    ttk.Label(top, text="Joint Pole Sanity Checks", font=("Segoe UI", 11, "bold")).pack(side="left")

    cols = ("Action Type", "Order Count (BTag)", "Order Count (Non-Tag)")
    tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")

    for c in cols:
        tree.heading(c, text=c)
    tree.column("Action Type", width=300, anchor="w")
    tree.column("Order Count (BTag)", width=150, anchor="center")
    tree.column("Order Count (Non-Tag)", width=150, anchor="center")

    vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=vsb.set)

    tree.grid(row=1, column=0, sticky="nsew", padx=(8, 0), pady=(0, 8))
    vsb.grid(row=1, column=1, sticky="ns", pady=(0, 8))

    def do_refresh():
        path = (get_file_path() or "").strip()
        if not path:
            #messagebox.showerror("Missing file", "Please choose a workbook file.")
            return
        if not os.path.exists(path):
            messagebox.showerror("Not found", f"File does not exist:\n{path}")
            return
        try:
            data = compute_joint_pole_sanity_summary(path)
            data = data.copy()
            data["Action Type"] = data["Action Type"].map(DISPLAY_LABELS).fillna(data["Action Type"])
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        # refill table
        for i in tree.get_children():
            tree.delete(i)
        for _, row in data.iterrows():
            tree.insert(
                "",
                "end",
                values=(row["Action Type"], int(row["Order Count (BTag)"]), int(row["Order Count (Non-Tag)"]))
            )

    ttk.Button(top, text="Refresh", command=do_refresh).pack(side="right")

    return {"frame": frame, "refresh": do_refresh}
