# sanity/permit_sanity.py
# UI + logic for "Permit Sanity Checks" (per Action: table by Div with BTag vs Non-Tag counts)
# Requires: pandas, openpyxl
import os
from pathlib import Path
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

# ----- Sheets -----
SHEET_NORMAL = "Permit"
SHEET_BTAG   = "BTag Permit"   # make sure this matches your workbook

# ----- Action buckets (canonical keys → accepted raw strings to match in 'Action' col) -----
# We match case-insensitively and trimmed. Included common misspelling "comfirm".
ACTION_MAP = {
    "confirm permit is approved and complete sap task": {
        "confirm permit is approved and complete sap task",
        "comfirm permit is approved and complete sap task",
    },
    "need click date for extension": {
        "need click date for extension",
    },
    "permit not needed. close sp/rp56": {
        "permit not needed. close sp/rp56",
    },
    "request for extension": {
        "request for extension",
    },
    "submitted over 30 days. provide update": {
        "submitted over 30 days. provide update",
    },
}

# Display labels (for sub-headings)
DISPLAY_LABELS = {
    "confirm permit is approved and complete sap task": "Confirm Permit is Approved and Complete SAP Task",
    "need click date for extension": "Need Click Date for Extension",
    "permit not needed. close sp/rp56": "Permit Not Needed. Close SP/RP56",
    "request for extension": "Request for Extension",
    "submitted over 30 days. provide update": "Submitted Over 30 Days. Provide Update",
}


def _load_minimal(path: str, sheet: str, btag_yes: bool) -> pd.DataFrame:
    """
    Load only what's needed and stamp BTag flag.
    Returns columns: ['Div', 'Order', 'Action', 'BTag (Y/N)']
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Workbook not found:\n{path}")

    df = pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program
    df = df[df["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()  
    df.columns = df.columns.str.strip()

    required = ["Div", "Order", "Action"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(
            f"Missing expected column(s) in sheet '{sheet}': {missing}\n"
            f"Found columns: {list(df.columns)}"
        )

    out = df[required].copy()
    out["BTag (Y/N)"] = "Yes" if btag_yes else "No"
    return out


def _canonicalize_action(s: str) -> str | None:
    """
    Return canonical action key if the raw 'Action' matches one of our sets; else None.
    """
    if not isinstance(s, str):
        return None
    v = s.strip().casefold()
    for canon, accepted in ACTION_MAP.items():
        if v in accepted:
            return canon
    return None


def _summary_for_action(df_all: pd.DataFrame, action_key: str) -> pd.DataFrame:
    """
    Build per-Div counts for a single action key.
    Output columns: ['Div', 'BTag Orders', 'Non-BTag Orders']
    Counts are DISTINCT 'Order' values (if present), else row counts.
    """
    # Filter to this action
    df = df_all[df_all["Action Type"] == action_key].copy()
    if df.empty:
        return pd.DataFrame(columns=["Div", "BTag Orders", "Non-BTag Orders"])

    # Normalize Div & Order for counting
    df["Div"] = df["Div"].astype(str).str.strip()
    df["Order"] = df["Order"].astype(str).str.strip()
    has_any_order = df["Order"].ne("").any()

    def count_for(flag: str) -> pd.Series:
        sub = df[df["BTag (Y/N)"] == flag]
        if sub.empty:
            return pd.Series(dtype=int)
        if has_any_order:
            grp = sub[sub["Order"] != ""].groupby("Div")["Order"].nunique()
        else:
            grp = sub.groupby("Div").size()
        return grp

    yes_counts = count_for("Yes")
    no_counts  = count_for("No")

    # union of all Divs that appear in either series
    all_divs = sorted(set(yes_counts.index).union(no_counts.index))
    result = pd.DataFrame({
        "Div": all_divs,
        "BTag Orders": [int(yes_counts.get(d, 0)) for d in all_divs],
        "Non-BTag Orders": [int(no_counts.get(d, 0)) for d in all_divs],
    })
    return result


def compute_permit_sanity_tables(file_path: str) -> dict[str, pd.DataFrame]:
    """
    Return a dict: { action_key: DataFrame(['Div','BTag Orders','Non-BTag Orders']) }
    One entry per action in ACTION_MAP (order preserved).
    """
    # Load both sheets
    df_norm = _load_minimal(file_path, SHEET_NORMAL, btag_yes=False)
    # df_btag = _load_minimal(file_path, SHEET_BTAG,   btag_yes=True)

    # Combine & canonicalize actions
    # df = pd.concat([df_norm, df_btag], ignore_index=True)
    df = df_norm
    df["Action Type"] = df["Action"].apply(_canonicalize_action)
    df = df[df["Action Type"].notna()].copy()

    # Build per-action tables
    tables: dict[str, pd.DataFrame] = {}
    for action_key in ACTION_MAP.keys():
        tables[action_key] = _summary_for_action(df, action_key)
    return tables


def build_permit_sanity_ui(parent: tk.Widget, get_file_path) -> dict:
    """
    Build the UI into `parent`:
      - Header "Permit Sanity Check" + Refresh button
      - For EACH action (in ACTION_MAP order):
          Sub-heading = nice display label
          Treeview (Div | BTag Orders | Non-BTag Orders)

    `get_file_path`: callable returning the selected workbook path (str).

    Returns {'frame': frame, 'refresh': refresh_func}
    """
    frame = ttk.Frame(parent)
    frame.grid(row=0, column=0, sticky="nsew")
    frame.columnconfigure(0, weight=1)

    # Top row: header + refresh
    top = ttk.Frame(frame)
    top.grid(row=0, column=0, sticky="we", padx=8, pady=(8, 6))
    ttk.Label(top, text="Permit Sanity Check", font=("Segoe UI", 12, "bold")).pack(side="left")

    sections: list[tuple[str, ttk.Treeview]] = []

    # Create a section (label + table) for each Action
    row_base = 1
    for idx, action_key in enumerate(ACTION_MAP.keys()):
        # Sub-heading
        disp = DISPLAY_LABELS.get(action_key, action_key.title())
        lbl = ttk.Label(frame, text=disp, font=("Segoe UI", 10, "bold"))
        lbl.grid(row=row_base + idx*2, column=0, sticky="w", padx=10, pady=(6, 2))

        # Table
        cols = ("Div", "BTag Orders", "Non-BTag Orders")
        tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse", height=6)
        for c in cols:
            tree.heading(c, text=c)
        tree.column("Div", width=50, anchor="w")
        tree.column("BTag Orders", width=100, anchor="center")
        tree.column("Non-BTag Orders", width=100, anchor="center")

        # vertical scrollbar
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)

        tree.grid(row=row_base + idx*2 + 1, column=0, sticky="nsew", padx=(10, 0), pady=(0, 6))
        vsb.grid(row=row_base + idx*2 + 1, column=1, sticky="ns", pady=(0, 6))

        sections.append((action_key, tree))

    # Let each table row expand a bit
    for i in range(len(sections)):
        frame.rowconfigure(row_base + i*2 + 1, weight=1)

    def do_refresh():
        path = (get_file_path() or "").strip()
        if not path:
            #messagebox.showerror("Missing file", "Please choose a workbook file.")
            return
        if not os.path.exists(path):
            messagebox.showerror("Not found", f"File does not exist:\n{path}")
            return

        try:
            tables = compute_permit_sanity_tables(path)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        # Fill each section's tree with its DataFrame
        for action_key, tree in sections:
            # clear
            for itm in tree.get_children():
                tree.delete(itm)

            df = tables.get(action_key)
            if df is None or df.empty:
                # optional: show a dummy row
                # tree.insert("", "end", values=("-", 0, 0))
                continue

            for _, row in df.iterrows():
                tree.insert("", "end", values=(row["Div"], int(row["BTag Orders"]), int(row["Non-BTag Orders"])))

    # Refresh button on the right
    ttk.Button(top, text="Refresh", command=do_refresh).pack(side="right")

    return {"frame": frame, "refresh": do_refresh}