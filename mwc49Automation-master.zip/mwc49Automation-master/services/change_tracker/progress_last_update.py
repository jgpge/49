# services/change_tracker/progress_last_update.py
from __future__ import annotations
from tkinter import ttk
import tkinter as tk
from datetime import datetime

# Default 8 sheets (shared by Poles & Maintenance)
DEFAULT_SHEETS = [
    "Permit", "BTag Permit",
    "Land", "BTag Land",
    "Joint Pole", "BTag Joint Pole",
    "Enviro", "BTag Enviro",
]

# Consolidated 4 groups for the chart
GROUP_MAP = {
    "Permit":     ["BTag Permit", "Permit"],
    "Joint Pole": ["BTag Joint Pole", "Joint Pole"],
    "Land":       ["BTag Land", "Land"],
    "Enviro":     ["BTag Enviro", "Enviro"],
}

GREY_PREV = "#9aa0a6"
GREEN_DOWN = "#2ca02c"
RED_UP     = "#d62728"
EQUAL_COL  = "#7f7f7f"  # if unchanged


def _parse_loaded_at(s: str):
    try:
        return datetime.strptime(s[:19], "%Y-%m-%d %H:%M:%S")
    except Exception:
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d")
        except Exception:
            return None


def build_progress_from_last_update_ui(
    parent: tk.Widget,
    db=None,
    get_db=None,
    sheets: list[str] | None = None,
) -> dict:
    """
    Composite UI:
      (A) 2-row table: Timestamp | File | <8 sheet counts> (prev, latest)
      (B) Clustered chart: 4 groups (Permit/Joint Pole/Land/Enviro), prev vs latest
          Latest bar is red if higher, green if lower, grey if equal.

    Arguments:
      - db:       an instance that has get_snapshot_summaries(limit=...) -> rows
      - get_db:   optional callable returning the db (used at refresh-time)
      - sheets:   optional list of 8 sheet names; defaults to DEFAULT_SHEETS

    Returns: {"frame": frame, "refresh": refresh, "get_table_data": get_table_data}
    """
    SHEET_WHITELIST = list(sheets or DEFAULT_SHEETS)

    def _get_db():
        return db if db is not None else (get_db() if get_db else None)

    frame = ttk.Frame(parent)
    frame.columnconfigure(0, weight=1)
    frame.rowconfigure(0, weight=0)  # table
    frame.rowconfigure(1, weight=1)  # chart

    # ---- (A) TABLE ----
    cols = ["Timestamp", "File"] + SHEET_WHITELIST
    table_wrap = ttk.Frame(frame)
    table_wrap.grid(row=0, column=0, sticky="ew", padx=4, pady=(0, 8))
    table_wrap.columnconfigure(0, weight=1)

    table = ttk.Treeview(table_wrap, columns=cols, show="headings", height=3, selectmode="browse")
    for c in cols:
        table.heading(c, text=c)
    table.column("Timestamp", width=170, anchor="w")
    table.column("File", width=280, anchor="w")
    for s in SHEET_WHITELIST:
        table.column(s, width=110, anchor="center")
    vsb = ttk.Scrollbar(table_wrap, orient="vertical", command=table.yview)
    table.configure(yscrollcommand=vsb.set)
    table.grid(row=0, column=0, sticky="ew")
    vsb.grid(row=0, column=1, sticky="ns")

    # ---- (B) CHART ----
    chart_wrap = ttk.Frame(frame)
    chart_wrap.grid(row=1, column=0, sticky="nsew")
    chart_wrap.columnconfigure(0, weight=1)
    chart_wrap.rowconfigure(0, weight=1)

    try:
        from matplotlib.figure import Figure
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        import numpy as np
        from matplotlib.patches import Patch
        have_mpl = True
    except Exception:
        have_mpl = False

    if have_mpl:
        fig = Figure(figsize=(7.5, 3.8), constrained_layout=True)
        ax = fig.add_subplot(111)
        canvas = FigureCanvasTkAgg(fig, master=chart_wrap)
        canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        toolbar = NavigationToolbar2Tk(canvas, chart_wrap, pack_toolbar=False)
        toolbar.grid(row=1, column=0, sticky="ew")
        # Hide (x,y) live coords label
        try:
            for child in toolbar.winfo_children():
                if isinstance(child, tk.Label):
                    child.pack_forget()
        except Exception:
            pass
    else:
        msg = ttk.Label(chart_wrap, text="Matplotlib is required for this chart.\nInstall:\n  pip install matplotlib")
        msg.grid(row=0, column=0, sticky="nsew")
        ax = None
        canvas = None
        np = None  # noqa

    # ---- REFRESH ----
    def refresh():
        # clear table
        for i in table.get_children():
            table.delete(i)

        _db = _get_db()
        if _db is None:
            if have_mpl:
                ax.clear()
                ax.text(0.5, 0.5, "No database handle provided.", ha="center", va="center")
                ax.set_axis_off()
                canvas.draw_idle()
            return

        rows = _db.get_snapshot_summaries(limit=200)
        if not rows or len(rows) < 2:
            table.insert("", "end", values=("Not enough data", "—") + tuple("—" for _ in SHEET_WHITELIST))
            if have_mpl:
                ax.clear()
                ax.text(0.5, 0.5, "Need at least two snapshots.\nUse Home → Update Database.", ha="center", va="center")
                ax.set_axis_off()
                canvas.draw_idle()
            return

        # sort oldest → newest using loaded_at
        def key_row(r):
            d = _parse_loaded_at(r["loaded_at"])
            return d or datetime.min

        rows_sorted = sorted(rows, key=key_row)
        prev, latest = rows_sorted[-2], rows_sorted[-1]

        def row_values(r):
            vals = [r["loaded_at"], r["file_name"]]
            vals += [int(r.get(s, 0) or 0) for s in SHEET_WHITELIST]
            return vals

        table.insert("", "end", values=row_values(prev))
        table.insert("", "end", values=row_values(latest))

        if have_mpl:
            # consolidated counts for 4 groups
            def consolidated(r):
                return {grp: sum(int(r.get(s, 0) or 0) for s in sheets) for grp, sheets in GROUP_MAP.items()}

            c_prev   = consolidated(prev)
            c_latest = consolidated(latest)

            ax.clear()
            groups = list(GROUP_MAP.keys())  # fixed order: Permit, Joint Pole, Land, Enviro
            x = np.arange(len(groups))
            width = 0.38

            prev_heights = [c_prev[g] for g in groups]
            latest_heights = [c_latest[g] for g in groups]

            prev_bars = ax.bar(x - width/2, prev_heights, width=width, label="Previous", color=GREY_PREV)

            latest_colors = []
            for g in groups:
                if c_latest[g] > c_prev[g]:
                    latest_colors.append(RED_UP)
                elif c_latest[g] < c_prev[g]:
                    latest_colors.append(GREEN_DOWN)
                else:
                    latest_colors.append(EQUAL_COL)
            latest_bars = ax.bar(x + width/2, latest_heights, width=width, label="Latest", color=latest_colors)

            ax.set_xticks(x)
            ax.set_xticklabels(groups)
            ax.set_ylabel("Open Dependencies")
            ax.set_title("Progress from Last Update")

            ymax = max(prev_heights + latest_heights) if (prev_heights or latest_heights) else 1
            ax.set_ylim(0, max(1, int(ymax * 1.15)))

            legend_patches = [
                Patch(facecolor=GREY_PREV, label="Previous"),
                Patch(facecolor=GREEN_DOWN, label="Latest (↓)"),
                Patch(facecolor=EQUAL_COL,  label="Latest (=)"),
                Patch(facecolor=RED_UP,     label="Latest (↑)"),
            ]
            ax.legend(handles=legend_patches, frameon=False, ncol=2, loc="upper right")

            # Data labels
            def _label_bars(containers):
                try:
                    for cont in containers:
                        ax.bar_label(cont, label_type="edge", padding=3, fmt="%d")
                except Exception:
                    for cont in containers:
                        for rect in cont:
                            h = rect.get_height()
                            ax.annotate(
                                f"{int(h)}",
                                xy=(rect.get_x() + rect.get_width() / 2, h),
                                xytext=(0, 3), textcoords="offset points",
                                ha="center", va="bottom", fontsize=9
                            )
            _label_bars([prev_bars, latest_bars])

            ax.grid(axis="y", linewidth=0.5, alpha=0.5)
            canvas.draw_idle()

    def get_table_data():
        cols = ["Timestamp", "File"] + SHEET_WHITELIST
        data = [list(table.item(iid, "values")) for iid in table.get_children()]
        return cols, data

    # Auto-refresh once so it shows immediately
    frame.after(0, refresh)

    return {"frame": frame, "refresh": refresh, "get_table_data": get_table_data}