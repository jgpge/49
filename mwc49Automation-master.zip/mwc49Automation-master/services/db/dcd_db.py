# services/db/dcd_db.py
from __future__ import annotations

import os
import sqlite3
from typing import Sequence, Tuple, List
import pandas as pd

# ----------------------------- Config -----------------------------
DB_DIR = os.path.join("data")
DB_PATH = os.path.join(DB_DIR, "dcd.db")
TABLE_NAME = "dcd"

# Baseline schema (keep in sync with UI ingest columns)
MINIMAL_DATA_COLS = [
    # metadata
    "timestamp",
    "file_name",

    # current required fields (from DCD sheet)
    "PM",
    "Notification #",
    "Mat Code",
    "Primary Hold-Up",
]


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


class DCDDB:
    """
    Thin wrapper around SQLite for the DCD database.
    - Creates data/dcd.db on first use.
    - Manages a single table: 'dcd' (by default).
    """

    def __init__(self, db_path: str = DB_PATH, table_name: str = TABLE_NAME):
        self.db_path = db_path
        self.table = table_name
        _ensure_dir(self.db_path)

    # ---- Schema / init ----
    def ensure_table(self, all_columns: Sequence[str]) -> None:
        """
        all_columns must be the full, final list of columns you will insert.
        All columns are created as TEXT for robustness.
        Also ensures any newly-added columns get ALTERed into an existing table.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()

            cols_sql = ",\n".join([f'"{c}" TEXT' for c in all_columns])
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS "{self.table}" (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    {cols_sql}
                )
                """
            )

            # Ensure any missing columns are added (safe incremental migration)
            cur.execute(f'PRAGMA table_info("{self.table}")')
            existing = {row[1] for row in cur.fetchall()}
            for c in all_columns:
                if c not in existing:
                    cur.execute(f'ALTER TABLE "{self.table}" ADD COLUMN "{c}" TEXT')

            # Helpful indexes
            if "timestamp" in all_columns:
                cur.execute(f'CREATE INDEX IF NOT EXISTS idx_{self.table}_ts ON "{self.table}" ("timestamp")')
            if "timestamp" in all_columns and "file_name" in all_columns:
                cur.execute(
                    f'CREATE INDEX IF NOT EXISTS idx_{self.table}_ts_file '
                    f'ON "{self.table}" ("timestamp","file_name")'
                )
            if "PM" in all_columns:
                cur.execute(f'CREATE INDEX IF NOT EXISTS idx_{self.table}_pm ON "{self.table}" ("PM")')

            con.commit()

    # ---- Inserts ----
    def insert_dataframe(self, df: pd.DataFrame) -> int:
        """
        Inserts all rows from df, never failing when some columns are missing:
          - Table is ensured to the UNION of MINIMAL_DATA_COLS and df.columns.
          - Missing columns in df are added with NULLs.
          - All NULL-like values (pd.NA/NaN/NaT) are converted to Python None.
          - Datetime-like objects are stringified before insert.
        """
        if df is None or df.empty:
            return 0

        incoming_cols = [str(c) for c in df.columns.tolist()]
        final_cols: List[str] = list(MINIMAL_DATA_COLS) + [c for c in incoming_cols if c not in MINIMAL_DATA_COLS]

        self.ensure_table(final_cols)

        # authoritative table order
        with sqlite3.connect(self.db_path) as con:
            meta = pd.read_sql_query(f'PRAGMA table_info("{self.table}")', con)
            table_cols = meta["name"].astype(str).tolist()

        # df with exactly table cols
        df = df.copy()
        for col in table_cols:
            if col not in df.columns:
                df[col] = pd.NA
        df = df[table_cols]

        df = df.astype("object").where(pd.notna(df), None)

        def _coerce_cell(v):
            if v is None:
                return None
            try:
                import pandas as _pd
                import datetime as _dt
                if isinstance(v, (_pd.Timestamp, _dt.datetime, _dt.date)):
                    return str(v)
            except Exception:
                pass
            return str(v)

        for c in table_cols:
            df[c] = df[c].map(_coerce_cell)

        with sqlite3.connect(self.db_path) as con:
            placeholders = ",".join(["?"] * len(table_cols))
            cols_sql = ",".join([f'"{c}"' for c in table_cols])
            sql = f'INSERT INTO "{self.table}" ({cols_sql}) VALUES ({placeholders})'
            con.executemany(sql, df.itertuples(index=False, name=None))
            con.commit()
            return len(df)

    # ---- Reads / summaries ----
    def distinct_snapshots(self) -> List[Tuple[str, str, int]]:
        """
        Returns list of (timestamp, file_name, count) ordered by timestamp DESC.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f"""
                SELECT "timestamp", "file_name", COUNT(*)
                FROM "{self.table}"
                GROUP BY "timestamp", "file_name"
                ORDER BY "timestamp" DESC
                """
            )
            return cur.fetchall()

    def snapshot_preview(self, timestamp: str, file_name: str) -> List[Tuple[str, str, str, str]]:
        """
        Returns list of (timestamp, PM, Notification #, Mat Code) for a snapshot.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f"""
                SELECT
                    "timestamp",
                    "PM",
                    "Notification #",
                    "Mat Code"
                FROM "{self.table}"
                WHERE "timestamp"=? AND "file_name"=?
                ORDER BY "PM" ASC
                """,
                (timestamp, file_name),
            )
            return cur.fetchall()

    # ---- Deletes ----
    def delete_snapshot(self, timestamp: str, file_name: str) -> int:
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f'DELETE FROM "{self.table}" WHERE "timestamp"=? AND "file_name"=?',
                (timestamp, file_name),
            )
            deleted = cur.rowcount
            con.commit()
            return deleted

    def delete_all(self) -> int:
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(f'DELETE FROM "{self.table}"')
            deleted = cur.rowcount
            con.commit()
            return deleted

    # ---- Hygiene ----
    def normalize_pm_numbers(self) -> int:
        """
        Cleans existing rows where 'PM' looks like '123456.0' and turns them into '123456'.
        Returns number of rows updated. If the table doesn't exist yet, returns 0.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (self.table,))
            if cur.fetchone() is None:
                return 0

            cur.execute(
                f"""
                SELECT rowid, TRIM("PM")
                FROM "{self.table}"
                WHERE TRIM("PM") LIKE '%.0'
                   OR TRIM("PM") LIKE '%.00'
                   OR TRIM("PM") LIKE '%.000'
                """
            )
            rows = cur.fetchall()

            updated = 0
            for rowid, pm in rows:
                if pm is None:
                    continue
                new_pm = self._strip_pm_decimal(pm)
                if new_pm != pm:
                    cur.execute(f'UPDATE "{self.table}" SET "PM" = ? WHERE rowid = ?', (new_pm, rowid))
                    updated += 1

            con.commit()
            return updated

    @staticmethod
    def _strip_pm_decimal(pm: str) -> str:
        s = str(pm).strip()
        if s.endswith(".0"):
            return s[:-2]
        if "." in s:
            try:
                f = float(s)
                if f.is_integer():
                    return str(int(f))
            except Exception:
                pass
        return s
