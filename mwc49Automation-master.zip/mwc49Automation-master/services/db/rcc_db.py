# services/db/rcc_db.py
from __future__ import annotations
import os
import sqlite3
from typing import Sequence, Tuple, List, Optional
import pandas as pd

# ----------------------------- Config -----------------------------
DB_DIR = os.path.join("data")
DB_PATH = os.path.join(DB_DIR, "RCC.db")
TABLE_NAME = "mwc49"  # single table for this module

# Final fixed schema (order matters; keep in sync with UI ingest list)
MINIMAL_DATA_COLS = [
    # metadata
    "timestamp",
    "file_name",

    # keys / basics
    "PM #",
    "Primary Hold-Up",
    "Secondary Hold-Up",
    "Stakeholder",
    "Stage of Job",
    "New Operating Number",
    "CLICK End Date",
    "Resolve Date",
    "Resolve Date2",
    "Current Mat",             # (was Mat Code)
    "Device Type",
    "Division",
    "Construction Resource",
    "Main Work Center",        # NEW
    "SAP Order User Status ",   # NEW
    "CN24 Status",

    # ---- NEW TRACKER FIELDS (requested) ----
    "Work Plan Date",
    "Project Reporting Year",
    "Anticipated Complete Date (VOID)",
    "Completion Deadline Date",
    "Notification #",
    "Notification Status",
    "Region",
    "Program Name",
    "Construction Contact / Div Director",
    "MPP Sub-Category",
    "On linda's list?",

    # survey / DLT / comms
    "IT Survey Request Date",
    "IT Survey WO",
    "IT Survey Site Status (Pass/Fail)",
    "DLT Site Visit Status (NOTN/INPR/COMP)",
    "Comm WO Request Date",
    "Controller Delivered to DLT Date",

    # settings / materials
    "Settings Requested Date",
    "Settings Received Date",
    "Material Requested Date",
    "Material Delivered Date",

    # flags / deps
    "DS83 Completed (Yes)",
    "Open Dependencies",
    "Dependency Estimated Out Date",
    "ESTS Actual Out Date",
    "ESTS Planned Out Date",
    "Field Install Completed (Yes)",

    # SCADA group
    "SCADA Build Request Date",
    "SCADA Build Ready Date",
    "SCADA WO Status",
    "SCADA ADMS Test Date",

    #Acticipated Completion Date
    "Dynamic ACD",

    #New Columns
    "Location #",
    "Latitude",
    "Longitude",
    "Notes and Updates",
    "SCADA Enabled?",
    "SAP Equipment ID"
]

_NOM_COL = "New Operating Number"
_NOM_PLACEHOLDER = "?????"

def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def _clean_nom_series(s: pd.Series) -> pd.Series:
    """
    Normalize New Operating Number values:
      - True NaN/NA -> '?????'
      - Empty string/whitespace -> '?????'
      - 'nan'/'null' (any case) -> '?????'
    Otherwise, keep original string (trimmed).
    """
    if s is None:
        return pd.Series([], dtype="object")

    out = s.astype("string").str.strip()
    mask_empty = out.isna() | (out == "")
    lower = out.str.lower()
    mask_nullish = lower.isna() | lower.isin({"nan", "null"})
    out = out.mask(mask_empty | mask_nullish, _NOM_PLACEHOLDER)
    return out


# -------------------------- DB Utilities --------------------------
class RCCDB:
    """
    Thin wrapper around SQLite for the RCC database.
    - Creates data/RCC.db on first use.
    - Manages a single table: 'mwc49' (by default).
    """

    def __init__(self, db_path: str = DB_PATH, table_name: str = TABLE_NAME):
        self.db_path = db_path
        self.table = table_name
        _ensure_dir(self.db_path)

    # ---- Schema / init ----
    def ensure_table(self, all_columns: Sequence[str]) -> None:
        """
        all_columns must be the full, final list of columns you will insert.
        All columns are created as TEXT for robustness.
        Also ensures any newly-added columns get ALTERed into an existing table.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            # Create table if missing
            cols_sql = ",\n".join([f'"{c}" TEXT' for c in all_columns])
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS "{self.table}" (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    {cols_sql}
                )
                """
            )
            # Ensure any missing columns are added (safe incremental migration)
            cur.execute(f'PRAGMA table_info("{self.table}")')
            existing = {row[1] for row in cur.fetchall()}
            for c in all_columns:
                if c not in existing:
                    cur.execute(f'ALTER TABLE "{self.table}" ADD COLUMN "{c}" TEXT')

            # Helpful indexes
            if "timestamp" in all_columns:
                cur.execute(f'CREATE INDEX IF NOT EXISTS idx_{self.table}_ts ON "{self.table}" ("timestamp")')
            if "timestamp" in all_columns and "file_name" in all_columns:
                cur.execute(
                    f'CREATE INDEX IF NOT EXISTS idx_{self.table}_ts_file '
                    f'ON "{self.table}" ("timestamp","file_name")'
                )
            if "PM #" in all_columns:
                cur.execute(f'CREATE INDEX IF NOT EXISTS idx_{self.table}_pm ON "{self.table}" ("PM #")')
            con.commit()

    def drop_and_recreate(self, all_columns: Sequence[str]) -> None:
        """
        Hard reset: drops the table (if exists) and recreates with current schema.
        Use this when changing columns wholesale.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(f'DROP TABLE IF EXISTS "{self.table}"')
            con.commit()
        self.ensure_table(all_columns)

    # ---- Inserts ----
    def insert_dataframe(self, df: pd.DataFrame) -> int:
        """
        Inserts all rows from df, never failing when some columns are missing:
          - Table is ensured to the UNION of MINIMAL_DATA_COLS and df.columns.
          - Missing columns in df are added with NULLs.
          - All NULL-like values (pd.NA/NaN/NaT) are converted to Python None
            so sqlite3 can bind them.
          - Datetime-like objects are stringified before insert.

        RETURNS number of inserted rows.
        """
        if df.empty:
            return 0

        # Build final schema as UNION (preserve baseline order, then append any new columns from df)
        incoming_cols = [str(c) for c in df.columns.tolist()]
        final_cols: List[str] = list(MINIMAL_DATA_COLS) + [c for c in incoming_cols if c not in MINIMAL_DATA_COLS]
        print(final_cols)

        # Ensure table exists and includes all columns
        self.ensure_table(final_cols)

        # Re-read actual table column order from SQLite to be authoritative
        with sqlite3.connect(self.db_path) as con:
            meta = pd.read_sql_query(f'PRAGMA table_info("{self.table}")', con)
            table_cols = meta["name"].astype(str).tolist()

        # Prepare df with EXACTLY table_cols (add missing; drop extras)
        df = df.copy()
        for col in table_cols:
            if col not in df.columns:
                df[col] = pd.NA

        # Normalize NOM before coercions 
        if _NOM_COL in df.columns:
            df[_NOM_COL] = _clean_nom_series(df[_NOM_COL])

        # 1) Keep only table columns in correct order
        df = df[table_cols]

        # 2) Convert pandas NA/NaN/NaT -> None so sqlite can bind
        df = df.astype("object").where(pd.notna(df), None)

        # 3) Coerce datetimes to strings; leave other scalars as-is (columns are TEXT)
        def _coerce_cell(v):
            if v is None:
                return None
            try:
                import pandas as _pd
                import datetime as _dt
                if isinstance(v, (_pd.Timestamp, _dt.datetime, _dt.date)):
                    return str(v)
            except Exception:
                pass
            return str(v)
        for c in table_cols:
            df[c] = df[c].map(_coerce_cell)

        # Insert
        with sqlite3.connect(self.db_path) as con:
            placeholders = ",".join(["?"] * len(table_cols))
            cols_sql = ",".join([f'"{c}"' for c in table_cols])
            sql = f'INSERT INTO "{self.table}" ({cols_sql}) VALUES ({placeholders})'
            con.executemany(sql, df.itertuples(index=False, name=None))
            con.commit()
            return len(df)

    # ---- Post-ingest fixer ----
    def backfill_nom_placeholders(self) -> int:
        """
        Updates existing rows so any NULL/empty/'nan'/'null' New Operating Number becomes '?????'.
        Returns number of rows updated.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()

            cur.execute(
                f'''
                UPDATE "{self.table}"
                   SET "{_NOM_COL}" = ?
                 WHERE "{_NOM_COL}" IS NULL
                    OR TRIM(COALESCE("{_NOM_COL}", "")) = ""
                ''',
                (_NOM_PLACEHOLDER,),
            )
            updated1 = cur.rowcount if cur.rowcount is not None else 0

            cur.execute(
                f'''
                UPDATE "{self.table}"
                   SET "{_NOM_COL}" = ?
                 WHERE LOWER(TRIM("{_NOM_COL}")) IN ('nan','null')
                ''',
                (_NOM_PLACEHOLDER,),
            )
            updated2 = cur.rowcount if cur.rowcount is not None else 0

            con.commit()
            return (updated1 or 0) + (updated2 or 0)

    # ---- Reads / summaries ----
    def distinct_snapshots(self) -> List[Tuple[str, str, int]]:
        """
        Returns list of (timestamp, file_name, count) ordered by timestamp DESC.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f"""
                SELECT "timestamp", "file_name", COUNT(*)
                FROM "{self.table}"
                GROUP BY "timestamp", "file_name"
                ORDER BY "timestamp" DESC
                """
            )
            return cur.fetchall()

    def snapshot_pm_preview(self, timestamp: str, file_name: str) -> List[Tuple[str, str, str]]:
        """
        Returns list of (timestamp, PM #, New Operating Number) for a snapshot.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f"""
                SELECT "timestamp", "PM #", "New Operating Number"
                FROM "{self.table}"
                WHERE "timestamp"=? AND "file_name"=?
                ORDER BY "PM #" ASC
                """,
                (timestamp, file_name),
            )
            return cur.fetchall()

    def fetch_click_series(self, ts_from: str, ts_to: str) -> pd.DataFrame:
        """
        Return rows between [ts_from, ts_to] (inclusive) for the click-focused reports.
        """
        with sqlite3.connect(self.db_path) as con:
            q = f"""
                SELECT
                    "timestamp",
                    "PM #",
                    "New Operating Number",
                    "CLICK End Date",
                    "Stage of Job",
                    "Resolve Date",
                    "Resolve Date2",
                    "Primary Hold-Up",
                    "Secondary Hold-Up",
                    "Current Mat",
                    "Device Type",
                    "Division",
                    "Construction Resource",
                    "Main Work Center",
                    "SAP Order User Status ",
                    "CN24 Status",

                    -- New tracker fields
                    "Work Plan Date",
                    "Project Reporting Year",
                    "Anticipated Complete Date (VOID)",
                    "Completion Deadline Date",
                    "Notification #",
                    "Notification Status",
                    "Region",
                    "Program Name",
                    "Construction Contact / Div Director",
                    "MPP Sub-Category",
                    "On linda's list?",

                    -- surveys / DLT / comms
                    "IT Survey Request Date",
                    "IT Survey WO",
                    "IT Survey Site Status (Pass/Fail)",
                    "DLT Site Visit Status (NOTN/INPR/COMP)",
                    "Comm WO Request Date",
                    "Controller Delivered to DLT Date",

                    -- settings / materials
                    "Settings Requested Date",
                    "Settings Received Date",
                    "Material Requested Date",
                    "Material Delivered Date",

                    -- flags / deps
                    "DS83 Completed (Yes)",
                    "Open Dependencies",
                    "Dependency Estimated Out Date",
                    "ESTS Actual Out Date",
                    "ESTS Planned Out Date",
                    "Field Install Completed (Yes)",

                    -- SCADA
                    "SCADA Build Request Date",
                    "SCADA Build Ready Date",
                    "SCADA WO Status",
                    "SCADA ADMS Test Date",

                    --Dynamic ACD
                    "Dynamic ACD"
                FROM "{self.table}"
                WHERE "timestamp" BETWEEN ? AND ?
                  AND "PM #" IS NOT NULL AND TRIM("PM #") <> ''
                ORDER BY "PM #", "timestamp" ASC
            """
            df = pd.read_sql_query(q, con, params=(ts_from, ts_to))
        return df

    def fetch_primary_holdup_series(self, ts_from: str, ts_to: str) -> pd.DataFrame:
        """
        For stakeholder reports.
        """
        with sqlite3.connect(self.db_path) as con:
            q = f"""
                SELECT
                    "timestamp",
                    "PM #",
                    "New Operating Number",
                    "Primary Hold-Up",
                    "Secondary Hold-Up",
                    "Resolve Date",
                    "Resolve Date2",
                    "Current Mat",
                    "Device Type",
                    "Division",
                    "Construction Resource",
                    "Main Work Center",
                    "SAP Order User Status ",
                    "CN24 Status",

                    -- New tracker fields
                    "Work Plan Date",
                    "Project Reporting Year",
                    "Anticipated Complete Date (VOID)",
                    "Completion Deadline Date",
                    "Notification #",
                    "Notification Status",
                    "Region",
                    "Program Name",
                    "Construction Contact / Div Director",
                    "MPP Sub-Category",
                    "On linda's list?",

                    -- surveys / DLT / comms
                    "IT Survey Request Date",
                    "IT Survey WO",
                    "IT Survey Site Status (Pass/Fail)",
                    "DLT Site Visit Status (NOTN/INPR/COMP)",
                    "Comm WO Request Date",
                    "Controller Delivered to DLT Date",

                    -- settings / materials
                    "Settings Requested Date",
                    "Settings Received Date",
                    "Material Requested Date",
                    "Material Delivered Date",

                    -- flags / deps
                    "DS83 Completed (Yes)",
                    "Open Dependencies",
                    "Dependency Estimated Out Date",
                    "ESTS Actual Out Date",
                    "ESTS Planned Out Date",
                    "Field Install Completed (Yes)",

                    -- SCADA
                    "SCADA Build Request Date",
                    "SCADA Build Ready Date",
                    "SCADA WO Status",
                    "SCADA ADMS Test Date"
                FROM "{self.table}"
                WHERE "timestamp" BETWEEN ? AND ?
                  AND "PM #" IS NOT NULL AND TRIM("PM #") <> ''
                ORDER BY "PM #", "timestamp" ASC
            """
            df = pd.read_sql_query(q, con, params=(ts_from, ts_to))
        return df

    def fetch_accurate_series(self, ts_from: str, ts_to: str) -> pd.DataFrame:
        """
        Robust fetch for the 'Accurate' stakeholder lifecycle report.
        - Builds SELECT list from desired columns that actually exist in table.
        - Adds 'timestamp_dt' column.
        """
        tbl = self.table
        desired_cols = [
            "timestamp",
            "PM #",
            "New Operating Number",
            "Current Mat",
            "Construction Resource",
            "Division",
            "Device Type",
            "Stage of Job",
            "Primary Hold-Up",
            "Secondary Hold-Up",
            "Resolve Date",
            "Resolve Date2",
            "CN24 Status",

            # New tracker fields
            "Work Plan Date",
            "Project Reporting Year",
            "Anticipated Complete Date (VOID)",
            "Completion Deadline Date",
            "Notification #",
            "Notification Status",
            "Region",
            "Program Name",
            "Construction Contact / Div Director",
            "MPP Sub-Category",
            "On linda's list?",

            "IT Survey Request Date",
            "IT Survey WO",
            "IT Survey Site Status (Pass/Fail)",
            "Field Install Completed (Yes)",
            "SCADA Build Request Date",
            "SCADA Build Ready Date",
            "SCADA WO Status",
            "SCADA ADMS Test Date",
            "Open Dependencies",
            "Dependency Estimated Out Date",
            "ESTS Actual Out Date",
            "ESTS Planned Out Date",
            "DS83 Completed (Yes)",
            "Material Delivered Date",
            "Material Requested Date",
            "Settings Requested Date",
            "Settings Received Date",
            "Controller Delivered to DLT Date",
            "Comm WO Request Date",
            "DLT Site Visit Status (NOTN/INPR/COMP)",
            "Main Work Center",
            "SAP Order User Status",
        ]

        con = sqlite3.connect(self.db_path)
        try:
            meta = pd.read_sql_query(f'PRAGMA table_info("{tbl}")', con)
            existing_cols = set(meta["name"].astype(str))
            select_cols = [c for c in desired_cols if c in existing_cols]
            if not select_cols:
                return pd.DataFrame()

            select_list = ", ".join(f'"{c}"' for c in select_cols)
            q = f'''
                SELECT {select_list}
                FROM "{tbl}"
                WHERE "timestamp" BETWEEN ?
                  AND ?
                  AND "PM #" IS NOT NULL
                  AND TRIM("PM #") <> ''
                ORDER BY "PM #", "timestamp" ASC
            '''
            df = pd.read_sql_query(q, con, params=(ts_from, ts_to))
        finally:
            con.close()

        if "timestamp" in df.columns:
            df["timestamp_dt"] = pd.to_datetime(df["timestamp"], errors="coerce")
        return df

    # ---- Deletes ----
    def delete_snapshot(self, timestamp: str, file_name: str) -> int:
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(
                f'DELETE FROM "{self.table}" WHERE "timestamp"=? AND "file_name"=?',
                (timestamp, file_name),
            )
            deleted = cur.rowcount
            con.commit()
            return deleted

    def delete_all(self) -> int:
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute(f'DELETE FROM "{self.table}"')
            deleted = cur.rowcount
            con.commit()
            return deleted

    # ---- Hygiene ----
    def normalize_pm_numbers(self) -> int:
        """
        Cleans existing rows where 'PM #' looks like '123456.0' and turns them into '123456'.
        Returns number of rows updated. If the table doesn't exist yet, returns 0.
        """
        with sqlite3.connect(self.db_path) as con:
            cur = con.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (self.table,))
            if cur.fetchone() is None:
                return 0

            cur.execute("""
                SELECT rowid, TRIM("PM #")
                FROM "mwc49"
                WHERE TRIM("PM #") LIKE '%.0'
                OR TRIM("PM #") LIKE '%.00'
                OR TRIM("PM #") LIKE '%.000'
            """)
            rows = cur.fetchall()

            updated = 0
            for rowid, pm in rows:
                if pm is None:
                    continue
                new_pm = self._strip_pm_decimal(pm)
                if new_pm != pm:
                    cur.execute('UPDATE "mwc49" SET "PM #" = ? WHERE rowid = ?', (new_pm, rowid))
                    updated += 1

            con.commit()
            return updated

    @staticmethod
    def _strip_pm_decimal(pm: str) -> str:
        s = str(pm).strip()
        if s.endswith(".0"):
            return s[:-2]
        if "." in s:
            try:
                f = float(s)
                if f.is_integer():
                    return str(int(f))
            except Exception:
                pass
        return s
