# services/db/mwc49.py
from __future__ import annotations

import os
import sqlite3
from typing import Callable, Optional, List

import pandas as pd
from openpyxl import load_workbook

DB_FILENAME = "mwc49.db"

# -------------------------
# MPP
# -------------------------
MPP_TABLE = "mpp_data"

MAT_ALLOWED = {"3UP", "49B", "49C", "49D", "49E", "49S", "49X"}

MPP_USECOLS: List[str] = [
    "Order",
    "MAT",
    "Work Plan Date",
    "Program",
    "Primary Status",
    "Order User Status",
    "Div",
    "Region",
    "County",
    "City",
    "Latitude",
    "Longitude",
    "IN03 Out",
    "Est Out Date",
    "PEND In",
    "DS18 Out",
    "PC25 Out",
    "CLICK Start Date",
    "CLICK End Date",
    "CN24",
    "CN24 Out",
    "CLICK Resource",
    "CN83",
    "CN83 Out",
    "Authorized Funding Action (2026)",
    "Project Reporting Year",
    "Sub-Category",
    "Project Managed Flag",
    "Order Desc",
    "Notification",
    "Notif Status",
    "HFTD",
    "Completion Deadline Date",
    "Job Owner",
    "1 thru N Rank",
    "Main Work Center",
]

# -------------------------
# PSPS SCADA TCom
# -------------------------
PSPS_SHEET = "query"
PSPS_TABLE = "psps_scada_tcom_data"

PSPS_USECOLS: List[str] = [
    "PM #",
    "SAP ID #",
    "Comm Survey Ord #",
    "Survey Pass / Fail / Xtnder",
    "Comm Radio Type",
    "MAS / LES",
    "IP Address",
    "RSSI",
    "Remarks",
    "Survey Comp Date",
    "Comm Install Ord #",
]


def _repo_root() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def data_dir() -> str:
    return os.path.join(_repo_root(), "data")


def default_db_path() -> str:
    return os.path.join(data_dir(), DB_FILENAME)


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or default_db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)

    # Speed-focused pragmas
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA temp_store=MEMORY;")
    conn.execute("PRAGMA cache_size=-200000;")  # ~200MB cache

    return conn


# -------------------------
# MPP helpers
# -------------------------
def _create_mpp_table(conn: sqlite3.Connection) -> None:
    cols_sql = ['"Order" INTEGER']
    for c in MPP_USECOLS:
        if c == "Order":
            continue
        cols_sql.append(f'"{c}" TEXT')

    conn.execute(f'DROP TABLE IF EXISTS "{MPP_TABLE}";')
    conn.execute(f'CREATE TABLE "{MPP_TABLE}" ({", ".join(cols_sql)});')
    conn.execute(f'CREATE INDEX IF NOT EXISTS idx_{MPP_TABLE}_mat ON "{MPP_TABLE}"("MAT");')
    conn.execute(f'CREATE INDEX IF NOT EXISTS idx_{MPP_TABLE}_order ON "{MPP_TABLE}"("Order");')


def replace_mpp_data_from_csv(
    csv_path: str,
    *,
    db_path: Optional[str] = None,
    chunksize: int = 100_000,
    on_progress: Optional[Callable[[int], None]] = None,
) -> int:
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    total_inserted = 0

    with connect(db_path) as conn:
        _create_mpp_table(conn)

        insert_cols = MPP_USECOLS[:]
        placeholders = ",".join(["?"] * len(insert_cols))
        col_list_sql = ",".join([f'"{c}"' for c in insert_cols])
        insert_sql = f'INSERT INTO "{MPP_TABLE}" ({col_list_sql}) VALUES ({placeholders});'

        reader = pd.read_csv(
            csv_path,
            usecols=MPP_USECOLS,
            dtype=str,
            chunksize=chunksize,
            low_memory=False,
            encoding_errors="ignore",
        )

        cur = conn.cursor()
        cur.execute("BEGIN;")

        try:
            for chunk in reader:
                if chunk.empty:
                    continue

                mat = chunk["MAT"].astype(str).str.strip().str.upper()
                chunk = chunk[mat.isin(MAT_ALLOWED)]
                if chunk.empty:
                    continue

                chunk.loc[:, "MAT"] = chunk["MAT"].astype(str).str.strip().str.upper()

                order_num = pd.to_numeric(chunk["Order"], errors="coerce")
                chunk.loc[:, "Order"] = order_num

                chunk = chunk.where(pd.notnull(chunk), None)

                rows = list(chunk[insert_cols].itertuples(index=False, name=None))
                cur.executemany(insert_sql, rows)

                total_inserted += len(rows)
                if on_progress:
                    on_progress(total_inserted)

            conn.commit()
        except Exception:
            conn.rollback()
            raise

    return total_inserted


# -------------------------
# PSPS helpers
# -------------------------
def _create_psps_table(conn: sqlite3.Connection) -> None:
    # all text columns; these IDs can contain non-numeric / formatting
    cols_sql = [f'"{c}" TEXT' for c in PSPS_USECOLS]

    conn.execute(f'DROP TABLE IF EXISTS "{PSPS_TABLE}";')
    conn.execute(f'CREATE TABLE "{PSPS_TABLE}" ({", ".join(cols_sql)});')

    # optional indexes (useful for later joins/search)
    if "SAP ID #" in PSPS_USECOLS:
        conn.execute(f'CREATE INDEX IF NOT EXISTS idx_{PSPS_TABLE}_sap ON "{PSPS_TABLE}"("SAP ID #");')
    if "PM #" in PSPS_USECOLS:
        conn.execute(f'CREATE INDEX IF NOT EXISTS idx_{PSPS_TABLE}_pm ON "{PSPS_TABLE}"("PM #");')


def replace_psps_scada_tcom_from_excel(
    xlsx_path: str,
    *,
    db_path: Optional[str] = None,
    on_progress: Optional[Callable[[int], None]] = None,  # rows inserted so far
) -> int:
    """
    Reads only PSPS_USECOLS from sheet PSPS_SHEET and rewrites PSPS_TABLE.
    Uses openpyxl read-only streaming for speed.
    """
    if not os.path.isfile(xlsx_path):
        raise FileNotFoundError(f"Excel file not found: {xlsx_path}")

    total_inserted = 0

    with connect(db_path) as conn:
        _create_psps_table(conn)

        insert_cols = PSPS_USECOLS[:]
        placeholders = ",".join(["?"] * len(insert_cols))
        col_list_sql = ",".join([f'"{c}"' for c in insert_cols])
        insert_sql = f'INSERT INTO "{PSPS_TABLE}" ({col_list_sql}) VALUES ({placeholders});'

        cur = conn.cursor()
        cur.execute("BEGIN;")

        try:
            wb = load_workbook(xlsx_path, read_only=True, data_only=True)
            if PSPS_SHEET not in wb.sheetnames:
                raise ValueError(f'Sheet "{PSPS_SHEET}" not found in workbook.')

            ws = wb[PSPS_SHEET]

            # Read header row (first non-empty row)
            header = None
            header_row_idx = None
            for i, row in enumerate(ws.iter_rows(values_only=True), start=1):
                if row and any(v is not None and str(v).strip() != "" for v in row):
                    header = [str(v).strip() if v is not None else "" for v in row]
                    header_row_idx = i
                    break

            if header is None:
                raise ValueError(f'Sheet "{PSPS_SHEET}" appears empty.')

            # Map required columns to indexes
            col_to_idx = {name: idx for idx, name in enumerate(header)}
            missing = [c for c in PSPS_USECOLS if c not in col_to_idx]
            if missing:
                raise ValueError(f"Missing required columns in sheet header: {missing}")

            wanted_idxs = [col_to_idx[c] for c in PSPS_USECOLS]

            # Stream rows after header
            batch: list[tuple] = []
            BATCH_SIZE = 5000

            for row in ws.iter_rows(min_row=(header_row_idx + 1), values_only=True):
                if row is None:
                    continue
                # Pull only needed columns
                out = []
                for idx in wanted_idxs:
                    v = row[idx] if idx < len(row) else None
                    # normalize to strings (keep None)
                    if v is None:
                        out.append(None)
                    else:
                        out.append(str(v).strip())
                # If entire extracted row is empty, skip
                if all(v is None or v == "" for v in out):
                    continue

                batch.append(tuple(out))

                if len(batch) >= BATCH_SIZE:
                    cur.executemany(insert_sql, batch)
                    total_inserted += len(batch)
                    batch.clear()
                    if on_progress:
                        on_progress(total_inserted)

            if batch:
                cur.executemany(insert_sql, batch)
                total_inserted += len(batch)
                if on_progress:
                    on_progress(total_inserted)

            conn.commit()
        except Exception:
            conn.rollback()
            raise

    return total_inserted
