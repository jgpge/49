import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import df_to_excelish_html
from ledgers.emailLedgers.poles.emailLedger import permitCombinedRequestForExtensionAndSubmittedOver_el
from ledgers.emailLedgers.poles.columnLedger import permitColumns
from services.db.poles_db import PolesDB
from datetime import datetime

COLUMNS = permitColumns
RECIPIENTS_MAP = permitCombinedRequestForExtensionAndSubmittedOver_el

def combinedRequestForExtensionAndSubmittedOver(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")
    df_btag = load_sheet(file_path, "BTag Permit")

    # 2) Stamp B-Tag and Non-BTag
    df_norm["BTag"] = "No"     
    df_btag["BTag"] = "Yes"    

    # 3) append into one table
    df_all = pd.concat([df_btag, df_norm], ignore_index=True)
    print(df_all)

    # 4) keep only Action 
    action_norm = df_all["Action"].astype(str).str.strip().str.casefold()
    df_final_request_for_extension = df_all[action_norm == "request for extension"].copy()
    df_final_submitted_over_thirty_days = df_all[action_norm == "submitted over 30 days. provide update"].copy()

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final_request_for_extension.columns:
            df_final_request_for_extension[col] = pd.to_datetime(df_final_request_for_extension[col], errors="coerce").dt.strftime("%m/%d/%Y")
        if col in df_final_submitted_over_thirty_days.columns:
            df_final_submitted_over_thirty_days[col] = pd.to_datetime(df_final_submitted_over_thirty_days[col], errors="coerce").dt.strftime("%m/%d/%Y")

    df_final = pd.concat([df_final_request_for_extension, df_final_submitted_over_thirty_days], ignore_index=True)

    #log this to the communicator
    db = PolesDB()
    db.add_communications_from_df(df=df_final, dependency_type="Permit", date=datetime.now(), communication_log="Email Sent: Request for Extension and Submitted Over 30 Days", allow_duplicates=True)

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    # 4) open ONE Outlook draft with the full table
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError("pywin32 is required for Outlook automation. Install: pip install pywin32") from e

    html_table = df_to_excelish_html(df_final, COLUMNS)
    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem
    mail.Subject = f"Permit Status Update"
    mail.HTMLBody = "<p>Hi Brett,<br><br>The order(s) below have been submitted for over 45 days and still not issued. Please review and provide updates on them.<br><br>" + html_table + "Thank You"
    mail.To = RECIPIENTS_MAP["to"]
    mail.CC = RECIPIENTS_MAP["cc"]
    mail.Display(True)