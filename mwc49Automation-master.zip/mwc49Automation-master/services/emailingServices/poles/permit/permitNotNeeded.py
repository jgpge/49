import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import open_outlook_drafts_by_div
from ledgers.emailLedgers.poles.emailLedger import permitNotNeeded_el
from ledgers.emailLedgers.poles.columnLedger import permitColumns
from services.db.poles_db import PolesDB
from datetime import datetime

COLUMNS = permitColumns
removeColumns = ["Permit Application Date", "Permit Expiration Date"]
COLUMNS = [x for x in COLUMNS if x not in removeColumns]
RECIPIENTS_MAP = permitNotNeeded_el

def notNeeded_poles(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")
    df_btag = load_sheet(file_path, "BTag Permit")

    # 2) Stamp B-Tag and Non-BTag
    df_norm["BTag"] = "No"     
    df_btag["BTag"] = "Yes"    

    # 3) append into one table
    df_all = pd.concat([df_btag, df_norm], ignore_index=True)

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    action_norm = df_all["Action"].astype(str).str.strip().str.casefold()
    df_final = df_all[action_norm == "permit not needed. close sp/rp56"].copy()

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")

    #log this to the communicator
    db = PolesDB()
    db.add_communications_from_df(df=df_final, dependency_type="Permit", date=datetime.now(), communication_log="Email Sent: Permit Not Needed", allow_duplicates=True)

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    if df_final.empty:
        print("No rows match permit not needed. close sp/rp56")
        return

    # 4) open Outlook draft for each Div separtely
    subject = "Permit Not Needed - Complete Task"
    body = "Hi,<br><br>E permit status indicates that permit is not Needed for the order(s) below. Please review, confirm and complete SAP task. Also let us know if anything else is pending before tasks can be completed.<br><br>"
    open_outlook_drafts_by_div(df_final,COLUMNS,RECIPIENTS_MAP, subject, body)
