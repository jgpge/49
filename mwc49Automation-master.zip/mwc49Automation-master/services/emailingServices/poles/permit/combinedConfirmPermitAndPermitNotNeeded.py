import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import open_outlook_drafts_by_div
from helpers.emailHelpers.email import df_to_excelish_html
from ledgers.emailLedgers.poles.emailLedger import permitCombinedConfirmPermitAndPermitNotNeeded_el
from ledgers.emailLedgers.poles.columnLedger import permitColumns
from services.db.poles_db import PolesDB
from datetime import datetime

COLUMNS = permitColumns
RECIPIENTS_MAP = permitCombinedConfirmPermitAndPermitNotNeeded_el

def combinedConfirmPermitAndPermitNotNeeded(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")
    df_btag = load_sheet(file_path, "BTag Permit")

    # 2) Stamp B-Tag and Non-BTag
    df_norm["BTag"] = "No"     
    df_btag["BTag"] = "Yes"    

    # 3) append into one table
    df_all = pd.concat([df_btag, df_norm], ignore_index=True)
    print(df_all)

    # 4) keep only Action 
    action_norm = df_all["Action"].astype(str).str.strip().str.casefold()
    df_final_confirm_permit_is_approved = df_all[action_norm == "confirm permit is approved and complete sap task"].copy()
    df_final_permit_not_needed = df_all[action_norm == "permit not needed. close sp/rp56"].copy()

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final_confirm_permit_is_approved.columns:
            df_final_confirm_permit_is_approved[col] = pd.to_datetime(df_final_confirm_permit_is_approved[col], errors="coerce").dt.strftime("%m/%d/%Y")
        if col in df_final_permit_not_needed.columns:
            df_final_permit_not_needed[col] = pd.to_datetime(df_final_permit_not_needed[col], errors="coerce").dt.strftime("%m/%d/%Y")

    df_final = pd.concat([df_final_confirm_permit_is_approved, df_final_permit_not_needed], ignore_index=True)

    #log this to the communicator
    db = PolesDB()
    db.add_communications_from_df(df=df_final, dependency_type="Permit", date=datetime.now(), communication_log="Email Sent: Confirm Permit is Approved. Complete Task in SAP and Permit Not Needed", allow_duplicates=True)

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

        # 4) open ONE Outlook draft with the full table
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError("pywin32 is required for Outlook automation. Install: pip install pywin32") from e

    html_table = df_to_excelish_html(df_final, COLUMNS)
    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem
    mail.Subject = f"Permit Task Pending Completion"
    mail.HTMLBody = "<p>Hi Brett,<br><br>The order(s) below have been flagged as permit is not needed or permit approved but the SP56/RP56 tasks are still open. Please review and complete the tasks. Also, let us know if anything else is pending for these order(s).<br><br>" + html_table + "Thank You"
    mail.To = RECIPIENTS_MAP["to"]
    mail.CC = RECIPIENTS_MAP["cc"]
    mail.Display(True)