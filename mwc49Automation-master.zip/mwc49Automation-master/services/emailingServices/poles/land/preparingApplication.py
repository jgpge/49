import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.misc.comment_filtering import extract_top_comment_triplets
from helpers.emailHelpers.email import open_outlook_drafts_by_lan_id
from services.db.poles_db import PolesDB
from datetime import datetime

def preparingApplication_poles(file_path: str):
    #1) Load the sheets and align the columns
    df_norm = load_sheet(file_path, "Land")
    df_btag = load_sheet(file_path, "BTag Land")

    # 2) Stamp B-Tag and Non-BTag
    df_norm["BTag"] = "No"     
    df_btag["BTag"] = "Yes"

    # 3) append into one table
    df_all = pd.concat([df_btag, df_norm], ignore_index=True)

    #4) filter only for preparing application in the "Permit Status" column
    prep_mask = df_all["Permit Status"] == "Preparing Application"
    df_all = df_all.loc[prep_mask]

    #4) Filter the anticipated dates for in the past, or not entered
    dt = pd.to_datetime(df_all["Anticipated Application Date"], errors="coerce")  # blanks/invalid -> NaT
    today = pd.Timestamp.today().normalize()

    mask = dt.isna() | (dt.dt.normalize() < today)  # empty OR strictly in the past
    df_all = df_all.loc[mask]

    #5)extract out the data that we need from the comments
    df_comments_extracted = extract_top_comment_triplets(df_all=df_all)
    print("Total Extracted Rows: ", len(df_comments_extracted))

    #6) Filter for the last comment date to later than 14 days from today (for the ones that have anticipate dates) and for later than 14 days for the ones that don't have anticipated date
    df_comments_filtered = filter_for_followup(df_comments_extracted)
    print(df_comments_filtered)

    #log this to the communicator
    db = PolesDB()
    db.add_communications_from_df(df_comments_filtered, dependency_type="Land", date=datetime.now(), communication_log="Email Sent: Preparing Application", allow_duplicates=True)
    
    #7)Create Emails
    subject = "Please Provide Update"
    body = "Hi,<br><br>Can you please review the action column and provide update(s) on the following order(s).<br><br>"
    open_outlook_drafts_by_lan_id(df_comments_filtered, subject, body)


#filter out latest comment date and the anticipated permit date
def filter_for_followup(out: pd.DataFrame) -> pd.DataFrame:
    # Parse dates (robust to blanks/strings)
    latest = pd.to_datetime(out["Latest Comment Date"], errors="coerce").dt.normalize()
    anticipated = pd.to_datetime(out["Anticipated Application Date"], errors="coerce").dt.normalize()

    today = pd.Timestamp.today().normalize()

    # Rule 1: Anticipated date present  -> keep if latest comment is ≥14 days old
    rule1 = anticipated.notna() & (latest <= today - pd.Timedelta(days=14))

    # Rule 2: Anticipated date missing -> keep if latest comment is ≥30 days old
    rule2 = anticipated.isna() & (latest <= today - pd.Timedelta(days=14))

    keep_mask = rule1 | rule2

    # Optional: label which rule matched (handy for reviewing)
    out_filtered = out.loc[keep_mask].copy()
    out_filtered["Filter Rule"] = pd.NA
    out_filtered.loc[rule1 & keep_mask, "Filter Rule"] = "Has Anticipated Date; 14+ days since latest comment"
    out_filtered.loc[rule2 & keep_mask, "Filter Rule"] = "No Anticipated Date; 30+ days since latest comment"

    return out_filtered

    
    