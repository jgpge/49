import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.misc.comment_filtering import extract_top_comment_triplets
from helpers.emailHelpers.email import open_outlook_drafts_by_lan_id
from typing import Iterable, List, Sequence, Tuple
from services.db.poles_db import PolesDB
from datetime import datetime

CATEGORY_ACTION_MAP = [
    ["Land | Provide update on the MPS", "Provide update on the Monument Preservation Survey"],
    ["Land | Confirm permit is obtained and complete SP/RP57", "Confirm permit is obtained and complete SP/RP57"],
    ["Land | Confirm if redesign is completed by estimation", "Confirm if redesign is completed by estimation"],
    ["Land | Confirm if draft permit can be used and complete SP/RP57", "Confirm if Draft Permit can be used and complete SP/RP57"],
    ["Land | Confirm if estimation provided the needed information...", "Confirm if estimation provided the needed information. Also, when do we expect permit application to be completed?"],
    ["Land | Confirm permit is not needed and complete SP/RP57", "Confirm permit is not needed and complete SP57 and or RP57"],
    ["Land | What is the status of the site specific permit...", "What is the status of the Site Specific permit and what is the anticipated issue date?"],
    ["Land | Confirm if DM17 is created...", "Confirm if DM17 is created. Also, when will permit application begin"],
    ["Land | Confirm if new application is in process...", "Permit issue date in the past, Please provide an update on permit EOD"],
    ["Land | Permit issue date in the past...", "Permit issue date in the past, Please provide an update on permit EOD"]
]

def combinedLandEmailer(file_path: str, categories: list):
    #1) Load the sheets and align the columns
    df_norm = load_sheet(file_path, "Land")
    df_btag = load_sheet(file_path, "BTag Land")

    # 2) Stamp B-Tag and Non-BTag
    df_norm["BTag"] = "No"     
    df_btag["BTag"] = "Yes"

    # 3) append into one table
    df_all = pd.concat([df_btag, df_norm], ignore_index=True)

    #4)now that we have the total land sheet, we need to figure out which actions do we have to send out the emails for
    actions_for_emails = actions_to_send_out_emails_for(categories, CATEGORY_ACTION_MAP)

    #5)filter out the df_all for these actions only
    action_norm = df_all["Action"].astype(str).str.strip().str.casefold()
    df_action_filtered = df_all[action_norm.isin([s.lower() for s in actions_for_emails])].copy()

    #6) extract out the data we need from the comments
    df_action_comments_extracted = extract_top_comment_triplets(df_action_filtered) #<----- list based on actions

    df_preparing_application_comments_extracted = pd.DataFrame()
    #7) check to see if preparing applications is in the cateogires that we have
    if "Land | Preparing Application" in categories:
        #1) filter only for preparing application in the "Permit Status" column
        prep_mask = df_all["Permit Status"] == "Preparing Application"
        df_all_permit_status_filtered = df_all.loc[prep_mask]

        #2) Filter the anticipated dates for in the past, or not entered
        dt = pd.to_datetime(df_all_permit_status_filtered["Anticipated Application Date"], errors="coerce")  # blanks/invalid -> NaT
        today = pd.Timestamp.today().normalize()
        mask = dt.isna() | (dt.dt.normalize() < today)  # empty OR strictly in the past
        df_all_dates_filtered = df_all_permit_status_filtered.loc[mask]

        #3)extract out the data that we need from the comments
        df_comments_extracted = extract_top_comment_triplets(df_all_dates_filtered)

        #6) Filter for the last comment date to later than 14 days from today (for the ones that have anticipate dates) and for later than 14 days for the ones that don't have anticipated date
        df_comments_filtered = filter_for_followup(df_comments_extracted)
        df_preparing_application_comments_extracted = df_comments_filtered

    #8) combine the two (actions + preparing application)
    df_final = pd.concat([df_preparing_application_comments_extracted, df_action_comments_extracted], ignore_index=True)
    
    #10) log this into communicator
    db = PolesDB()
    db.add_communications_from_df(df_final, dependency_type="Land", date=datetime.now(), communication_log="Email Sent", allow_duplicates=True)

    #11) create emails
    subject = "Please Provide Update"
    body = "Hi,<br><br>Can you please review the action column and provide update(s) on the following order(s).<br><br>"
    open_outlook_drafts_by_lan_id(df_final, subject, body)  

def actions_to_send_out_emails_for(
    categories: Iterable[str],
    category_action_map: Sequence[Sequence[str]],
    *,
    case_insensitive: bool = False
) -> List[str]:
    """
    Return all 'action' (index 1) values for rows whose 'category' (index 0)
    is present in `categories`.

    - Preserves the order of `category_action_map`.
    - If `case_insensitive=True`, compares using lowercase.
    """
    if case_insensitive:
        wanted = {c.lower() for c in categories}
        return [row[1] for row in category_action_map if row and row[0].lower() in wanted]
    else:
        wanted = set(categories)
        return [row[1] for row in category_action_map if row and row[0] in wanted]

#filter out latest comment date and the anticipated permit date
def filter_for_followup(out: pd.DataFrame) -> pd.DataFrame:
    # Parse dates (robust to blanks/strings)
    latest = pd.to_datetime(out["Latest Comment Date"], errors="coerce").dt.normalize()
    anticipated = pd.to_datetime(out["Anticipated Application Date"], errors="coerce").dt.normalize()

    today = pd.Timestamp.today().normalize()

    # Rule 1: Anticipated date present  -> keep if latest comment is ≥14 days old
    rule1 = anticipated.notna() & (latest <= today - pd.Timedelta(days=14))

    # Rule 2: Anticipated date missing -> keep if latest comment is ≥30 days old
    rule2 = anticipated.isna() & (latest <= today - pd.Timedelta(days=14))

    keep_mask = rule1 | rule2

    # Optional: label which rule matched (handy for reviewing)
    out_filtered = out.loc[keep_mask].copy()

    return out_filtered