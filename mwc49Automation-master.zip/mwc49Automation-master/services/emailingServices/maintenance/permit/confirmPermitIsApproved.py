import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import open_outlook_drafts_by_div
from ledgers.emailLedgers.maintenance.emailLedger import permitConfirmPermitIsApproved_el
from ledgers.emailLedgers.maintenance.columnLedger import permitColumns
# from comms.comm_logger import record_email_comm

COLUMNS = permitColumns
RECIPIENTS_MAP = permitConfirmPermitIsApproved_el

def confirmPermitIsApproved_maintenance(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    action_norm = df_norm["Action"].astype(str).str.strip().str.casefold()
    df_final = df_norm[action_norm == "confirm permit is approved and complete sap task"].copy()
    df_final = df_final[df_final["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()        #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")


    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    if df_final.empty:
        print("No rows match comfirm permit is approved and complete sap task")
        return

    # 4) open Outlook draft for each Div separtely
    subject = "Permit Approved - Please Review and Complete Task in SAP"
    body = "Hi,<br><br>E permit status indicates that permit(s) for below order(s) is/are approved. Please review and complete SAP tasks if this is accurate. If not, please let us know what else is pending to get the task completed.<br><br>"
    open_outlook_drafts_by_div(df_final,COLUMNS,RECIPIENTS_MAP, subject,body)
