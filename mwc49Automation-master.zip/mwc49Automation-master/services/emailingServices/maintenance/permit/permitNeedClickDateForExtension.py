import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import df_to_excelish_html
from ledgers.emailLedgers.maintenance.emailLedger import permitNeedClickDateForExtension_el
from ledgers.emailLedgers.maintenance.columnLedger import permitColumns_needClickDateForExtension

COLUMNS = permitColumns_needClickDateForExtension
RECIPIENTS_MAP = permitNeedClickDateForExtension_el

def needClickDateForExtension_maintenance(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    action_norm = df_norm["Action"].astype(str).str.strip().str.casefold()
    df_final = df_norm[action_norm == "need click date for extension"].copy()
    df_final = df_final[df_final["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()        #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    if df_final.empty:
        print("No rows match comfirm permit is approved and complete sap task")
        return

    # 4) open ONE Outlook draft with the full table
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError("pywin32 is required for Outlook automation. Install: pip install pywin32") from e
    
    html_table = df_to_excelish_html(df_final, COLUMNS)
    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem
    mail.Subject = f"Click Date Needed for Extension"
    mail.HTMLBody = "<p>Hi Wanqui,<br><br>The order(s) below have expired permits and a new Click Date is needed to request for an extension. Please escalate this with the planning team for scheduling.<br><br>" + html_table + "Thank You"
    mail.To = RECIPIENTS_MAP["to"]
    mail.CC = RECIPIENTS_MAP["cc"]
    mail.Display(True)
