import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import open_outlook_drafts_by_div
from ledgers.emailLedgers.maintenance.emailLedger import permitRequestForExtension_el
from ledgers.emailLedgers.maintenance.columnLedger import permitColumns
# from comms.comm_logger import record_email_comm

COLUMNS = permitColumns
RECIPIENTS_MAP = permitRequestForExtension_el

def requestForExtension_maintenance(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Permit")
    # df_btag = load_sheet(file_path, "BTag Permit")  note that we do not need the BTag sheet for the maintenance program. so we can comment this part out about taking that sheet in and adding a column that tells them whether this is BTag or not.

    # # 2) Stamp B-Tag and Non-BTag
    # df_norm["BTag"] = "No"     
    # df_btag["BTag"] = "Yes"    

    # # 3) append into one table
    # df_all = pd.concat([df_btag, df_norm], ignore_index=True)

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    action_norm = df_norm["Action"].astype(str).str.strip().str.casefold()
    df_final = df_norm[action_norm == "request for extension"].copy()
    df_final = df_final[df_final["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()        #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program

    # tidy dates for display
    for col in ("Work Plan Date", "CLICK Start Date", "CLICK End Date", "Permit Application Date", "Permit Expiration Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    #Log this to communications
    # record_email_comm(df_final, "Permit | Request for Extension")

    if df_final.empty:
        print("No rows match request for extension")
        return

    # 4) open Outlook draft for each Div separtely
    subject = "Permit Extension Required"
    body = "Hi,<br><br>Please request for an extension for the order(s) below.<br><br>"
    open_outlook_drafts_by_div(df_final,COLUMNS,RECIPIENTS_MAP, subject,body)
