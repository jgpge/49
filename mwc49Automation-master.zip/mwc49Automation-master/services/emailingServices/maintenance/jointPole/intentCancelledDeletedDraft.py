import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import df_to_excelish_html
from ledgers.emailLedgers.maintenance.emailLedger import jointPoleIntentCancelledDeletedDraft_el
from ledgers.emailLedgers.maintenance.columnLedger import jointPoleColumns
# from comms.comm_logger import record_email_comm

COLUMNS = jointPoleColumns
RECIPIENTS_MAP = jointPoleIntentCancelledDeletedDraft_el

def intentCancelledDeleteDraft_maintenance(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Joint Pole")

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    keep_values = [
        "intent deleted. review and complete task if jp is not needed",
        "intent in draft. review and provide update",
        "intent cancelled. review and complete task if jp is not needed",
    ]
    action_norm = df_norm["Action"].astype(str).str.strip().str.casefold()
    df_final = df_norm[action_norm.isin(keep_values)].copy()
    df_final = df_final[df_final["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()        #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program

    # tidy dates for display
    for col in ("Work Plan Date", "JP Status Date", "JP Due Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")

    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    if df_final.empty:
        print("No rows match 'Released. Verify PC20'. No draft created.")
        return

    # 4) open ONE Outlook draft with the full table
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError("pywin32 is required for Outlook automation. Install: pip install pywin32") from e

    html_table = df_to_excelish_html(df_final, COLUMNS)
    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem
    mail.Subject = f"Joint Pole Status Update Needed"
    mail.HTMLBody = "<p>Hi Stuti,<br><br>Please review the table below and provide the needed estimation action on the following order(s).<br><br>" + html_table + "Thank You"
    mail.To = RECIPIENTS_MAP["to"]
    mail.CC = RECIPIENTS_MAP["cc"]
    mail.Display(True)