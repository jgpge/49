# emailCategories/jointPoleReleasedVerifyPC20.py
# pip install pandas openpyxl pywin32
import pandas as pd
from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.output import print_final_table
from helpers.emailHelpers.email import df_to_excelish_html
from ledgers.emailLedgers.maintenance.emailLedger import jointPoleReleasedVerifyPC20_el
from ledgers.emailLedgers.maintenance.columnLedger import jointPoleColumns
#from comms.comm_logger import record_email_comm

COLUMNS = jointPoleColumns
RECIPIENTS_MAP = jointPoleReleasedVerifyPC20_el

def releasedVerifyPC20_maintenance(file_path: str):
    # 1) load two sheets and align columns
    df_norm = load_sheet(file_path, "Joint Pole")
    # df_btag = load_sheet(file_path, "BTag Permit")  note that we do not need the BTag sheet for the maintenance program. so we can comment this part out about taking that sheet in and adding a column that tells them whether this is BTag or not.

    # # 2) Stamp B-Tag and Non-BTag
    # df_norm["BTag"] = "No"     
    # df_btag["BTag"] = "Yes"    

    # # 3) append into one table
    # df_all = pd.concat([df_btag, df_norm], ignore_index=True)

    # 4) keep only Action == "Released. Verify PC20" (case-insensitive, trimmed)
    action_norm = df_norm["Action"].astype(str).str.strip().str.casefold()
    df_final = df_norm[action_norm == "released. verify pc20"].copy()
    df_final = df_final[df_final["WMP Commitments"].astype("string").str.strip().str.casefold() == "wmp backlog"].copy()        #filtering out the WMP Commitments to only WMP Backlog. Note that we are only doing this for the maintenance program
    
    # tidy dates for display
    for col in ("Work Plan Date", "JP Status Date", "JP Due Date"):
        if col in df_final.columns:
            df_final[col] = pd.to_datetime(df_final[col], errors="coerce").dt.strftime("%m/%d/%Y")


    # Log the final combined table
    print_final_table(df_final, COLUMNS)

    if df_final.empty:
        print("No rows match 'Released. Verify PC20'. No draft created.")
        return
    
    #Log this to communications
    #record_email_comm(df_final, "Joint Pole | Released. Verify PC20")

    # 4) open ONE Outlook draft with the full table
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError("pywin32 is required for Outlook automation. Install: pip install pywin32") from e

    html_table = df_to_excelish_html(df_final, COLUMNS)
    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem
    mail.Subject = f"Send to Construction with Task Open"
    mail.HTMLBody = "<p>Hi Pam,<br><br>The table below is a list of order(s) that have JP status as \"Sent to Construction\" but either PC20 and or DS42 is still open in SAP. Please review and complete these tasks.<br><br>" + html_table + "Thank You"
    mail.To = RECIPIENTS_MAP["to"]
    mail.CC = RECIPIENTS_MAP["cc"]
    mail.Display(True)
