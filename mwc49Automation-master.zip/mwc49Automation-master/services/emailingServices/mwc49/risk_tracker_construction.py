# services/emailingServices/mwc49/risk_tracker_construction.py
from __future__ import annotations

import pandas as pd
from datetime import datetime
import tempfile
import os

from helpers.emailHelpers.loadSheet import load_sheet
from helpers.emailHelpers.email import df_to_excelish_html


# Final column order for the email table
COLUMNS = [
    "Main Work Center",        # NEW: first column
    "Region",
    "Division",
    "PM #",
    "Notification #",
    "CLICK End Date",
    "Action",
    "Comments",                # NEW: empty column for user notes
    "Current Mat",
    "Program Name",
    "Construction Resource",
    "SAP Order User Status",   # NEW: right before PRY
    "Project Reporting Year",
]


def mwc49_risk_tracker_emailer_construction(file_path: str) -> None:
    """
    Build and display an Outlook draft email for MWC49 Risk Tracker - Construction.

    Steps:
      1) Load 'Sheet1' from the Excel file.
      2) Filter Stakeholder == 'Construction'.
      3) Keep/reorder the required columns in COLUMNS.
      4) Tidy date formats.
      5) Create an Outlook draft with a formatted HTML table in the body.
      6) Attach the same data as an Excel file:
         'Construction Action Items - MMDDYYYY.xlsx'
    """
    # ---------------- Step 1: Load Sheet1 ----------------
    df = load_sheet(file_path, "Sheet1")

    if df.empty:
        print("MWC49 Construction Emailer: Sheet1 is empty; no email generated.")
        return

    # ---------------- Step 2: Filter Stakeholder == 'Construction' ----------------
    if "Stakeholder" not in df.columns:
        print("MWC49 Construction Emailer: 'Stakeholder' column not found; no email generated.")
        return

    stake_norm = df["Stakeholder"].astype(str).str.strip().str.casefold()
    df_constr = df[stake_norm == "construction"].copy()

    if df_constr.empty:
        print("MWC49 Construction Emailer: No rows with Stakeholder == 'Construction'; no email generated.")
        return

    # ---------------- Handle possible mis-typed CLICK End Date column ----------------
    # If "CLICK End Date" is missing but "CLIKC End date" exists, copy it over.
    if "CLICK End Date" not in df_constr.columns and "CLIKC End date" in df_constr.columns:
        df_constr["CLICK End Date"] = df_constr["CLIKC End date"]

    # ---------------- Step 3: Keep only the desired columns, in the right order ----------------
    # Ensure all required columns exist; if missing, create them as blank.
    for col in COLUMNS:
        if col not in df_constr.columns:
            df_constr[col] = ""

    df_final = df_constr[COLUMNS].copy()

    # ---------------- Step 3.5: Tidy date formats ----------------
    # CLICK End Date -> mm/dd/YYYY
    if "CLICK End Date" in df_final.columns:
        df_final["CLICK End Date"] = (
            pd.to_datetime(df_final["CLICK End Date"], errors="coerce")
              .dt.strftime("%m/%d/%Y")
        )

    # ---------------- Dates for subject/body/attachment ----------------
    today = datetime.now()
    today_str_compact = today.strftime("%m%d%Y")   # for filename: MMDDYYYY
    today_str_display = today.strftime("%m/%d/%Y") # for body:    MM/DD/YYYY

    # ---------------- Step 4: Build Outlook email ----------------
    try:
        import win32com.client as win32
    except ImportError as e:
        raise ImportError(
            "pywin32 is required for Outlook automation. Install with: pip install pywin32"
        ) from e

    # Convert DataFrame to HTML table in a grid/excel-like look
    html_table = df_to_excelish_html(df_final, COLUMNS)

    app = win32.Dispatch("Outlook.Application")
    mail = app.CreateItem(0)  # olMailItem

    mail.Subject = "Weekly MWC 49& 3UP Readiness & Delivery WOR | Construction action items"

    # Use whatever final addresses you want here
    mail.To = "uxgj@pge.com"
    mail.CC = "yxzk@pge.com; jg57@pge.com"

    mail.HTMLBody = (
        "<p>Hi all,<br><br>"
        "Please find the weekly update for MWC 49 &amp; 3UP Readiness &amp; Delivery "
        "&ndash; Construction Action Items below. This email is automatically generated "
        "based on the latest data.<br><br>"
        f"{html_table}"
        f"<br><br>Data date: {today_str_display}"
        "<br><br>Thank you</p>"
    )

    # ---------------- Step 5: Attach as Excel file ----------------
    # Filename: "Construction Action Items - MMDDYYYY.xlsx"
    attach_filename = f"Construction Action Items - {today_str_compact}.xlsx"

    # Write to a temp file with the desired name
    temp_dir = tempfile.gettempdir()
    temp_path = os.path.join(temp_dir, attach_filename)
    df_final.to_excel(temp_path, index=False)

    # Attach to the email
    mail.Attachments.Add(Source=os.path.abspath(temp_path))

    # Show the draft to the user
    mail.Display(True)
